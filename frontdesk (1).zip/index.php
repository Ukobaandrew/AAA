<?php
// Redirect to the login page
header("Location: dashboard.php");
exit;
?>
