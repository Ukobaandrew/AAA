
<?php

function sanitizeInput($input) {
    return htmlspecialchars(strip_tags(trim($input)));
}

function redirect($url) {
    header("Location: " . $url);
    exit();
}

function generateToken($length = 32) {
    return bin2hex(random_bytes($length));
}

?>
