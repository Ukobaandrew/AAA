<?php
// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirect if not logged in or not an accountant
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'accountant') {
    header("Location: ../unauthorized.php");
    exit();
}

// Database connection
$host = "localhost";
$dbname = "u740329344_rlis";
$username = "u740329344_rlis";
$password = "Rlis@7030";

// MySQLi for basic connection
$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("MySQLi Connection failed: " . $conn->connect_error);
}

// PDO for queries
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);
} catch (PDOException $e) {
    die("PDO Connection failed: " . $e->getMessage());
}

if (!isset($_GET['invoice_id'])) {
    header("Location: invoices.php");
    exit();
}

$invoice_id = (int)$_GET['invoice_id'];

$stmt = $pdo->prepare("SELECT i.*, p.first_name, p.last_name, p.barcode
                         FROM invoices i
                         JOIN patients p ON i.patient_id = p.id
                         WHERE i.id = ?");
$stmt->execute([$invoice_id]);
$invoice = $stmt->fetch();

if (!$invoice) {
    header("Location: invoices.php");
    exit();
}

$page_title = "Apply Discount to Invoice #{$invoice_id}";
include 'header.php';

// Check for existing discount request
$stmt2 = $pdo->prepare("SELECT * FROM discount_requests 
                        WHERE invoice_id = ? AND status = 'pending'");
$stmt2->execute([$invoice_id]);
$existing_request = $stmt2->fetch();
?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-6 offset-md-3">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Apply Discount</h3>
                </div>
                <form method="post" action="process_discount_request.php">
                    <div class="card-body">
                        <?php if ($existing_request): ?>
                            <div class="alert alert-warning">
                                There is already a pending discount request (#DR-<?= $existing_request['id'] ?>) 
                                for this invoice. You can <a href="discount_approvals.php">review it here</a>.
                            </div>
                        <?php endif; ?>

                        <div class="form-group">
                            <label>Patient</label>
                            <input type="text" class="form-control" readonly 
                                   value="<?= htmlspecialchars($invoice['first_name'] . ' ' . $invoice['last_name']) ?>">
                        </div>

                        <div class="form-group">
                            <label>Barcode</label>
                            <input type="text" class="form-control" readonly 
                                   value="<?= htmlspecialchars($invoice['barcode']) ?>">
                        </div>

                        <div class="form-group">
                            <label>Current Total</label>
                            <input type="text" class="form-control" readonly 
                                   value="₦<?= number_format($invoice['total_amount'], 2) ?>">
                        </div>

                        <div class="form-group">
                            <label>Current Discount</label>
                            <input type="text" class="form-control" readonly 
                                   value="₦<?= number_format($invoice['discount_amount'], 2) ?>">
                        </div>

                        <div class="form-group">
                            <label>Final Amount</label>
                            <input type="text" class="form-control" readonly 
                                   value="₦<?= number_format($invoice['final_amount'], 2) ?>">
                        </div>

                        <hr>

                        <div class="form-group">
                            <label for="discount_amount">Discount Percentage*</label>
                            <input type="number" class="form-control" id="discount_amount" 
                                   name="discount_amount" min="0" max="100" step="0.5" required>
                        </div>

                        <div class="form-group">
                            <label for="reason">Reason for Discount*</label>
                            <textarea class="form-control" id="reason" name="reason" rows="3" required></textarea>
                        </div>

                        <div class="form-group">
                            <label for="notes">Additional Notes</label>
                            <textarea class="form-control" id="notes" name="notes" rows="2"></textarea>
                        </div>

                        <input type="hidden" name="invoice_id" value="<?= $invoice_id ?>">
                        <!-- Optional CSRF token -->
                        <!-- <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?? '' ?>"> -->
                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary" <?= $existing_request ? 'disabled' : '' ?>>
                            <i class="fas fa-paper-plane"></i> Submit Request
                        </button>
                        <a href="invoices.php" class="btn btn-default">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>