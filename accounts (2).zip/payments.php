<?php
// Show errors temporarily
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check if user is logged in and has accountant role
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirect if not logged in or not an accountant
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'accountant') {
    header("Location: ../unauthorized.php");
    exit();
}

// Database connection
$host = "localhost";
$dbname = "u740329344_rlis";
$username = "u740329344_rlis";
$password = "Rlis@7030";

// MySQLi for basic connection
$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("MySQLi Connection failed: " . $conn->connect_error);
}

// PDO for queries
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);
} catch (PDOException $e) {
    die("PDO Connection failed: " . $e->getMessage());
}


$page_title = "Payments Management";
include 'header.php';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        $invoice_id = $_POST['invoice_id'] ?? null;
        $patient_id = $_POST['patient_id'] ?? null;
        $amount = (float)$_POST['amount'];
        $payment_method = $_POST['payment_method'];
        $transaction_id = $_POST['transaction_id'] ?? null;
        $notes = $_POST['notes'] ?? null;
        
        // Validate required fields
        if (empty($amount) || empty($payment_method)) {
            throw new Exception("Amount and payment method are required");
        }
        
        // Record payment
        $stmt = $pdo->prepare("
            INSERT INTO payments (
                invoice_id, 
                patient_id, 
                amount_paid, 
                payment_method, 
                transaction_id, 
                description,
                payment_date,
                status
            ) VALUES (?, ?, ?, ?, ?, ?, NOW(), 'paid')
        ");
        
        $stmt->execute([
            $invoice_id,
            $patient_id,
            $amount,
            $payment_method,
            $transaction_id,
            $notes
        ]);
        
        // Update invoice balance if applicable
        if ($invoice_id) {
            $stmt = $pdo->prepare("
                UPDATE invoices 
                SET balance_remaining = balance_remaining - ?,
                    status = CASE 
                        WHEN (balance_remaining - ?) <= 0 THEN 'paid'
                        ELSE 'partially_paid'
                    END
                WHERE id = ?
            ");
            $stmt->execute([$amount, $amount, $invoice_id]);
        }
        
        $_SESSION['success'] = "Payment recorded successfully";
        header("Location: payments.php");
        exit();
        
    } catch (Exception $e) {
        $_SESSION['error'] = "Error recording payment: " . $e->getMessage();
    }
}

// Handle payment search
$search_query = $_GET['search'] ?? '';
$payments = [];
$invoices = [];
$patients = [];

if (!empty($search_query)) {
    // Search payments
    $stmt = $pdo->prepare("
        SELECT p.*, i.invoice_number, pt.first_name, pt.last_name
        FROM payments p
        LEFT JOIN invoices i ON p.invoice_id = i.id
        LEFT JOIN patients pt ON p.patient_id = pt.id
        WHERE p.transaction_id LIKE ? 
           OR pt.first_name LIKE ? 
           OR pt.last_name LIKE ?
           OR i.invoice_number LIKE ?
        ORDER BY p.payment_date DESC
        LIMIT 50
    ");
    $search_param = "%$search_query%";
    $stmt->execute([$search_param, $search_param, $search_param, $search_param]);
    $payments = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Search invoices for payment form
    $stmt = $pdo->prepare("
        SELECT i.*, p.first_name, p.last_name
        FROM invoices i
        JOIN patients p ON i.patient_id = p.id
        WHERE i.balance_remaining > 0
          AND (i.id LIKE ? OR p.first_name LIKE ? OR p.last_name LIKE ?)
        ORDER BY i.created_at DESC
        LIMIT 10
    ");
    $stmt->execute([$search_param, $search_param, $search_param]);
    $invoices = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Search patients for direct payment
    $stmt = $pdo->prepare("
        SELECT id, first_name, last_name, phone
        FROM patients
        WHERE first_name LIKE ? OR last_name LIKE ? OR phone LIKE ?
        ORDER BY first_name
        LIMIT 10
    ");
    $stmt->execute([$search_param, $search_param, $search_param]);
    $patients = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Get recent payments if no search
if (empty($search_query)) {
    $stmt = $pdo->prepare("
        SELECT p.*, i.invoice_number, pt.first_name, pt.last_name
        FROM payments p
        LEFT JOIN invoices i ON p.invoice_id = i.id
        LEFT JOIN patients pt ON p.patient_id = pt.id
        ORDER BY p.payment_date DESC
        LIMIT 50
    ");
    $stmt->execute();
    $payments = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<div class="container-fluid">
    <div class="row">
     

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Payments Management</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#recordPaymentModal">
                        <i class="fas fa-plus-circle"></i> Record Payment
                    </button>
                </div>
            </div>

            <!-- Search Form -->
            <div class="card mb-4">
                <div class="card-body">
                    <form method="get" action="payments.php">
                        <div class="input-group">
                            <input type="text" class="form-control" placeholder="Search payments by transaction ID, patient name or invoice number..." 
                                   name="search" value="<?= htmlspecialchars($search_query) ?>">
                            <button class="btn btn-outline-secondary" type="submit">
                                <i class="fas fa-search"></i> Search
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Payment List -->
            <div class="card">
                <div class="card-header">
                    <h5><?= empty($search_query) ? 'Recent Payments' : 'Search Results' ?></h5>
                </div>
                <div class="card-body">
                    <?php if (!empty($_SESSION['success'])): ?>
                        <div class="alert alert-success"><?= $_SESSION['success'] ?></div>
                        <?php unset($_SESSION['success']); ?>
                    <?php endif; ?>
                    
                    <?php if (!empty($_SESSION['error'])): ?>
                        <div class="alert alert-danger"><?= $_SESSION['error'] ?></div>
                        <?php unset($_SESSION['error']); ?>
                    <?php endif; ?>
                    
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Patient</th>
                                    <th>Invoice #</th>
                                    <th class="text-end">Amount</th>
                                    <th>Method</th>
                                    <th>Status</th>
                                    <th>Transaction ID</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($payments as $payment): ?>
                                <tr>
                                    <td><?= date('M j, Y h:i A', strtotime($payment['payment_date'])) ?></td>
                                    <td><?= htmlspecialchars($payment['first_name'] . ' ' . $payment['last_name']) ?></td>
                                    <td><?= $payment['invoice_id'] ? '#' . $payment['invoice_id'] : 'N/A' ?></td>
                                    <td class="text-end"><?= number_format($payment['amount_paid'], 2) ?></td>
                                    <td><?= ucfirst($payment['payment_method']) ?></td>
                                    <td><?= ucfirst(str_replace('_', ' ', $payment['status'])) ?></td>
                                    <td><?= $payment['transaction_id'] ?: 'N/A' ?></td>
                                    <td>
                                        <a href="payment_view.php?id=<?= $payment['id'] ?>" class="btn btn-sm btn-primary">
                                            <i class="fas fa-eye"></i> View
                                        </a>
                                        <?php if ($_SESSION['user_role'] == 'admin' || $_SESSION['user_role'] == 'accountant'): ?>
                                        <a href="payment_edit.php?id=<?= $payment['id'] ?>" class="btn btn-sm btn-warning">
                                            <i class="fas fa-edit"></i> Edit
                                        </a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                <?php if (empty($payments)): ?>
                                <tr>
                                    <td colspan="8" class="text-center">No payments found</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<!-- Record Payment Modal -->
<div class="modal fade" id="recordPaymentModal" tabindex="-1" aria-labelledby="recordPaymentModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="recordPaymentModalLabel">Record New Payment</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="post" action="payments.php">
                <div class="modal-body">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="payment_type" class="form-label">Payment Type</label>
                            <select class="form-select" id="payment_type" name="payment_type" onchange="togglePaymentType()">
                                <option value="invoice">Invoice Payment</option>
                                <option value="direct">Direct Patient Payment</option>
                            </select>
                        </div>
                    </div>
                    
                    <!-- Invoice Payment Fields -->
                    <div id="invoice_payment_fields">
                        <div class="row mb-3">
                            <div class="col-md-12">
                                <label for="invoice_search" class="form-label">Search Invoice</label>
                                <input type="text" class="form-control" id="invoice_search" 
                                       placeholder="Search by invoice number or patient name" 
                                       onkeyup="searchInvoices(this.value)">
                                <div id="invoice_results" class="mt-2 border rounded p-2" style="max-height: 200px; overflow-y: auto; display: none;">
                                    <?php foreach ($invoices as $invoice): ?>
                                    <div class="invoice-result p-2 border-bottom" 
                                         data-invoice-id="<?= $invoice['id'] ?>"
                                         data-patient-id="<?= $invoice['patient_id'] ?>"
                                         data-balance="<?= $invoice['balance_remaining'] ?>"
                                         onclick="selectInvoice(this)">
                                        <strong>Invoice #<?= $invoice['id'] ?></strong> - 
                                        <?= htmlspecialchars($invoice['first_name'] . ' ' . $invoice['last_name']) ?>
                                        <br>
                                        <small>
                                            Total: <?= number_format($invoice['final_amount'], 2) ?> | 
                                            Paid: <?= number_format($invoice['final_amount'] - $invoice['balance_remaining'], 2) ?> | 
                                            Balance: <?= number_format($invoice['balance_remaining'], 2) ?>
                                        </small>
                                    </div>
                                    <?php endforeach; ?>
                                    <?php if (empty($invoices)): ?>
                                    <div class="text-center p-2">No invoices found</div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="invoice_id" class="form-label">Invoice ID</label>
                                <input type="text" class="form-control" id="invoice_id" name="invoice_id" readonly>
                            </div>
                            <div class="col-md-6">
                                <label for="patient_name" class="form-label">Patient</label>
                                <input type="text" class="form-control" id="patient_name" readonly>
                                <input type="hidden" id="patient_id" name="patient_id">
                            </div>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="invoice_amount" class="form-label">Invoice Amount</label>
                                <input type="text" class="form-control" id="invoice_amount" readonly>
                            </div>
                            <div class="col-md-6">
                                <label for="invoice_balance" class="form-label">Outstanding Balance</label>
                                <input type="text" class="form-control" id="invoice_balance" readonly>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Direct Payment Fields -->
                    <div id="direct_payment_fields" style="display: none;">
                        <div class="row mb-3">
                            <div class="col-md-12">
                                <label for="patient_search" class="form-label">Search Patient</label>
                                <input type="text" class="form-control" id="patient_search" 
                                       placeholder="Search by patient name or phone" 
                                       onkeyup="searchPatients(this.value)">
                                <div id="patient_results" class="mt-2 border rounded p-2" style="max-height: 200px; overflow-y: auto; display: none;">
                                    <?php foreach ($patients as $patient): ?>
                                    <div class="patient-result p-2 border-bottom" 
                                         data-patient-id="<?= $patient['id'] ?>"
                                         data-patient-name="<?= htmlspecialchars($patient['first_name'] . ' ' . $patient['last_name']) ?>"
                                         onclick="selectPatient(this)">
                                        <?= htmlspecialchars($patient['first_name'] . ' ' . $patient['last_name']) ?>
                                        <br>
                                        <small><?= htmlspecialchars($patient['phone']) ?></small>
                                    </div>
                                    <?php endforeach; ?>
                                    <?php if (empty($patients)): ?>
                                    <div class="text-center p-2">No patients found</div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="direct_patient_id" class="form-label">Patient ID</label>
                                <input type="text" class="form-control" id="direct_patient_id" name="patient_id" readonly>
                            </div>
                            <div class="col-md-6">
                                <label for="direct_patient_name" class="form-label">Patient Name</label>
                                <input type="text" class="form-control" id="direct_patient_name" readonly>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Common Payment Fields -->
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="amount" class="form-label">Amount *</label>
                            <input type="number" class="form-control" id="amount" name="amount" step="0.01" min="0" required>
                        </div>
                        <div class="col-md-6">
                            <label for="payment_method" class="form-label">Payment Method *</label>
                            <select class="form-select" id="payment_method" name="payment_method" required>
                                <option value="">Select Method</option>
                                <option value="cash">Cash</option>
                                <option value="card">Card</option>
                                <option value="bank_transfer">Bank Transfer</option>
                                <option value="mobile_money">Mobile Money</option>
                                <option value="insurance">Insurance</option>
                                <option value="other">Other</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="transaction_id" class="form-label">Transaction/Reference ID</label>
                            <input type="text" class="form-control" id="transaction_id" name="transaction_id">
                        </div>
                        <div class="col-md-6">
                            <label for="notes" class="form-label">Notes</label>
                            <input type="text" class="form-control" id="notes" name="notes">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Record Payment</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Toggle between invoice and direct payment forms
function togglePaymentType() {
    const paymentType = document.getElementById('payment_type').value;
    if (paymentType === 'invoice') {
        document.getElementById('invoice_payment_fields').style.display = 'block';
        document.getElementById('direct_payment_fields').style.display = 'none';
    } else {
        document.getElementById('invoice_payment_fields').style.display = 'none';
        document.getElementById('direct_payment_fields').style.display = 'block';
    }
}

// Search invoices via AJAX
function searchInvoices(query) {
    if (query.length < 2) {
        document.getElementById('invoice_results').style.display = 'none';
        return;
    }
    
    fetch(`ajax_search_invoices.php?q=${encodeURIComponent(query)}`)
        .then(response => response.json())
        .then(data => {
            const resultsContainer = document.getElementById('invoice_results');
            resultsContainer.innerHTML = '';
            
            if (data.length === 0) {
                resultsContainer.innerHTML = '<div class="text-center p-2">No invoices found</div>';
            } else {
                data.forEach(invoice => {
                    const div = document.createElement('div');
                    div.className = 'invoice-result p-2 border-bottom';
                    div.setAttribute('data-invoice-id', invoice.id);
                    div.setAttribute('data-patient-id', invoice.patient_id);
                    div.setAttribute('data-balance', invoice.balance_remaining);
                    div.setAttribute('onclick', 'selectInvoice(this)');
                    
                    div.innerHTML = `
                        <strong>Invoice #${invoice.id}</strong> - 
                        ${invoice.first_name} ${invoice.last_name}
                        <br>
                        <small>
                            Total: ${invoice.final_amount.toFixed(2)} | 
                            Paid: ${(invoice.final_amount - invoice.balance_remaining).toFixed(2)} | 
                            Balance: ${invoice.balance_remaining.toFixed(2)}
                        </small>
                    `;
                    
                    resultsContainer.appendChild(div);
                });
            }
            
            resultsContainer.style.display = 'block';
        });
}

// Search patients via AJAX
function searchPatients(query) {
    if (query.length < 2) {
        document.getElementById('patient_results').style.display = 'none';
        return;
    }
    
    fetch(`ajax_search_patients.php?q=${encodeURIComponent(query)}`)
        .then(response => response.json())
        .then(data => {
            const resultsContainer = document.getElementById('patient_results');
            resultsContainer.innerHTML = '';
            
            if (data.length === 0) {
                resultsContainer.innerHTML = '<div class="text-center p-2">No patients found</div>';
            } else {
                data.forEach(patient => {
                    const div = document.createElement('div');
                    div.className = 'patient-result p-2 border-bottom';
                    div.setAttribute('data-patient-id', patient.id);
                    div.setAttribute('data-patient-name', `${patient.first_name} ${patient.last_name}`);
                    div.setAttribute('onclick', 'selectPatient(this)');
                    
                    div.innerHTML = `
                        ${patient.first_name} ${patient.last_name}
                        <br>
                        <small>${patient.phone || ''}</small>
                    `;
                    
                    resultsContainer.appendChild(div);
                });
            }
            
            resultsContainer.style.display = 'block';
        });
}

// Select an invoice from search results
function selectInvoice(element) {
    document.getElementById('invoice_id').value = element.getAttribute('data-invoice-id');
    document.getElementById('patient_id').value = element.getAttribute('data-patient-id');
    document.getElementById('patient_name').value = element.textContent.split(' - ')[1].trim();
    document.getElementById('invoice_amount').value = element.textContent.match(/Total: ([\d,.]+)/)[1];
    document.getElementById('invoice_balance').value = element.getAttribute('data-balance');
    document.getElementById('amount').max = parseFloat(element.getAttribute('data-balance'));
    document.getElementById('invoice_results').style.display = 'none';
}

// Select a patient from search results
function selectPatient(element) {
    document.getElementById('direct_patient_id').value = element.getAttribute('data-patient-id');
    document.getElementById('direct_patient_name').value = element.getAttribute('data-patient-name');
    document.getElementById('patient_id').value = element.getAttribute('data-patient-id');
    document.getElementById('patient_results').style.display = 'none';
}

// Close search results when clicking outside
document.addEventListener('click', function(e) {
    if (!e.target.closest('#invoice_search') && !e.target.closest('#invoice_results')) {
        document.getElementById('invoice_results').style.display = 'none';
    }
    if (!e.target.closest('#patient_search') && !e.target.closest('#patient_results')) {
        document.getElementById('patient_results').style.display = 'none';
    }
});
</script>

