<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirect if not logged in or not an accountant
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'accountant') {
    header("Location: ../unauthorized.php");
    exit();
}

// Database connection
$host = "localhost";
$dbname = "u740329344_rlis";
$username = "u740329344_rlis";
$password = "Rlis@7030";

// MySQLi for basic connection
$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("MySQLi Connection failed: " . $conn->connect_error);
}

// PDO for queries
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);
} catch (PDOException $e) {
    die("PDO Connection failed: " . $e->getMessage());
}

// Get date range from request or default to current month
$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-01');
$end_date = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-d');
$department_id = isset($_GET['department_id']) ? (int)$_GET['department_id'] : null;
$group_by = isset($_GET['group_by']) ? $_GET['group_by'] : 'day';

// Get departments for filter dropdown
$departments = $pdo->query("SELECT id, name FROM departments ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);

// Build the query based on grouping
switch ($group_by) {
    case 'month':
        $date_format = "DATE_FORMAT(tr.created_at, '%Y-%m')";
        $date_display = "DATE_FORMAT(tr.created_at, '%b %Y')";
        break;
    case 'week':
        $date_format = "DATE_FORMAT(tr.created_at, '%Y-%u')";
        $date_display = "CONCAT('Week ', DATE_FORMAT(tr.created_at, '%u, %Y'))";
        break;
    default: // day
        $date_format = "DATE(tr.created_at)";
        $date_display = "DATE_FORMAT(tr.created_at, '%b %e, %Y')";
}

// Get test volume data
$query = "
    SELECT 
        $date_format as period,
        $date_display as display_period,
        COUNT(tr.id) as test_count,
        SUM(t.price) as total_revenue,
        d.name as department_name,
        t.department_id
    FROM test_results tr
    JOIN tests t ON tr.test_id = t.id
    JOIN departments d ON t.department_id = d.id
    WHERE DATE(tr.created_at) BETWEEN :start_date AND :end_date
";

$params = [
    'start_date' => $start_date,
    'end_date' => $end_date
];

if ($department_id) {
    $query .= " AND t.department_id = :department_id";
    $params['department_id'] = $department_id;
}

$query .= "
    GROUP BY period, d.name, t.department_id
    ORDER BY period, d.name
";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$test_volumes = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate totals
$total_tests = array_sum(array_column($test_volumes, 'test_count'));
$total_revenue = array_sum(array_column($test_volumes, 'total_revenue'));

// Get top tests
$top_tests_query = "
    SELECT 
        t.name,
        COUNT(tr.id) as test_count,
        SUM(t.price) as total_revenue,
        d.name as department_name
    FROM test_results tr
    JOIN tests t ON tr.test_id = t.id
    JOIN departments d ON t.department_id = d.id
    WHERE DATE(tr.created_at) BETWEEN :start_date AND :end_date
";

if ($department_id) {
    $top_tests_query .= " AND t.department_id = :department_id";
}

$top_tests_query .= "
    GROUP BY t.id, d.name
    ORDER BY test_count DESC
    LIMIT 10
";

$stmt = $pdo->prepare($top_tests_query);
$stmt->execute($params);
$top_tests = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="card">
    <div class="card-header">
        <h5>Test Volume Report (<?= date('M j, Y', strtotime($start_date)) ?> to <?= date('M j, Y', strtotime($end_date)) ?>)</h5>
    </div>
    <div class="card-body">
        <!-- Filters -->
        <form method="get" action="reports.php" class="mb-4">
            <input type="hidden" name="report_type" value="test_volume">
            <div class="row">
                <div class="col-md-3">
                    <label for="start_date" class="form-label">From Date</label>
                    <input type="date" class="form-control" id="start_date" name="start_date" 
                           value="<?= htmlspecialchars($start_date) ?>">
                </div>
                <div class="col-md-3">
                    <label for="end_date" class="form-label">To Date</label>
                    <input type="date" class="form-control" id="end_date" name="end_date" 
                           value="<?= htmlspecialchars($end_date) ?>">
                </div>
                <div class="col-md-3">
                    <label for="department_id" class="form-label">Department</label>
                    <select class="form-select" id="department_id" name="department_id">
                        <option value="">All Departments</option>
                        <?php foreach ($departments as $dept): ?>
                        <option value="<?= $dept['id'] ?>" <?= $department_id == $dept['id'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($dept['name']) ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label for="group_by" class="form-label">Group By</label>
                    <select class="form-select" id="group_by" name="group_by">
                        <option value="day" <?= $group_by == 'day' ? 'selected' : '' ?>>Day</option>
                        <option value="week" <?= $group_by == 'week' ? 'selected' : '' ?>>Week</option>
                        <option value="month" <?= $group_by == 'month' ? 'selected' : '' ?>>Month</option>
                    </select>
                </div>
            </div>
            <div class="row mt-3">
                <div class="col-md-12">
                    <button type="submit" class="btn btn-primary">Apply Filters</button>
                    <a href="reports.php?report_type=test_volume" class="btn btn-outline-secondary">Reset</a>
                    <button type="button" class="btn btn-success float-end" onclick="exportToExcel()">
                        <i class="fas fa-file-excel"></i> Export to Excel
                    </button>
                </div>
            </div>
        </form>

        <!-- Summary Cards -->
        <div class="row mb-4">
            <div class="col-md-6">
                <div class="card text-white bg-primary">
                    <div class="card-body">
                        <h5 class="card-title">Total Tests</h5>
                        <h2 class="card-text"><?= number_format($total_tests) ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card text-white bg-success">
                    <div class="card-body">
                        <h5 class="card-title">Total Revenue</h5>
                        <h2 class="card-text"><?= number_format($total_revenue, 2) ?></h2>
                    </div>
                </div>
            </div>
        </div>

        <!-- Test Volume Table -->
        <div class="table-responsive">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>Period</th>
                        <th>Department</th>
                        <th class="text-end">Test Count</th>
                        <th class="text-end">Revenue</th>
                        <th class="text-end">Avg. Revenue/Test</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($test_volumes as $volume): ?>
                    <tr>
                        <td><?= htmlspecialchars($volume['display_period']) ?></td>
                        <td><?= htmlspecialchars($volume['department_name']) ?></td>
                        <td class="text-end"><?= number_format($volume['test_count']) ?></td>
                        <td class="text-end"><?= number_format($volume['total_revenue'], 2) ?></td>
                        <td class="text-end"><?= $volume['test_count'] > 0 ? number_format($volume['total_revenue'] / $volume['test_count'], 2) : '0.00' ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($test_volumes)): ?>
                    <tr>
                        <td colspan="5" class="text-center">No test data found for selected period</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Top Tests -->
        <h5 class="mt-5">Top 10 Tests by Volume</h5>
        <div class="table-responsive">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>Test Name</th>
                        <th>Department</th>
                        <th class="text-end">Test Count</th>
                        <th class="text-end">Revenue</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($top_tests as $test): ?>
                    <tr>
                        <td><?= htmlspecialchars($test['name']) ?></td>
                        <td><?= htmlspecialchars($test['department_name']) ?></td>
                        <td class="text-end"><?= number_format($test['test_count']) ?></td>
                        <td class="text-end"><?= number_format($test['total_revenue'], 2) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- Charts Section -->
        <div class="row mt-5">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h5>Test Volume Trend</h5>
                    </div>
                    <div class="card-body">
                        <canvas id="volumeChart" height="300"></canvas>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h5>Revenue by Department</h5>
                    </div>
                    <div class="card-body">
                        <canvas id="revenueChart" height="300"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
// Prepare data for charts
function prepareChartData() {
    const periods = [...new Set(testVolumes.map(item => item.display_period))];
    const departments = [...new Set(testVolumes.map(item => item.department_name))];
    
    // Volume by period and department
    const volumeData = {};
    departments.forEach(dept => {
        volumeData[dept] = periods.map(period => {
            const item = testVolumes.find(v => v.display_period === period && v.department_name === dept);
            return item ? item.test_count : 0;
        });
    });
    
    // Revenue by department
    const revenueData = {};
    departments.forEach(dept => {
        revenueData[dept] = testVolumes
            .filter(v => v.department_name === dept)
            .reduce((sum, item) => sum + parseFloat(item.total_revenue), 0);
    });
    
    return { periods, departments, volumeData, revenueData };
}

// Initialize charts when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    const testVolumes = <?= json_encode($test_volumes) ?>;
    const { periods, departments, volumeData, revenueData } = prepareChartData();
    
    // Volume Trend Chart
    const volumeCtx = document.getElementById('volumeChart').getContext('2d');
    const volumeChart = new Chart(volumeCtx, {
        type: 'line',
        data: {
            labels: periods,
            datasets: departments.map((dept, i) => ({
                label: dept,
                data: volumeData[dept],
                borderColor: getDepartmentColor(i),
                backgroundColor: getDepartmentColor(i, 0.1),
                borderWidth: 2,
                fill: true
            }))
        },
        options: {
            responsive: true,
            plugins: {
                title: {
                    display: true,
                    text: 'Test Volume Over Time'
                },
                tooltip: {
                    mode: 'index',
                    intersect: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Number of Tests'
                    }
                }
            }
        }
    });
    
    // Revenue by Department Chart
    const revenueCtx = document.getElementById('revenueChart').getContext('2d');
    const revenueChart = new Chart(revenueCtx, {
        type: 'doughnut',
        data: {
            labels: departments,
            datasets: [{
                data: departments.map(dept => revenueData[dept]),
                backgroundColor: departments.map((dept, i) => getDepartmentColor(i)),
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                title: {
                    display: true,
                    text: 'Revenue Distribution'
                },
                legend: {
                    position: 'right'
                }
            }
        }
    });
});

// Helper function to generate consistent colors for departments
function getDepartmentColor(index, opacity = 1) {
    const colors = [
        `rgba(54, 162, 235, ${opacity})`,  // Blue
        `rgba(255, 99, 132, ${opacity})`,   // Red
        `rgba(75, 192, 192, ${opacity})`,   // Teal
        `rgba(255, 159, 64, ${opacity})`,   // Orange
        `rgba(153, 102, 255, ${opacity})`,  // Purple
        `rgba(255, 205, 86, ${opacity})`,   // Yellow
        `rgba(201, 203, 207, ${opacity})`   // Gray
    ];
    return colors[index % colors.length];
}

// Export to Excel
function exportToExcel() {
    // Get current URL with parameters
    let url = new URL(window.location.href);
    url.searchParams.set('export', 'excel');
    
    // Open in new tab to trigger download
    window.open(url.toString(), '_blank');
}
</script>