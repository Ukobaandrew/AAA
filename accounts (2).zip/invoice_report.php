<?php
// Get invoice data
$stmt = $pdo->prepare("
    SELECT i.*, p.first_name, p.last_name, p.phone
    FROM invoices i
    JOIN patients p ON i.patient_id = p.id
    WHERE i.created_at BETWEEN ? AND ?
    ORDER BY i.created_at DESC
");
$stmt->execute([$start_date . ' 00:00:00', $end_date . ' 23:59:59']);
$invoices = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="card">
    <div class="card-header">
        <h5>Invoice List (<?= date('M j, Y', strtotime($start_date)) ?> to <?= date('M j, Y', strtotime($end_date)) ?>)</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>Invoice #</th>
                        <th>Date</th>
                        <th>Patient</th>
                        <th>Contact</th>
                        <th class="text-end">Total</th>
                        <th class="text-end">Paid</th>
                        <th class="text-end">Balance</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($invoices as $invoice): ?>
                    <tr>
                        <td><?= $invoice['id'] ?></td>
                        <td><?= date('M j, Y', strtotime($invoice['created_at'])) ?></td>
                        <td><?= htmlspecialchars($invoice['first_name'] . ' ' . $invoice['last_name']) ?></td>
                        <td><?= htmlspecialchars($invoice['phone']) ?></td>
                        <td class="text-end"><?= number_format($invoice['final_amount'], 2) ?></td>
                        <td class="text-end"><?= number_format($invoice['final_amount'] - $invoice['balance_remaining'], 2) ?></td>
                        <td class="text-end"><?= number_format($invoice['balance_remaining'], 2) ?></td>
                        <td>
                            <?php if ($invoice['balance_remaining'] <= 0): ?>
                                <span class="badge bg-success">Paid</span>
                            <?php elseif ($invoice['balance_remaining'] < $invoice['final_amount']): ?>
                                <span class="badge bg-warning text-dark">Partial</span>
                            <?php else: ?>
                                <span class="badge bg-danger">Unpaid</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="invoice_view.php?id=<?= $invoice['id'] ?>" class="btn btn-sm btn-primary">
                                <i class="fas fa-eye"></i> View
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($invoices)): ?>
                    <tr>
                        <td colspan="9" class="text-center">No invoices found for selected period</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>