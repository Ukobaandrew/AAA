<?php
// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirect if not logged in or not an accountant
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'accountant') {
    header("Location: ../unauthorized.php");
    exit();
}

// Database connection
$host = "localhost";
$dbname = "u740329344_rlis";
$username = "u740329344_rlis";
$password = "Rlis@7030";

// MySQLi for basic connection
$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("MySQLi Connection failed: " . $conn->connect_error);
}

// PDO for queries
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);
} catch (PDOException $e) {
    die("PDO Connection failed: " . $e->getMessage());
}

$page_title = "Invoice Management";
include 'header.php';

// Get filter parameters
$status = isset($_GET['status']) ? $_GET['status'] : 'all';
$date_from = isset($_GET['date_from']) ? $_GET['date_from'] : '';
$date_to = isset($_GET['date_to']) ? $_GET['date_to'] : '';

// Build query
$query = "SELECT i.*, 
                 p.first_name, p.last_name, p.barcode,
                 (SELECT IFNULL(SUM(amount_paid),0) FROM payments WHERE invoice_id = i.id AND status = 'completed') AS amount_paid
          FROM invoices i
          JOIN patients p ON i.patient_id = p.id";

$where = [];
$params = [];

if ($status !== 'all') {
    $where[] = "i.status = ?";
    $params[] = $status;
}

if (!empty($date_from) && !empty($date_to)) {
    $where[] = "DATE(i.created_at) BETWEEN ? AND ?";
    $params[] = $date_from;
    $params[] = $date_to;
}

if (!empty($where)) {
    $query .= " WHERE " . implode(" AND ", $where);
}

$query .= " ORDER BY i.created_at DESC";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$invoices = $stmt->fetchAll();
?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Invoice Management</h3>
                    <div class="card-tools">
                        <button class="btn btn-sm btn-primary" data-toggle="modal" data-target="#exportModal">
                            <i class="fas fa-download"></i> Export
                        </button>
                    </div>
                </div>
                <div class="card-body">
                    <!-- Filter Form -->
                    <form method="get" class="mb-4">
                        <div class="row">
                            <div class="col-md-3">
                                <div class="form-group">
                                    <select name="status" class="form-control">
                                        <option value="all" <?= $status === 'all' ? 'selected' : '' ?>>All Statuses</option>
                                        <option value="unpaid" <?= $status === 'unpaid' ? 'selected' : '' ?>>Unpaid</option>
                                        <option value="paid" <?= $status === 'paid' ? 'selected' : '' ?>>Paid</option>
                                        <option value="pending" <?= $status === 'pending' ? 'selected' : '' ?>>Partially Paid</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <input type="date" name="date_from" class="form-control" 
                                           value="<?= htmlspecialchars($date_from) ?>" placeholder="From Date">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <input type="date" name="date_to" class="form-control" 
                                           value="<?= htmlspecialchars($date_to) ?>" placeholder="To Date">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-filter"></i> Filter
                                </button>
                                <a href="invoices.php" class="btn btn-secondary">
                                    <i class="fas fa-sync"></i> Reset
                                </a>
                            </div>
                        </div>
                    </form>

                    <!-- Invoices Table -->
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Invoice #</th>
                                    <th>Patient</th>
                                    <th>Barcode</th>
                                    <th>Total</th>
                                    <th>Discount</th>
                                    <th>Final Amount</th>
                                    <th>Paid</th>
                                    <th>Balance</th>
                                    <th>Status</th>
                                    <th>Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($invoices as $invoice): ?>
                                    <?php 
                                    $balance = $invoice['final_amount'] - $invoice['amount_paid'];
                                    ?>
                                    <tr>
                                        <td><a href="view_invoice.php?id=<?= $invoice['id'] ?>"><?= $invoice['invoice_number'] ?? 'INV-'.$invoice['id'] ?></a></td>
                                        <td>
                                            <a href="patient_profile.php?id=<?= $invoice['patient_id'] ?>">
                                                <?= htmlspecialchars(($invoice['first_name'] ?? '') . ' ' . ($invoice['last_name'] ?? '')) ?>
                                            </a>
                                        </td>
                                        <td><?= htmlspecialchars($invoice['barcode'] ?? '') ?></td>
                                        <td>₦<?= number_format($invoice['total_amount'] ?? 0, 2) ?></td>
                                        <td><?= $invoice['discount'] ?>%</td>
                                        <td>₦<?= number_format($invoice['final_amount'] ?? 0, 2) ?></td>
                                        <td>₦<?= number_format($invoice['amount_paid'], 2) ?></td>
                                        <td>₦<?= number_format($balance, 2) ?></td>
                                        <td>
                                            <span class="badge badge-<?= 
                                                $invoice['status'] === 'paid' ? 'success' : 
                                                ($invoice['status'] === 'pending' ? 'warning' : 'danger')
                                            ?>">
                                                <?= ucfirst($invoice['status']) ?>
                                            </span>
                                        </td>
                                        <td><?= date('M d, Y', strtotime($invoice['created_at'])) ?></td>
                                        <td>
                                            <div class="btn-group">
                                                <a href="view_invoice.php?id=<?= $invoice['id'] ?>" class="btn btn-sm btn-info" title="View">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                <a href="apply_discount.php?invoice_id=<?= $invoice['id'] ?>" class="btn btn-sm btn-warning" title="Apply Discount">
                                                    <i class="fas fa-percentage"></i>
                                                </a>
                                                <?php if ($invoice['status'] !== 'paid'): ?>
                                                    <a href="record_payment.php?invoice_id=<?= $invoice['id'] ?>" class="btn btn-sm btn-success" title="Record Payment">
                                                        <i class="fas fa-money-bill-wave"></i>
                                                    </a>
                                                <?php endif; ?>
                                                <a href="print_invoice.php?id=<?= $invoice['id'] ?>" class="btn btn-sm btn-secondary" title="Print" target="_blank">
                                                    <i class="fas fa-print"></i>
                                                </a>
                                                <a href="send_invoice_email.php?id=<?= $invoice['id'] ?>" class="btn btn-sm btn-primary" title="Email PDF">
                                                    <i class="fas fa-envelope"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php
// Quick summary queries
$totalInvoices = $pdo->query("SELECT COUNT(*) FROM invoices")->fetchColumn();
$totalPaid = $pdo->query("SELECT COUNT(*) FROM invoices WHERE status = 'paid'")->fetchColumn();
$totalUnpaid = $pdo->query("SELECT COUNT(*) FROM invoices WHERE status = 'unpaid'")->fetchColumn();
$totalCollected = $pdo->query("SELECT IFNULL(SUM(amount_paid),0) FROM payments WHERE status = 'completed'")->fetchColumn();
?>

<div class="row mb-4">
    <div class="col-md-3">
        <div class="card bg-primary text-white">
            <div class="card-body">
                <h5>Total Invoices</h5>
                <h3><?= $totalInvoices ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-success text-white">
            <div class="card-body">
                <h5>Paid</h5>
                <h3><?= $totalPaid ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-danger text-white">
            <div class="card-body">
                <h5>Unpaid</h5>
                <h3><?= $totalUnpaid ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-dark text-white">
            <div class="card-body">
                <h5>Total Collected</h5>
                <h3>₦<?= number_format($totalCollected, 2) ?></h3>
            </div>
        </div>
    </div>
</div>

            </div>
        </div>
    </div>
</div>

<!-- Export Modal -->
<div class="modal fade" id="exportModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Export Invoices</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form method="post" action="export_invoices.php">
                <div class="modal-body">
                    <div class="form-group">
                        <label>Format</label>
                        <select name="format" class="form-control">
                            <option value="excel">Excel</option>
                            <option value="pdf">PDF</option>
                            <option value="csv">CSV</option>
                        </select>
                    </div>
                    <input type="hidden" name="status" value="<?= $status ?>">
                    <input type="hidden" name="date_from" value="<?= $date_from ?>">
                    <input type="hidden" name="date_to" value="<?= $date_to ?>">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Export</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>