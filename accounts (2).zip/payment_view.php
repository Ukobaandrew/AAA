<?php

// Show errors temporarily
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check if user is logged in and has accountant role
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirect if not logged in or not an accountant
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'accountant') {
    header("Location: ../unauthorized.php");
    exit();
}

// Database connection
$host = "localhost";
$dbname = "u740329344_rlis";
$username = "u740329344_rlis";
$password = "Rlis@7030";

// MySQLi for basic connection
$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("MySQLi Connection failed: " . $conn->connect_error);
}

// PDO for queries
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);
} catch (PDOException $e) {
    die("PDO Connection failed: " . $e->getMessage());
}


// Get payment ID
$payment_id = $_GET['id'] ?? null;
if (!$payment_id) {
    header("Location: payments.php");
    exit();
}

// Fetch payment details
$stmt = $pdo->prepare("
    SELECT p.*, 
           i.id as invoice_id, i.final_amount as invoice_amount, i.balance_remaining as invoice_balance,
           pt.first_name, pt.last_name, pt.phone, pt.email
    FROM payments p
    LEFT JOIN invoices i ON p.invoice_id = i.id
    LEFT JOIN patients pt ON p.patient_id = pt.id
    WHERE p.id = ?
");
$stmt->execute([$payment_id]);
$payment = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$payment) {
    $_SESSION['error'] = "Payment not found";
    header("Location: payments.php");
    exit();
}

$page_title = "Payment Details #" . $payment['id'];
include 'header.php';
?>

<div class="container-fluid">
    <div class="row">
       

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Payment Details</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <a href="payments.php" class="btn btn-sm btn-outline-secondary">
                        <i class="fas fa-arrow-left"></i> Back to Payments
                    </a>
                    <?php if ($_SESSION['user_role'] == 'admin' || $_SESSION['user_role'] == 'accountant'): ?>
                    <a href="payment_edit.php?id=<?= $payment['id'] ?>" class="btn btn-sm btn-primary ms-2">
                        <i class="fas fa-edit"></i> Edit Payment
                    </a>
                    <?php endif; ?>
                </div>
            </div>

            <?php if (!empty($_SESSION['success'])): ?>
                <div class="alert alert-success"><?= $_SESSION['success'] ?></div>
                <?php unset($_SESSION['success']); ?>
            <?php endif; ?>
            
            <?php if (!empty($_SESSION['error'])): ?>
                <div class="alert alert-danger"><?= $_SESSION['error'] ?></div>
                <?php unset($_SESSION['error']); ?>
            <?php endif; ?>

            <div class="row">
                <div class="col-md-6">
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5>Payment Information</h5>
                        </div>
                        <div class="card-body">
                            <table class="table table-sm">
                                <tbody>
                                    <tr>
                                        <th>Payment ID</th>
                                        <td><?= $payment['id'] ?></td>
                                    </tr>
                                    <tr>
                                        <th>Date</th>
                                        <td><?= date('M j, Y h:i A', strtotime($payment['payment_date'])) ?></td>
                                    </tr>
                                    <tr>
                                        <th>Amount</th>
                                        <td><?= number_format($payment['amount_paid'], 2) ?></td>
                                    </tr>
                                    <tr>
                                        <th>Payment Method</th>
                                        <td><?= ucfirst(str_replace('_', ' ', $payment['payment_method'])) ?></td>
                                    </tr>
                                    <tr>
                                        <th>Transaction ID</th>
                                        <td><?= $payment['transaction_id'] ?: 'N/A' ?></td>
                                    </tr>
                                    <tr>
                                        <th>Status</th>
                                        <td>
                                            <span class="badge bg-<?= $payment['status'] == 'paid' ? 'success' : 'warning' ?>">
                                                <?= ucfirst($payment['status']) ?>
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Notes</th>
                                        <td><?= $payment['description'] ?: 'N/A' ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5>Patient Information</h5>
                        </div>
                        <div class="card-body">
                            <table class="table table-sm">
                                <tbody>
                                    <tr>
                                        <th>Patient Name</th>
                                        <td><?= htmlspecialchars($payment['first_name'] . ' ' . $payment['last_name']) ?></td>
                                    </tr>
                                    <tr>
                                        <th>Contact</th>
                                        <td>
                                            <?= htmlspecialchars($payment['phone']) ?><br>
                                            <?= htmlspecialchars($payment['email']) ?>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <?php if ($payment['invoice_id']): ?>
                    <div class="card">
                        <div class="card-header">
                            <h5>Invoice Information</h5>
                        </div>
                        <div class="card-body">
                            <table class="table table-sm">
                                <tbody>
                                    <tr>
                                        <th>Invoice #</th>
                                        <td>
                                            <a href="invoice_view.php?id=<?= $payment['invoice_id'] ?>">
                                                <?= $payment['invoice_id'] ?>
                                            </a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Invoice Amount</th>
                                        <td><?= number_format($payment['invoice_amount'], 2) ?></td>
                                    </tr>
                                    <tr>
                                        <th>Amount Paid</th>
                                        <td><?= number_format($payment['invoice_amount'] - $payment['invoice_balance'], 2) ?></td>
                                    </tr>
                                    <tr>
                                        <th>Balance Remaining</th>
                                       <td><?= number_format($payment['invoice_balance'] ?? 0, 2) ?></td>

                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Payment Receipt -->
            <div class="card mt-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5>Payment Receipt</h5>
                    <button class="btn btn-sm btn-outline-secondary" onclick="printReceipt()">
                        <i class="fas fa-print"></i> Print Receipt
                    </button>
                </div>
                <div class="card-body" id="receipt-content">
                    <div class="text-center mb-4">
                        <h4>PAYMENT RECEIPT</h4>
                        <p class="mb-0"><?= date('F j, Y h:i A', strtotime($payment['payment_date'])) ?></p>
                        <p>Receipt #: <?= $payment['id'] ?></p>
                    </div>

                    <div class="row mb-4">
                        <div class="col-md-6">
                            <h6>Paid By:</h6>
                            <p class="mb-1">
                                <strong><?= htmlspecialchars($payment['first_name'] . ' ' . $payment['last_name']) ?></strong>
                            </p>
                            <p class="mb-1"><?= htmlspecialchars($payment['phone']) ?></p>
                            <p><?= htmlspecialchars($payment['email']) ?></p>
                        </div>
                        <div class="col-md-6">
                            <h6>Payment Details:</h6>
                            <p class="mb-1"><strong>Amount:</strong> <?= number_format($payment['amount_paid'], 2) ?></p>
                            <p class="mb-1"><strong>Method:</strong> <?= ucfirst($payment['payment_method']) ?></p>
                            <p class="mb-1"><strong>Transaction ID:</strong> <?= $payment['transaction_id'] ?: 'N/A' ?></p>
                            <?php if ($payment['invoice_id']): ?>
                            <p class="mb-1"><strong>For Invoice:</strong> #<?= $payment['invoice_id'] ?></p>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="border-top pt-3">
                        <p class="text-center">
                            <strong>Thank you for your payment!</strong><br>
                            For any inquiries, please contact our billing department.
                        </p>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<script>
function printReceipt() {
    const receiptContent = document.getElementById('receipt-content').innerHTML;
    const originalContent = document.body.innerHTML;
    
    document.body.innerHTML = `
        <div class="container mt-4">
            ${receiptContent}
            <div class="text-center mt-4">
                <small>Printed on ${new Date().toLocaleString()}</small>
            </div>
        </div>
    `;
    
    window.print();
    document.body.innerHTML = originalContent;
    window.location.reload();
}
</script>
