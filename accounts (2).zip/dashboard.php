<?php
// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirect if not logged in or not an accountant
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'accountant') {
    header("Location: ../unauthorized.php");
    exit();
}

// Database connection
$host = "localhost";
$dbname = "u740329344_rlis";
$username = "u740329344_rlis";
$password = "Rlis@7030";

// MySQLi for basic connection
$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("MySQLi Connection failed: " . $conn->connect_error);
}

// PDO for queries
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);
} catch (PDOException $e) {
    die("PDO Connection failed: " . $e->getMessage());
}

$user_name = $_SESSION['user_name'];
$page_title = "Accounts Dashboard";


// Dates
$today = date('Y-m-d');
$month = date('Y-m');
$last_month = date('Y-m', strtotime('-1 month'));

// Fetch statistics
$stats = [];

// Today's Revenue
$stmt = $pdo->prepare("SELECT SUM(final_amount) FROM invoices WHERE DATE(created_at) = :today AND status = 'paid'");
$stmt->execute(['today' => $today]);
$stats['today_revenue'] = $stmt->fetchColumn() ?? 0;

// Yesterday's Revenue for comparison
$yesterday = date('Y-m-d', strtotime('-1 day'));
$stmt = $pdo->prepare("SELECT SUM(final_amount) FROM invoices WHERE DATE(created_at) = :yesterday AND status = 'paid'");
$stmt->execute(['yesterday' => $yesterday]);
$stats['yesterday_revenue'] = $stmt->fetchColumn() ?? 0;

// This Month's Revenue
$stmt = $pdo->prepare("SELECT SUM(final_amount) FROM invoices WHERE DATE_FORMAT(created_at, '%Y-%m') = :month AND status = 'paid'");
$stmt->execute(['month' => $month]);
$stats['month_revenue'] = $stmt->fetchColumn() ?? 0;

// Last Month's Revenue for comparison
$stmt = $pdo->prepare("SELECT SUM(final_amount) FROM invoices WHERE DATE_FORMAT(created_at, '%Y-%m') = :last_month AND status = 'paid'");
$stmt->execute(['last_month' => $last_month]);
$stats['last_month_revenue'] = $stmt->fetchColumn() ?? 0;

// Pending Invoices
$stmt = $pdo->prepare("SELECT COUNT(*) FROM invoices WHERE status = 'unpaid'");
$stmt->execute();
$stats['pending_invoices'] = $stmt->fetchColumn();

// Pending Discount Requests
$stmt = $pdo->prepare("SELECT COUNT(*) FROM discount_requests WHERE status = 'pending'");
$stmt->execute();
$stats['pending_discounts'] = $stmt->fetchColumn();

// Revenue trend data (last 7 days)
$revenue_trend = [];
for ($i = 6; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-$i days"));
    $stmt = $pdo->prepare("SELECT SUM(final_amount) FROM invoices WHERE DATE(created_at) = :date AND status = 'paid'");
    $stmt->execute(['date' => $date]);
    $amount = $stmt->fetchColumn() ?? 0;
    $revenue_trend[] = [
        'date' => date('D, M j', strtotime($date)),
        'amount' => $amount
    ];
}

// Top paying patients
$top_patients = $pdo->query("
    SELECT p.id, p.first_name, p.last_name, SUM(i.final_amount) as total_spent
    FROM patients p
    JOIN invoices i ON p.id = i.patient_id
    WHERE i.status = 'paid'
    GROUP BY p.id
    ORDER BY total_spent DESC
    LIMIT 5
")->fetchAll();
?>



<!DOCTYPE html>
<html lang="en" data-bs-theme="auto">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Accounts Management System for invoice processing and discount approvals">
    <meta name="author" content="Your Company Name">
    
    <title><?php echo htmlspecialchars($page_title); ?></title>
    
    <!-- Favicon -->
    <link rel="icon" href="assets/favicon.ico" type="image/x-icon">
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" 
          integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/dark.css" media="(prefers-color-scheme: dark)">
    <link rel="stylesheet" href="css/theme.css">
    <link rel="stylesheet" href="css/responsive.css">
    
    <!-- Page-specific CSS -->
    <?php if (isset($page_specific_css)): ?>
    <link rel="stylesheet" href="assets/css/<?php echo htmlspecialchars($page_specific_css); ?>">
    <?php endif; ?>
    
    <!-- Dark mode detection -->
    <script>
        const storedTheme = localStorage.getItem('theme') || 
                          (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
        if (storedTheme) document.documentElement.setAttribute('data-bs-theme', storedTheme);
    </script>
    <style>
:root {
    --primary: #4361ee;
    --secondary: #3f37c9;
    --success: #4cc9f0;
    --info: #4895ef;
    --warning: #f8961e;
    --danger: #f72585;
    --light: #f8f9fa;
    --dark: #212529;
    --white: #ffffff;
    --gray: #6c757d;
    --gray-dark: #343a40;
}

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #f5f7fa;
    color: #333;
}

.dashboard-header {
    background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
    color: white;
    padding: 1.5rem;
    border-radius: 10px;
    margin-bottom: 2rem;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
}

.dashboard-header h1 {
    font-weight: 600;
    margin-bottom: 0.5rem;
}

.dashboard-header p {
    opacity: 0.9;
    margin-bottom: 0;
}

.card {
    border: none;
    border-radius: 10px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    margin-bottom: 1.5rem;
    overflow: hidden;
}

.card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
}

.card-header {
    background-color: var(--white);
    border-bottom: 1px solid rgba(0, 0, 0, 0.05);
    padding: 1.25rem 1.5rem;
    border-radius: 10px 10px 0 0 !important;
}

.card-header h3 {
    font-weight: 600;
    color: var(--dark);
    margin-bottom: 0;
}

.card-body {
    padding: 1.5rem;
}

.stats-card {
    border-radius: 10px;
    color: white;
    padding: 1.5rem;
    position: relative;
    overflow: hidden;
    transition: all 0.3s ease;
    height: 100%;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
}

.stats-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
}

.stats-card .icon {
    font-size: 2.5rem;
    opacity: 0.3;
    position: absolute;
    right: 1.5rem;
    top: 1.5rem;
}

.stats-card .title {
    font-size: 1rem;
    font-weight: 500;
    margin-bottom: 0.5rem;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.stats-card .value {
    font-size: 1.75rem;
    font-weight: 700;
    margin-bottom: 0.5rem;
}

.stats-card .change {
    display: flex;
    align-items: center;
    font-size: 0.85rem;
    font-weight: 500;
}

.stats-card .change.positive i {
    color: #2ecc71;
}

.stats-card .change.negative i {
    color: #e74c3c;
}

.table {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0;
}

.table th {
    background-color: #f8f9fa;
    color: #495057;
    font-weight: 600;
    padding: 1rem;
    border-top: 1px solid #dee2e6;
}

.table td {
    padding: 1rem;
    vertical-align: middle;
    border-top: 1px solid #dee2e6;
}

.table tr:hover td {
    background-color: #f8f9fa;
}

.badge {
    padding: 0.35em 0.65em;
    font-weight: 600;
    letter-spacing: 0.5px;
}

.badge-success {
    background-color: rgba(46, 204, 113, 0.2);
    color: #27ae60;
}

.badge-warning {
    background-color: rgba(241, 196, 15, 0.2);
    color: #f39c12;
}

.badge-danger {
    background-color: rgba(231, 76, 60, 0.2);
    color: #e74c3c;
}

.chart-container {
    position: relative;
    height: 300px;
    width: 100%;
}

.quick-actions {
    display: flex;
    flex-wrap: wrap;
    gap: 1rem;
    margin-bottom: 2rem;
}

.quick-action-btn {
    flex: 1 1 200px;
    background: white;
    border: none;
    border-radius: 8px;
    padding: 1.5rem;
    text-align: center;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
    transition: all 0.3s ease;
    cursor: pointer;
    color: var(--dark);
    text-decoration: none;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
}

.quick-action-btn:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
    color: var(--primary);
    text-decoration: none;
}

.quick-action-btn i {
    font-size: 1.75rem;
    margin-bottom: 0.75rem;
    color: var(--primary);
}

.quick-action-btn span {
    font-weight: 600;
    font-size: 0.95rem;
}

@media (max-width: 768px) {
    .quick-actions {
        flex-direction: column;
    }
    
    .quick-action-btn {
        flex: 1 1 auto;
    }
    
    .stats-card {
        margin-bottom: 1rem;
    }
}
</style>
</head>
<body class="d-flex flex-column min-vh-100">
    <!-- Accessibility skip link -->
    <a href="#main-content" class="visually-hidden-focusable">Skip to main content</a>
    
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm">
        <div class="container-fluid">
            <a class="navbar-brand d-flex align-items-center" href="
#">
                <i class="fas fa-calculator me-2"></i>
                <span class="fw-bold">Accounts Dashboard</span>
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#main-nav" 
                    aria-controls="main-nav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="main-nav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link <?php echo $current_page === 'accounts
/invoices.php' ? 'active' : ''; ?>" href="accounts/invoices.php">
                            <i class="fas fa-file-invoice me-1"></i> Invoices
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo $current_page === 'accounts
/apply_discount.php' ? 'active' : ''; ?>" href="accounts/apply_discount.php">
                            <i class="fas fa-tag me-1"></i> Apply Discount
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo $current_page === 'accounts
/discount_approvals.php' ? 'active' : ''; ?>" href="accounts/discount_approvals.php">
                            <i class="fas fa-check-circle me-1"></i> Approvals
                        </a>
                    </li>
                </ul>
                
                <ul class="navbar-nav ms-auto">
                    <?php if (isset($_SESSION['user_id'])): ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="user-dropdown" role="button" 
                           data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user-circle me-1"></i>
                            <?php echo htmlspecialchars($_SESSION['username'] ?? 'Account'); ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="user-dropdown">
                            <li><a class="dropdown-item" href="accounts
/profile.php"><i class="fas fa-user-cog me-2"></i> Profile</a></li>
                            <li><a class="dropdown-item" href="accounts
/settings.php"><i class="fas fa-cog me-2"></i> Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-danger" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i> Logout</a></li>
                        </ul>
                    </li>
                    <?php endif; ?>
                    <li class="nav-item">
                        <button class="btn btn-link nav-link" id="theme-toggle" title="Toggle dark mode">
                            <i class="fas fa-moon"></i>
                            <i class="fas fa-sun d-none"></i>
                        </button>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <main id="main-content" class="container flex-grow-1 my-4">
        <?php if (isset($_SESSION['flash_message'])): ?>
            <div class="alert alert-<?php echo htmlspecialchars($_SESSION['flash_message']['type']); ?> alert-dismissible fade show" role="alert">
                <?php echo htmlspecialchars($_SESSION['flash_message']['text']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php unset($_SESSION['flash_message']); ?>
        <?php endif; ?>

<!-- DASHBOARD HTML -->
<div class="container-fluid">
    <div class="dashboard-header">
        <div class="row align-items-center">
            <div class="col-md-6">
                <h1>Welcome back, <?= htmlspecialchars($user_name) ?></h1>
                <p>Here's what's happening with your finances today</p>
            </div>
            <div class="col-md-6 text-md-right">
                <h3><?= date('l, F j, Y') ?></h3>
            </div>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="quick-actions">
        <a href="accounts
/invoices.php" class="quick-action-btn">
            <i class="fas fa-file-invoice"></i>
            <span>Create Invoice</span>
        </a>
        <a href="accounts
/payments.php" class="quick-action-btn">
            <i class="fas fa-money-bill-wave"></i>
            <span>Record Payment</span>
        </a>
        <a href="accounts
/reports.php" class="quick-action-btn">
            <i class="fas fa-chart-pie"></i>
            <span>Generate Reports</span>
        </a>
        <a href="accounts
/discount_approvals.php" class="quick-action-btn">
            <i class="fas fa-percentage"></i>
            <span>Discount Approvals</span>
        </a>
    </div>
<?php

// Get filter parameters
$status = $_GET['status'] ?? 'all';
$date_from = $_GET['date_from'] ?? '';
$date_to = $_GET['date_to'] ?? '';

// Build query
$query = "SELECT i.*, 
                 p.first_name, p.last_name, p.barcode,
                 (SELECT IFNULL(SUM(amount_paid), 0) 
                  FROM payments 
                  WHERE invoice_id = i.id AND status IN ('paid', 'partially paid')) AS amount_paid
          FROM invoices i
          JOIN patients p ON i.patient_id = p.id";

$where = [];
$params = [];

if ($status !== 'all') {
    $where[] = "i.status = ?";
    $params[] = $status;
}

if (!empty($date_from) && !empty($date_to)) {
    $where[] = "DATE(i.created_at) BETWEEN ? AND ?";
    $params[] = $date_from;
    $params[] = $date_to;
}

if (!empty($where)) {
    $query .= " WHERE " . implode(" AND ", $where);
}

$query .= " ORDER BY i.created_at DESC";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$invoices = $stmt->fetchAll();
?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h3 class="card-title">Invoice Management</h3>
                    <div class="card-tools">
                        <button class="btn btn-sm btn-primary" data-toggle="modal" data-target="#exportModal">
                            <i class="fas fa-download"></i> Export
                        </button>
                    </div>
                </div>

                <div class="card-body">
                    <!-- Filter Form -->
                    <form method="get" class="mb-4">
                        <div class="row">
                            <div class="col-md-3">
                                <select name="status" class="form-control">
                                    <option value="all" <?= $status === 'all' ? 'selected' : '' ?>>All Statuses</option>
                                    <option value="unpaid" <?= $status === 'unpaid' ? 'selected' : '' ?>>Unpaid</option>
                                    <option value="paid" <?= $status === 'paid' ? 'selected' : '' ?>>Paid</option>
                                    <option value="partially paid" <?= $status === 'partially paid' ? 'selected' : '' ?>>Partially Paid</option>
                                </select>
                            </div>

                            <div class="col-md-3">
                                <input type="date" name="date_from" class="form-control" value="<?= htmlspecialchars($date_from) ?>">
                            </div>

                            <div class="col-md-3">
                                <input type="date" name="date_to" class="form-control" value="<?= htmlspecialchars($date_to) ?>">
                            </div>

                            <div class="col-md-3">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-filter"></i> Filter
                                </button>
                                <a href="invoices.php" class="btn btn-secondary">
                                    <i class="fas fa-sync"></i> Reset
                                </a>
                            </div>
                        </div>
                    </form>

                    <!-- Invoices Table -->
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Invoice #</th>
                                    <th>Patient</th>
                                    <th>Barcode</th>
                                    <th>Total</th>
                                    <th>Discount</th>
                                    <th>Final Amount</th>
                                    <th>Paid</th>
                                    <th>Balance</th>
                                    <th>Status</th>
                                    <th>Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($invoices as $invoice): ?>
                                    <?php
                                        $balance = $invoice['final_amount'] - $invoice['amount_paid'];
                                        if ($invoice['amount_paid'] == 0) {
                                            $invoice_status = 'unpaid';
                                        } elseif ($balance > 0) {
                                            $invoice_status = 'partially paid';
                                        } else {
                                            $invoice_status = 'paid';
                                        }
                                    ?>
                                    <tr>
                                        <td>
                                            <a href="accounts/view_invoice.php?id=<?= $invoice['id'] ?>">
                                                <?= $invoice['invoice_number'] ?? 'INV-' . $invoice['id'] ?>
                                            </a>
                                        </td>

                                        <td>
                                            <a href="accounts/patient_profile.php?id=<?= $invoice['patient_id'] ?>">
                                                <?= htmlspecialchars(($invoice['first_name'] ?? '') . ' ' . ($invoice['last_name'] ?? '')) ?>
                                            </a>
                                        </td>

                                        <td><?= htmlspecialchars($invoice['barcode'] ?? '') ?></td>
                                        <td>₦<?= number_format($invoice['total_amount'] ?? 0, 2) ?></td>
                                        <td><?= $invoice['discount'] ?>%</td>
                                        <td>₦<?= number_format($invoice['final_amount'] ?? 0, 2) ?></td>
                                        <td>₦<?= number_format($invoice['amount_paid'], 2) ?></td>
                                        <td>₦<?= number_format($balance, 2) ?></td>

                                        <td>
                                            <span class="badge badge-<?= 
                                                $invoice_status === 'paid' ? 'success' : 
                                                ($invoice_status === 'partially paid' ? 'warning' : 
                                                ($invoice_status === 'unpaid' ? 'danger' : 'secondary'))
                                            ?>">
                                                <?= ucwords($invoice_status) ?>
                                            </span>
                                        </td>

                                        <td><?= date('M d, Y', strtotime($invoice['created_at'])) ?></td>

                                        <td>
                                            <div class="btn-group">
                                                <a href="accounts/view_invoice.php?id=<?= $invoice['id'] ?>" class="btn btn-sm btn-info" title="View">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                <a href="accounts/apply_discount.php?invoice_id=<?= $invoice['id'] ?>" class="btn btn-sm btn-warning" title="Apply Discount">
                                                    <i class="fas fa-percentage"></i>
                                                </a>
                                                <?php if ($invoice_status !== 'paid'): ?>
                                                    <a href="accounts/record_payment.php?invoice_id=<?= $invoice['id'] ?>" class="btn btn-sm btn-success" title="Record Payment">
                                                        <i class="fas fa-money-bill-wave"></i>
                                                    </a>
                                                <?php endif; ?>
                                                <a href="accounts/print_invoice.php?id=<?= $invoice['id'] ?>" class="btn btn-sm btn-secondary" title="Print" target="_blank">
                                                    <i class="fas fa-print"></i>
                                                </a>
                                                <a href="accounts/send_invoice_email.php?id=<?= $invoice['id'] ?>" class="btn btn-sm btn-primary" title="Email PDF">
                                                    <i class="fas fa-envelope"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

    <!-- Stats Cards -->
    <div class="row">
        <!-- Today's Revenue -->
        <div class="col-md-3 col-sm-6">
            <div class="stats-card bg-primary">
                <i class="fas fa-money-bill-wave icon"></i>
                <div class="title">Today's Revenue</div>
                <div class="value">₦<?= number_format($stats['today_revenue'], 2) ?></div>
<div class="change <?= $stats['today_revenue'] > $stats['yesterday_revenue'] ? 'positive' : 'negative' ?>">
    <i class="fas fa-arrow-<?= $stats['today_revenue'] > $stats['yesterday_revenue'] ? 'up' : 'down' ?>"></i>
    <?= abs($stats['yesterday_revenue'] > 0 
        ? (($stats['today_revenue'] - $stats['yesterday_revenue']) / $stats['yesterday_revenue'] * 100) 
        : 0) ?>%
    vs yesterday
</div>

            </div>
        </div>

        <!-- Monthly Revenue -->
        <div class="col-md-3 col-sm-6">
            <div class="stats-card bg-success">
                <i class="fas fa-chart-line icon"></i>
                <div class="title">Monthly Revenue</div>
                <div class="value">₦<?= number_format($stats['month_revenue'], 2) ?></div>
                <div class="change <?= $stats['month_revenue'] > $stats['last_month_revenue'] ? 'positive' : 'negative' ?>">
                    <i class="fas fa-arrow-<?= $stats['month_revenue'] > $stats['last_month_revenue'] ? 'up' : 'down' ?>"></i>
                   <?= $stats['last_month_revenue'] > 0 
    ? abs((($stats['month_revenue'] - $stats['last_month_revenue']) / $stats['last_month_revenue']) * 100)
    : 0 ?>
%
                    vs last month
                </div>
            </div>
        </div>

        <!-- Pending Invoices -->
        <div class="col-md-3 col-sm-6">
            <div class="stats-card bg-warning">
                <i class="fas fa-file-invoice-dollar icon"></i>
                <div class="title">Pending Invoices</div>
                <div class="value"><?= $stats['pending_invoices'] ?></div>
                <a href="accounts
/invoices.php" class="text-white" style="text-decoration: none; display: inline-block; margin-top: 10px;">
                    View All <i class="fas fa-arrow-right ml-1"></i>
                </a>
            </div>
        </div>

        <!-- Pending Discounts -->
        <div class="col-md-3 col-sm-6">
            <div class="stats-card bg-danger">
                <i class="fas fa-percentage icon"></i>
                <div class="title">Pending Discounts</div>
                <div class="value"><?= $stats['pending_discounts'] ?></div>
                <a href="accounts
/discount_approvals.php" class="text-white" style="text-decoration: none; display: inline-block; margin-top: 10px;">
                    Review <i class="fas fa-arrow-right ml-1"></i>
                </a>
            </div>
        </div>
    </div>

    <div class="row mt-4">
        <!-- Revenue Trend Chart -->
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Revenue Trend (Last 7 Days)</h3>
                </div>
                <div class="card-body">
                    <div class="chart-container">
                        <canvas id="revenueChart"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <!-- Top Paying Patients -->
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Top Paying Patients</h3>
                </div>
                <div class="card-body">
                    <ul class="list-group list-group-flush">
                        <?php foreach ($top_patients as $patient): ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <div>
                             <h6 class="mb-0">
  <?= htmlspecialchars($patient['first_name'] . ' ' . $patient['last_name']) ?>
</h6>

                                <small class="text-muted">Patient ID: <?= $patient['id'] ?></small>
                            </div>
                            <span class="badge badge-success">₦<?= number_format($patient['total_spent'], 2) ?></span>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <div class="row mt-4">
        <!-- Recent Payments -->
        <div class="col-md-6">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h3 class="card-title">Recent Payments</h3>
                    <a href="accounts
/payments.php" class="btn btn-sm btn-outline-primary">View All</a>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Invoice #</th>
                                    <th>Patient</th>
                                    <th>Amount</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php
                            $payments = $pdo->query("SELECT p.*, i.id AS invoice_id, pt.first_name, pt.last_name 
                                FROM payments p
                                JOIN invoices i ON p.invoice_id = i.id
                                JOIN patients pt ON p.patient_id = pt.id
                                ORDER BY p.payment_date DESC LIMIT 5")->fetchAll();

                            foreach ($payments as $payment): ?>
                                <tr>
                                    <td><?= sprintf("INV-%05d", $payment['invoice_id']) ?></td>
                                    <td><?= htmlspecialchars($payment['first_name'] . ' ' . $payment['last_name']) ?></td>
                                    <td>₦<?= number_format($payment['amount_paid'], 2) ?></td>
                                    <td><?= date('M d, Y', strtotime($payment['payment_date'])) ?></td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recent Discount Approvals -->
        <div class="col-md-6">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h3 class="card-title">Recent Discount Approvals</h3>
                    <a href="accounts
/discount_approvals.php" class="btn btn-sm btn-outline-primary">View All</a>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Request #</th>
                                    <th>Invoice</th>
                                    <th>Discount</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php
                            $discounts = $pdo->query("SELECT d.*, i.id AS invoice_id 
                                FROM discount_requests d
                                JOIN invoices i ON d.invoice_id = i.id
                                ORDER BY d.request_date DESC LIMIT 5")->fetchAll();

                            foreach ($discounts as $discount): ?>
                                <tr>
                                    <td>DR-<?= $discount['id'] ?></td>
                                    <td><?= sprintf("INV-%05d", $discount['invoice_id']) ?></td>
                                    <td><?= $discount['discount_amount'] ?>%</td>
                                    <td>
                                        <span class="badge badge-<?= 
                                            $discount['status'] == 'approved' ? 'success' : 
                                            ($discount['status'] == 'rejected' ? 'danger' : 'warning') ?>">
                                            <?= ucfirst($discount['status']) ?>
                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

        <!-- Bootstrap Bundle with Popper -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" 
                integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" 
                crossorigin="anonymous"></script>
        
        <!-- Theme switcher -->
        <script src="js/theme.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Revenue Chart
    const revenueCtx = document.getElementById('revenueChart').getContext('2d');
    const revenueChart = new Chart(revenueCtx, {
        type: 'line',
        data: {
            labels: <?= json_encode(array_column($revenue_trend, 'date')) ?>,
            datasets: [{
                label: 'Daily Revenue (₦)',
                data: <?= json_encode(array_column($revenue_trend, 'amount')) ?>,
                backgroundColor: 'rgba(67, 97, 238, 0.2)',
                borderColor: 'rgba(67, 97, 238, 1)',
                borderWidth: 2,
                tension: 0.3,
                fill: true,
                pointBackgroundColor: 'rgba(67, 97, 238, 1)',
                pointBorderColor: '#fff',
                pointHoverRadius: 5,
                pointHoverBackgroundColor: 'rgba(67, 97, 238, 1)',
                pointHoverBorderColor: '#fff',
                pointHitRadius: 10,
                pointBorderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    position: 'top',
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return '₦' + context.raw.toLocaleString('en-NG', {minimumFractionDigits: 2});
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return '₦' + value.toLocaleString('en-NG');
                        }
                    },
                    grid: {
                        color: 'rgba(0, 0, 0, 0.05)'
                    }
                },
                x: {
                    grid: {
                        display: false
                    }
                }
            }
        }
    });

    // Animate stats cards on scroll
    const animateOnScroll = function() {
        const cards = document.querySelectorAll('.stats-card');
        cards.forEach(card => {
            const cardPosition = card.getBoundingClientRect().top;
            const screenPosition = window.innerHeight / 1.3;
            
            if (cardPosition < screenPosition) {
                card.style.opacity = '1';
                card.style.transform = 'translateY(0)';
            }
        });
    };

    // Set initial state
    const cards = document.querySelectorAll('.stats-card');
    cards.forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
    });

    // Add event listener
    window.addEventListener('scroll', animateOnScroll);
    // Trigger once on load
    animateOnScroll();
});
</script>

<?php include '../includes/footer.php'; ?>