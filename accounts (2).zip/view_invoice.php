<?php
// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirect if not logged in or not an accountant
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'accountant') {
    header("Location: ../unauthorized.php");
    exit();
}

// Database connection
$host = "localhost";
$dbname = "u740329344_rlis";
$username = "u740329344_rlis";
$password = "Rlis@7030";

// MySQLi for basic connection
$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("MySQLi Connection failed: " . $conn->connect_error);
}

// PDO for queries
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);
} catch (PDOException $e) {
    die("PDO Connection failed: " . $e->getMessage());
}


if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: invoices.php");
    exit();
}

$invoice_id = (int)$_GET['id'];

$stmt = $pdo->prepare("SELECT i.*, p.first_name, p.last_name, p.gender, p.barcode, p.phone, p.email FROM invoices i
                    JOIN patients p ON i.patient_id = p.id WHERE i.id = ?");
$stmt->execute([$invoice_id]);
$invoice = $stmt->fetch();

if (!$invoice) {
    echo "<div class='alert alert-danger'>Invoice not found.</div>";
    exit();
}

$items = $pdo->prepare("SELECT * FROM invoice_items WHERE invoice_id = ?");
$items->execute([$invoice_id]);
$invoice_items = $items->fetchAll();

$page_title = "View Invoice #{$invoice['invoice_number']}";
include 'header.php';
?>

<div class="container mt-4">
    <div class="card">
        <div class="card-header bg-primary text-white">
            <h4><?= htmlspecialchars($page_title) ?></h4>
        </div>
        <div class="card-body">
            <div class="row mb-3">
                <div class="col-md-6">
                    <h5>Patient Info</h5>
                    <p><strong>Name:</strong> <?= htmlspecialchars($invoice['first_name'] . ' ' . $invoice['last_name']) ?></p>
                    <p><strong>Gender:</strong> <?= htmlspecialchars($invoice['gender']) ?></p>
                    <p><strong>Phone:</strong> <?= htmlspecialchars($invoice['phone']) ?></p>
                    <p><strong>Email:</strong> <?= htmlspecialchars($invoice['email']) ?></p>
                    <p><strong>Barcode:</strong> <?= htmlspecialchars($invoice['barcode']) ?></p>
                </div>
                <div class="col-md-6">
                    <h5>Invoice Info</h5>
                    <p><strong>Invoice No:</strong> <?= htmlspecialchars($invoice['invoice_number']) ?></p>
                    <p><strong>Date:</strong> <?= htmlspecialchars($invoice['created_at']) ?></p>
                    <p><strong>Status:</strong> <?= htmlspecialchars($invoice['status']) ?></p>
                    <p><strong>Total:</strong> ₦<?= number_format($invoice['total_amount'], 2) ?></p>
                    <p><strong>Discount:</strong> ₦<?= number_format($invoice['discount_amount'], 2) ?></p>
                    <p><strong>Final Amount:</strong> ₦<?= number_format($invoice['final_amount'], 2) ?></p>
                </div>
            </div>

            <h5>Services/Test Items</h5>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Description</th>
                        <th>Amount (₦)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1; foreach ($invoice_items as $item): ?>
                        <tr>
                            <td><?= $i++ ?></td>
                            <td><?= htmlspecialchars($item['description']) ?></td>
                            <td><?= number_format($item['amount'], 2) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <div class="text-end">
                <button onclick="window.print()" class="btn btn-secondary"><i class="fas fa-print"></i> Print</button>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>