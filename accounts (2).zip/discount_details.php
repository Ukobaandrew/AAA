<?php
require_once 'config.php';


// Verify user has accounts access
if ($_SESSION['role'] != 'accountant' && $_SESSION['role'] != 'admin') {
    header("Location: ../unauthorized.php");
    exit();
}

if (!isset($_GET['id'])) {
    header("Location: discount_approvals.php");
    exit();
}

$request_id = (int)$_GET['id'];
$request = $pdo->prepare("
    SELECT d.*, i.invoice_number, i.total_amount, i.final_amount,
           p.first_name, p.last_name, p.barcode, p.phone,
           u1.name AS requested_by, u2.name AS processed_by
    FROM discount_requests d
    JOIN invoices i ON d.invoice_id = i.id
    JOIN patients p ON i.patient_id = p.id
    JOIN users u1 ON d.requested_by = u1.id
    LEFT JOIN users u2 ON d.processed_by = u2.id
    WHERE d.id = ?
")->execute([$request_id])->fetch();

if (!$request) {
    header("Location: discount_approvals.php");
    exit();
}

$page_title = "Discount Request Details";
include 'header.php';
?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Discount Request #<?= $request['id'] ?></h3>
                    <div class="card-tools">
                        <a href="discount_approvals.php" class="btn btn-sm btn-default">
                            <i class="fas fa-arrow-left"></i> Back to List
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <table class="table table-bordered">
                                <tr>
                                    <th>Invoice Number</th>
                                    <td><?= $request['invoice_number'] ?></td>
                                </tr>
                                <tr>
                                    <th>Patient</th>
                                    <td>
                                        <?= htmlspecialchars($request['first_name'] . ' ' . htmlspecialchars($request['last_name'])) ?>
                                        <br>
                                        <small>Barcode: <?= htmlspecialchars($request['barcode']) ?></small>
                                        <br>
                                        <small>Phone: <?= htmlspecialchars($request['phone']) ?></small>
                                    </td>
                                </tr>
                                <tr>
                                    <th>Original Amount</th>
                                    <td>₦<?= number_format($request['total_amount'], 2) ?></td>
                                </tr>
                                <tr>
                                    <th>Discount Requested</th>
                                    <td>₦<?= number_format($request['discount_amount'], 2) ?></td>
                                </tr>
                                <tr>
                                    <th>New Amount</th>
                                    <td>₦<?= number_format($request['total_amount'] - $request['discount_amount'], 2) ?></td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <table class="table table-bordered">
                                <tr>
                                    <th>Status</th>
                                    <td>
                                        <?php if ($request['status'] == 'approved'): ?>
                                            <span class="badge badge-success">Approved</span>
                                        <?php elseif ($request['status'] == 'rejected'): ?>
                                            <span class="badge badge-danger">Rejected</span>
                                        <?php else: ?>
                                            <span class="badge badge-warning">Pending</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th>Requested By</th>
                                    <td><?= htmlspecialchars($request['requested_by']) ?></td>
                                </tr>
                                <tr>
                                    <th>Request Date</th>
                                    <td><?= date('M d, Y h:i A', strtotime($request['request_date'])) ?></td>
                                </tr>
                                <?php if ($request['status'] != 'pending'): ?>
                                    <tr>
                                        <th>Processed By</th>
                                        <td><?= htmlspecialchars($request['processed_by']) ?></td>
                                    </tr>
                                    <tr>
                                        <th>Processed Date</th>
                                        <td><?= date('M d, Y h:i A', strtotime($request['processed_date'])) ?></td>
                                    </tr>
                                    <tr>
                                        <th>Notes</th>
                                        <td><?= nl2br(htmlspecialchars($request['notes'])) ?></td>
                                    </tr>
                                <?php endif; ?>
                            </table>
                        </div>
                    </div>
                    
                    <div class="row mt-4">
                        <div class="col-md-12">
                            <h4>Invoice Items</h4>
                            <?php
                            $items = $pdo->prepare("
                                SELECT * FROM invoice_items 
                                WHERE invoice_id = ?
                            ")->execute([$request['invoice_id']])->fetchAll();
                            ?>
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Test/Service</th>
                                        <th>Price</th>
                                        <th>Quantity</th>
                                        <th>Subtotal</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($items as $item): ?>
                                        <tr>
                                            <td><?= htmlspecialchars($item['test_name']) ?></td>
                                            <td>₦<?= number_format($item['price'], 2) ?></td>
                                            <td><?= $item['quantity'] ?></td>
                                            <td>₦<?= number_format($item['price'] * $item['quantity'], 2) ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                    <tr>
                                        <td colspan="3" class="text-right"><strong>Subtotal:</strong></td>
                                        <td>₦<?= number_format($request['total_amount'], 2) ?></td>
                                    </tr>
                                    <?php if ($request['status'] == 'approved'): ?>
                                        <tr>
                                            <td colspan="3" class="text-right"><strong>Discount:</strong></td>
                                            <td>-₦<?= number_format($request['discount_amount'], 2) ?></td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" class="text-right"><strong>Final Amount:</strong></td>
                                            <td>₦<?= number_format($request['final_amount'], 2) ?></td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>