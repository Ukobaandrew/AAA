<?php
// Get outstanding balances
$stmt = $pdo->prepare("
    SELECT i.*, p.first_name, p.last_name, p.phone, 
           (i.final_amount - IFNULL(SUM(py.amount_paid), 0)) as outstanding
    FROM invoices i
    JOIN patients p ON i.patient_id = p.id
    LEFT JOIN payments py ON py.invoice_id = i.id
    WHERE i.balance_remaining > 0
    GROUP BY i.id
    HAVING outstanding > 0
    ORDER BY outstanding DESC
");
$stmt->execute();
$outstanding = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate totals
$total_outstanding = array_sum(array_column($outstanding, 'outstanding'));
?>

<div class="card">
    <div class="card-header">
        <h5>Outstanding Balances Report</h5>
    </div>
    <div class="card-body">
        <div class="alert alert-danger">
            <strong>Total Outstanding:</strong> <?= number_format($total_outstanding, 2) ?>
        </div>
        
        <div class="table-responsive">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>Invoice #</th>
                        <th>Patient</th>
                        <th>Contact</th>
                        <th class="text-end">Invoice Amount</th>
                        <th class="text-end">Amount Paid</th>
                        <th class="text-end">Outstanding</th>
                        <th>Days Outstanding</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($outstanding as $invoice): 
                        $days = floor((time() - strtotime($invoice['created_at'])) / (60 * 60 * 24));
                    ?>
                    <tr>
                        <td><?= $invoice['id'] ?></td>
                        <td><?= htmlspecialchars($invoice['first_name'] . ' ' . $invoice['last_name']) ?></td>
                        <td><?= htmlspecialchars($invoice['phone']) ?></td>
                        <td class="text-end"><?= number_format($invoice['final_amount'], 2) ?></td>
                        <td class="text-end"><?= number_format($invoice['final_amount'] - $invoice['outstanding'], 2) ?></td>
                        <td class="text-end"><?= number_format($invoice['outstanding'], 2) ?></td>
                        <td>
                            <?= $days ?>
                            <?php if ($days > 30): ?>
                                <span class="badge bg-danger">Overdue</span>
                            <?php elseif ($days > 15): ?>
                                <span class="badge bg-warning text-dark">Due Soon</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="invoice_view.php?id=<?= $invoice['id'] ?>" class="btn btn-sm btn-primary">
                                <i class="fas fa-eye"></i> View
                            </a>
                            <a href="payment_add.php?invoice_id=<?= $invoice['id'] ?>" class="btn btn-sm btn-success">
                                <i class="fas fa-money-bill-wave"></i> Record Payment
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($outstanding)): ?>
                    <tr>
                        <td colspan="8" class="text-center">No outstanding balances found</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>