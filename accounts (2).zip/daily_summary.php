<?php
// Get summary data
$stmt = $pdo->prepare("
    SELECT 
        DATE(created_at) as report_date,
        COUNT(*) as invoice_count,
        SUM(final_amount) as total_amount,
        SUM(final_amount - IFNULL(balance_remaining, 0)) as total_paid,
        SUM(IFNULL(balance_remaining, 0)) as total_outstanding
    FROM invoices
    WHERE created_at BETWEEN ? AND ?
    GROUP BY DATE(created_at)
    ORDER BY report_date DESC
");
$stmt->execute([$start_date . ' 00:00:00', $end_date . ' 23:59:59']);
$daily_summary = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get payment methods summary
$stmt = $pdo->prepare("
    SELECT 
        payment_method,
        COUNT(*) as transaction_count,
        SUM(amount_paid) as total_amount
    FROM payments
    WHERE payment_date BETWEEN ? AND ?
    GROUP BY payment_method
");
$stmt->execute([$start_date . ' 00:00:00', $end_date . ' 23:59:59']);
$payment_methods = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="card">
    <div class="card-header">
        <h5>Daily Financial Summary (<?= date('M j, Y', strtotime($start_date)) ?> to <?= date('M j, Y', strtotime($end_date)) ?>)</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th class="text-end">Invoices</th>
                        <th class="text-end">Total Amount</th>
                        <th class="text-end">Amount Paid</th>
                        <th class="text-end">Outstanding</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($daily_summary as $day): ?>
                    <tr>
                        <td><?= date('M j, Y', strtotime($day['report_date'])) ?></td>
                        <td class="text-end"><?= $day['invoice_count'] ?></td>
                        <td class="text-end"><?= number_format($day['total_amount'], 2) ?></td>
                        <td class="text-end"><?= number_format($day['total_paid'], 2) ?></td>
                        <td class="text-end"><?= number_format($day['total_outstanding'], 2) ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($daily_summary)): ?>
                    <tr>
                        <td colspan="5" class="text-center">No data found for selected period</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <h5 class="mt-4">Payment Methods Summary</h5>
        <div class="table-responsive">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>Payment Method</th>
                        <th class="text-end">Transactions</th>
                        <th class="text-end">Total Amount</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($payment_methods as $method): ?>
                    <tr>
                        <td><?= ucfirst(str_replace('_', ' ', $method['payment_method'])) ?></td>
                        <td class="text-end"><?= $method['transaction_count'] ?></td>
                        <td class="text-end"><?= number_format($method['total_amount'], 2) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>