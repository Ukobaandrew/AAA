<?php
// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirect if not logged in or not an accountant
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'accountant') {
    header("Location: ../unauthorized.php");
    exit();
}

// Database connection
$host = "localhost";
$dbname = "u740329344_rlis";
$username = "u740329344_rlis";
$password = "Rlis@7030";

// MySQLi for basic connection
$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("MySQLi Connection failed: " . $conn->connect_error);
}

// PDO for queries
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);
} catch (PDOException $e) {
    die("PDO Connection failed: " . $e->getMessage());
}


// Verify user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$page_title = "Account Settings";
include 'header.php';

// Get current user data
$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Get user preferences
$preferences = $pdo->prepare("SELECT * FROM user_preferences WHERE user_id = ?");
$preferences->execute([$user_id]);
$prefs = $preferences->fetch(PDO::FETCH_ASSOC) ?: [];
?>

<div class="container-fluid">
    <div class="row">
        

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Account Settings</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <a href="profile.php" class="btn btn-sm btn-outline-secondary">
                        <i class="fas fa-user"></i> My Profile
                    </a>
                </div>
            </div>

            <?php if (!empty($_SESSION['settings_success'])): ?>
                <div class="alert alert-success"><?= $_SESSION['settings_success'] ?></div>
                <?php unset($_SESSION['settings_success']); ?>
            <?php endif; ?>
            
            <?php if (!empty($_SESSION['settings_error'])): ?>
                <div class="alert alert-danger"><?= $_SESSION['settings_error'] ?></div>
                <?php unset($_SESSION['settings_error']); ?>
            <?php endif; ?>

            <div class="row">
                <div class="col-md-6">
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5>Change Password</h5>
                        </div>
                        <div class="card-body">
                            <form method="post" action="update_password.php">
                                <div class="mb-3">
                                    <label for="current_password" class="form-label">Current Password *</label>
                                    <input type="password" class="form-control" id="current_password" name="current_password" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="new_password" class="form-label">New Password *</label>
                                    <input type="password" class="form-control" id="new_password" name="new_password" required>
                                    <div class="form-text">Minimum 8 characters with at least one number and one special character</div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="confirm_password" class="form-label">Confirm New Password *</label>
                                    <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                                </div>
                                
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-key"></i> Change Password
                                </button>
                            </form>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5>Application Preferences</h5>
                        </div>
                        <div class="card-body">
                            <form method="post" action="update_preferences.php">
                                <div class="mb-3">
                                    <label for="theme" class="form-label">Theme</label>
                                    <select class="form-select" id="theme" name="theme">
                                        <option value="light" <?= ($prefs['theme'] ?? 'light') == 'light' ? 'selected' : '' ?>>Light</option>
                                        <option value="dark" <?= ($prefs['theme'] ?? 'light') == 'dark' ? 'selected' : '' ?>>Dark</option>
                                        <option value="system" <?= ($prefs['theme'] ?? 'light') == 'system' ? 'selected' : '' ?>>System Default</option>
                                    </select>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="results_per_page" class="form-label">Results Per Page</label>
                                    <select class="form-select" id="results_per_page" name="results_per_page">
                                        <option value="10" <?= ($prefs['results_per_page'] ?? 20) == 10 ? 'selected' : '' ?>>10</option>
                                        <option value="20" <?= ($prefs['results_per_page'] ?? 20) == 20 ? 'selected' : '' ?>>20</option>
                                        <option value="50" <?= ($prefs['results_per_page'] ?? 20) == 50 ? 'selected' : '' ?>>50</option>
                                        <option value="100" <?= ($prefs['results_per_page'] ?? 20) == 100 ? 'selected' : '' ?>>100</option>
                                    </select>
                                </div>
                                
                                <div class="mb-3 form-check">
                                    <input type="checkbox" class="form-check-input" id="email_notifications" name="email_notifications" 
                                           <?= ($prefs['email_notifications'] ?? 1) ? 'checked' : '' ?>>
                                    <label class="form-check-label" for="email_notifications">Enable Email Notifications</label>
                                </div>
                                
                                <div class="mb-3 form-check">
                                    <input type="checkbox" class="form-check-input" id="notify_critical" name="notify_critical" 
                                           <?= ($prefs['notify_critical'] ?? 1) ? 'checked' : '' ?>>
                                    <label class="form-check-label" for="notify_critical">Notify for Critical Results</label>
                                </div>
                                
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save"></i> Save Preferences
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-header bg-danger text-white">
                    <h5>Danger Zone</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h6>Export My Data</h6>
                            <p>Download all your personal data stored in the system.</p>
                            <a href="export_data.php" class="btn btn-outline-secondary">
                                <i class="fas fa-download"></i> Export Data
                            </a>
                        </div>
                        <div class="col-md-6">
                            <h6>Delete My Account</h6>
                            <p>Permanently delete your account and all associated data.</p>
                            <button class="btn btn-outline-danger" data-bs-toggle="modal" data-bs-target="#deleteAccountModal">
                                <i class="fas fa-trash-alt"></i> Delete Account
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<!-- Delete Account Modal -->
<div class="modal fade" id="deleteAccountModal" tabindex="-1" aria-labelledby="deleteAccountModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title" id="deleteAccountModalLabel">Confirm Account Deletion</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="alert alert-danger">
                    <strong>Warning:</strong> This action cannot be undone. All your data will be permanently deleted.
                </div>
                <p>To confirm, please enter your password:</p>
                <form method="post" action="delete_account.php" id="deleteAccountForm">
                    <div class="mb-3">
                        <label for="confirm_password_delete" class="form-label">Password *</label>
                        <input type="password" class="form-control" id="confirm_password_delete" name="password" required>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" form="deleteAccountForm" class="btn btn-danger">
                    <i class="fas fa-trash-alt"></i> Permanently Delete My Account
                </button>
            </div>
        </div>
    </div>
</div>
