<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use Dompdf\Dompdf;

require_once 'config.php';
require_once '../vendor/autoload.php'; // PHPMailer and Dompdf

if (!isset($_GET['id'])) {
    die('Invoice ID is missing');
}

$invoice_id = (int)$_GET['id'];

$stmt = $pdo->prepare("SELECT i.*, p.first_name, p.last_name, p.email FROM invoices i JOIN patients p ON i.patient_id = p.id WHERE i.id = ?");
$stmt->execute([$invoice_id]);
$invoice = $stmt->fetch();

if (!$invoice || empty($invoice['email'])) {
    die('Invoice not found or patient email is missing');
}

// Load invoice HTML
ob_start();
include 'print_invoice.php?id=' . $invoice_id;
$html = ob_get_clean();

// Generate PDF
$dompdf = new Dompdf();
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();
$pdf = $dompdf->output();

// Create temp file
$pdfPath = sys_get_temp_dir() . "/invoice_{$invoice_id}.pdf";
file_put_contents($pdfPath, $pdf);

// Send with PHPMailer
$mail = new PHPMailer(true);
try {
    // Server settings
    $mail->isSMTP();
    $mail->Host       = 'smtp.hostinger.com'; // Update if needed
    $mail->SMTPAuth   = true;
    $mail->Username   = 'info@lifewaydiagnosticconnect.com';
    $mail->Password   = 'YOUR_EMAIL_PASSWORD'; // ⚠️ REPLACE with your actual password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = 587;

    // Recipients
    $mail->setFrom('info@lifewaydiagnosticconnect.com', 'Lifeway Diagnostic Center');
    $mail->addAddress($invoice['email'], $invoice['first_name'] . ' ' . $invoice['last_name']);

    // Attachments
    $mail->addAttachment($pdfPath, "Invoice_{$invoice['invoice_number']}.pdf");

    // Content
    $mail->isHTML(true);
    $mail->Subject = 'Your Lifeway Diagnostic Invoice';
    $mail->Body    = "Dear {$invoice['first_name']},<br><br>Your invoice is attached as a PDF. Please keep it for your records.<br><br>Thank you,<br>Lifeway Diagnostic Center";

    $mail->send();
    echo "Invoice sent successfully to {$invoice['email']}";
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}

// Cleanup
unlink($pdfPath);
?>
