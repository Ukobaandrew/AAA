<?php
require_once 'config.php';

// Verify user has accounts role
if ($_SESSION['role'] !== 'accountant') {
    header("Location: ../unauthorized.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: discount_approvals.php");
    exit();
}

$action = $_POST['action'];
$request_id = (int)$_POST['request_id'];

try {
    $pdo->beginTransaction();
    
    // Get the request details
    $request = $pdo->prepare("SELECT * FROM discount_requests WHERE id = ?")->execute([$request_id])->fetch();
    
    if (!$request) {
        throw new Exception("Discount request not found");
    }
    
    if ($action === 'approve') {
        // Calculate new amount
        $invoice = $pdo->prepare("SELECT * FROM invoices WHERE id = ?")->execute([$request['invoice_id']])->fetch();
        $discount_amount = (float)$_POST['discount_amount'];
        $new_amount = $invoice['total_amount'] * (1 - ($discount_amount / 100));
        
        // Update invoice
        $pdo->prepare("UPDATE invoices SET 
                      discount = ?, 
                      final_amount = ?,
                      discount_notes = ?
                      WHERE id = ?")
           ->execute([
               $discount_amount,
               $new_amount,
               $_POST['approval_notes'],
               $request['invoice_id']
           ]);
        
        // Update request
        $pdo->prepare("UPDATE discount_requests SET 
                      status = 'approved',
                      processed_by = ?,
                      processed_at = NOW(),
                      approval_notes = ?
                      WHERE id = ?")
           ->execute([
               $_SESSION['user_id'],
               $_POST['approval_notes'],
               $request_id
           ]);
        
        // Log this action
        $pdo->prepare("INSERT INTO audit_logs 
                      (user_id, action, table_name, record_id, details)
                      VALUES (?, ?, ?, ?, ?)")
           ->execute([
               $_SESSION['user_id'],
               'approve_discount',
               'discount_requests',
               $request_id,
               "Approved {$discount_amount}% discount on invoice {$request['invoice_id']}"
           ]);
        
        $_SESSION['success'] = "Discount approved successfully!";
        
    } elseif ($action === 'reject') {
        // Update request
        $pdo->prepare("UPDATE discount_requests SET 
                      status = 'rejected',
                      processed_by = ?,
                      processed_at = NOW(),
                      rejection_reason = ?
                      WHERE id = ?")
           ->execute([
               $_SESSION['user_id'],
               $_POST['rejection_reason'],
               $request_id
           ]);
        
        // Log this action
        $pdo->prepare("INSERT INTO audit_logs 
                      (user_id, action, table_name, record_id, details)
                      VALUES (?, ?, ?, ?, ?)")
           ->execute([
               $_SESSION['user_id'],
               'reject_discount',
               'discount_requests',
               $request_id,
               "Rejected discount request #{$request_id}"
           ]);
        
        $_SESSION['success'] = "Discount request rejected.";
    }
    
    $pdo->commit();
    
} catch (Exception $e) {
    $pdo->rollBack();
    $_SESSION['error'] = "Error processing request: " . $e->getMessage();
}

header("Location: discount_approvals.php");
exit();