<?php

// Show errors temporarily
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check if user is logged in and has accountant role
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirect if not logged in or not an accountant
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'accountant') {
    header("Location: ../unauthorized.php");
    exit();
}

// Database connection
$host = "localhost";
$dbname = "u740329344_rlis";
$username = "u740329344_rlis";
$password = "Rlis@7030";

// MySQLi for basic connection
$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("MySQLi Connection failed: " . $conn->connect_error);
}

// PDO for queries
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);
} catch (PDOException $e) {
    die("PDO Connection failed: " . $e->getMessage());
}

// Get payment ID
$payment_id = $_GET['id'] ?? null;
if (!$payment_id) {
    header("Location: payments.php");
    exit();
}

// Fetch payment details
$stmt = $pdo->prepare("
    SELECT p.*, 
           i.id as invoice_id, i.final_amount as invoice_amount, i.balance_remaining as invoice_balance,
           pt.first_name, pt.last_name, pt.phone, pt.email
    FROM payments p
    LEFT JOIN invoices i ON p.invoice_id = i.id
    LEFT JOIN patients pt ON p.patient_id = pt.id
    WHERE p.id = ?
");
$stmt->execute([$payment_id]);
$payment = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$payment) {
    $_SESSION['error'] = "Payment not found";
    header("Location: payments.php");
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        $amount = (float)$_POST['amount'];
        $payment_method = $_POST['payment_method'];
        $transaction_id = $_POST['transaction_id'] ?? null;
        $notes = $_POST['notes'] ?? null;
        
        // Validate required fields
        if (empty($amount) || empty($payment_method)) {
            throw new Exception("Amount and payment method are required");
        }
        
        // Calculate amount difference
        $amount_diff = $amount - $payment['amount_paid'];
        
        // Begin transaction
        $pdo->beginTransaction();
        
        // Update payment record
        $stmt = $pdo->prepare("
            UPDATE payments 
            SET amount_paid = ?, 
                payment_method = ?, 
                transaction_id = ?, 
                description = ?,
                updated_at = NOW()
            WHERE id = ?
        ");
        
        $stmt->execute([
            $amount,
            $payment_method,
            $transaction_id,
            $notes,
            $payment_id
        ]);
        
        // Update invoice balance if applicable
        if ($payment['invoice_id'] && $amount_diff != 0) {
            $stmt = $pdo->prepare("
                UPDATE invoices 
                SET balance_remaining = balance_remaining - ?,
                    status = CASE 
                        WHEN (balance_remaining - ?) <= 0 THEN 'paid'
                        ELSE 'partially_paid'
                    END
                WHERE id = ?
            ");
            $stmt->execute([$amount_diff, $amount_diff, $payment['invoice_id']]);
        }
        
        $pdo->commit();
        
        $_SESSION['success'] = "Payment updated successfully";
        header("Location: payment_view.php?id=$payment_id");
        exit();
        
    } catch (Exception $e) {
        $pdo->rollBack();
        $_SESSION['error'] = "Error updating payment: " . $e->getMessage();
        header("Location: payment_edit.php?id=$payment_id");
        exit();
    }
}

$page_title = "Edit Payment #" . $payment['id'];
include 'header.php';
?>

<div class="container-fluid">
    <div class="row">
      

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Edit Payment</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <a href="payment_view.php?id=<?= $payment['id'] ?>" class="btn btn-sm btn-outline-secondary">
                        <i class="fas fa-arrow-left"></i> Back to Payment
                    </a>
                </div>
            </div>

            <?php if (!empty($_SESSION['error'])): ?>
                <div class="alert alert-danger"><?= $_SESSION['error'] ?></div>
                <?php unset($_SESSION['error']); ?>
            <?php endif; ?>

            <div class="card">
                <div class="card-header">
                    <h5>Payment Details</h5>
                </div>
                <div class="card-body">
                    <form method="post" action="payment_edit.php?id=<?= $payment['id'] ?>">
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="payment_date" class="form-label">Payment Date</label>
                                <input type="text" class="form-control" id="payment_date" 
                                       value="<?= date('M j, Y h:i A', strtotime($payment['payment_date'])) ?>" readonly>
                            </div>
                            <div class="col-md-6">
                                <label for="payment_id" class="form-label">Payment ID</label>
                                <input type="text" class="form-control" id="payment_id" 
                                       value="<?= $payment['id'] ?>" readonly>
                            </div>
                        </div>
                        
                        <?php if ($payment['invoice_id']): ?>
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="invoice_id" class="form-label">Invoice #</label>
                                <input type="text" class="form-control" id="invoice_id" 
                                       value="<?= $payment['invoice_id'] ?>" readonly>
                            </div>
                            <div class="col-md-6">
                                <label for="patient_name" class="form-label">Patient</label>
                                <input type="text" class="form-control" id="patient_name" 
                                       value="<?= htmlspecialchars($payment['first_name'] . ' ' . $payment['last_name']) ?>" readonly>
                            </div>
                        </div>
                        <?php else: ?>
                        <div class="row mb-3">
                            <div class="col-md-12">
                                <label for="direct_patient" class="form-label">Patient</label>
                                <input type="text" class="form-control" id="direct_patient" 
                                       value="<?= htmlspecialchars($payment['first_name'] . ' ' . $payment['last_name']) ?>" readonly>
                            </div>
                        </div>
                        <?php endif; ?>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="amount" class="form-label">Amount *</label>
                                <input type="number" class="form-control" id="amount" name="amount" 
                                       value="<?= number_format($payment['amount_paid'], 2, '.', '') ?>" 
                                       step="0.01" min="0" required>
                                <?php if ($payment['invoice_id']): ?>
                                <small class="text-muted">
                                    Original invoice amount: <?= number_format($payment['invoice_amount'], 2) ?>
                                </small>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-6">
                                <label for="payment_method" class="form-label">Payment Method *</label>
                                <select class="form-select" id="payment_method" name="payment_method" required>
                                    <option value="">Select Method</option>
                                    <option value="cash" <?= $payment['payment_method'] == 'cash' ? 'selected' : '' ?>>Cash</option>
                                    <option value="card" <?= $payment['payment_method'] == 'card' ? 'selected' : '' ?>>Card</option>
                                    <option value="bank_transfer" <?= $payment['payment_method'] == 'bank_transfer' ? 'selected' : '' ?>>Bank Transfer</option>
                                    <option value="mobile_money" <?= $payment['payment_method'] == 'mobile_money' ? 'selected' : '' ?>>Mobile Money</option>
                                    <option value="insurance" <?= $payment['payment_method'] == 'insurance' ? 'selected' : '' ?>>Insurance</option>
                                    <option value="other" <?= $payment['payment_method'] == 'other' ? 'selected' : '' ?>>Other</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="transaction_id" class="form-label">Transaction/Reference ID</label>
                                <input type="text" class="form-control" id="transaction_id" name="transaction_id"
                                       value="<?= htmlspecialchars($payment['transaction_id']) ?>">
                            </div>
                            <div class="col-md-6">
                                <label for="status" class="form-label">Status</label>
                                <input type="text" class="form-control" id="status" 
                                       value="<?= ucfirst($payment['status']) ?>" readonly>
                            </div>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-12">
                                <label for="notes" class="form-label">Notes</label>
                                <textarea class="form-control" id="notes" name="notes" rows="3"><?= htmlspecialchars($payment['description']?? '') ?></textarea>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-12">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save"></i> Update Payment
                                </button>
                                <a href="payment_view.php?id=<?= $payment['id'] ?>" class="btn btn-outline-secondary">
                                    Cancel
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            
            <?php if ($payment['invoice_id']): ?>
            <div class="card mt-4">
                <div class="card-header">
                    <h5>Invoice Information</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Invoice Amount</th>
                                    <th>Amount Paid</th>
                                    <th>Balance Remaining</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><?= number_format($payment['invoice_amount'], 2) ?></td>
                                    <td><?= number_format($payment['invoice_amount'] - $payment['invoice_balance'], 2) ?></td>
                                    <td><?= number_format($payment['invoice_balance'], 2) ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </main>
    </div>
</div>
