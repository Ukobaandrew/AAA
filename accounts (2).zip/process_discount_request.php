<?php
require_once 'config.php';


// Verify user has accounts role
if ($_SESSION['role'] !== 'accountant') {
    header("Location: ../unauthorized.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: invoices.php");
    exit();
}

$invoice_id = (int)$_POST['invoice_id'];
$discount_amount = (float)$_POST['discount_amount'];
$reason = htmlspecialchars(trim($_POST['reason']));
$notes = htmlspecialchars(trim($_POST['notes']));

// Validate discount amount
if ($discount_amount < 0 || $discount_amount > 100) {
    $_SESSION['error'] = "Discount amount must be between 0 and 100 percent";
    header("Location: apply_discount.php?invoice_id=$invoice_id");
    exit();
}

try {
    $pdo->beginTransaction();
    
    // Check if invoice exists
    $invoice = $pdo->prepare("SELECT * FROM invoices WHERE id = ?")->execute([$invoice_id])->fetch();
    if (!$invoice) {
        throw new Exception("Invoice not found");
    }
    
    // Check for existing pending request
    $existing = $pdo->prepare("SELECT * FROM discount_requests 
                              WHERE invoice_id = ? AND status = 'pending'")
                   ->execute([$invoice_id])->fetch();
    
    if ($existing) {
        throw new Exception("There is already a pending discount request for this invoice");
    }
    
    // Create discount request
    $pdo->prepare("INSERT INTO discount_requests 
                  (invoice_id, discount_amount, reason, notes, requested_by, request_date, status)
                  VALUES (?, ?, ?, ?, ?, NOW(), 'pending')")
       ->execute([
           $invoice_id,
           $discount_amount,
           $reason,
           $notes,
           $_SESSION['user_id']
       ]);
    
    // Log this action
    $pdo->prepare("INSERT INTO audit_logs 
                  (user_id, action, table_name, record_id, details)
                  VALUES (?, ?, ?, ?, ?)")
       ->execute([
           $_SESSION['user_id'],
           'request_discount',
           'discount_requests',
           $pdo->lastInsertId(),
           "Requested $discount_amount% discount for invoice $invoice_id"
       ]);
    
    $pdo->commit();
    
    $_SESSION['success'] = "Discount request submitted successfully!";
    
} catch (Exception $e) {
    $pdo->rollBack();
    $_SESSION['error'] = "Error: " . $e->getMessage();
}

header("Location: invoices.php");
exit();