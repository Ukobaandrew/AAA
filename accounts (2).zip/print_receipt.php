<?php
// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirect if not logged in or not an accountant
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'accountant') {
    header("Location: ../unauthorized.php");
    exit();
}

// Database connection
$host = "localhost";
$dbname = "u740329344_rlis";
$username = "u740329344_rlis";
$password = "Rlis@7030";

// MySQLi for basic connection
$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("MySQLi Connection failed: " . $conn->connect_error);
}

// PDO for queries
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);
} catch (PDOException $e) {
    die("PDO Connection failed: " . $e->getMessage());
}


if (!isset($_GET['invoice_id']) || !isset($_GET['amount'])) {
    die("Invalid request.");
}

$invoice_id = (int)$_GET['invoice_id'];
$amount_paid = (float)$_GET['amount'];

// Fetch invoice, patient, and payment
$stmt = $pdo->prepare("SELECT i.*, p.first_name, p.last_name, p.barcode, p.phone FROM invoices i JOIN patients p ON i.patient_id = p.id WHERE i.id = ?");
$stmt->execute([$invoice_id]);
$invoice = $stmt->fetch();

if (!$invoice) {
    die("Invoice not found.");
}

$payment = $pdo->prepare("SELECT * FROM payments WHERE invoice_id = ? AND amount_paid = ? ORDER BY id DESC LIMIT 1");
$payment->execute([$invoice_id, $amount_paid]);
$payment = $payment->fetch();

if (!$payment) {
    die("Payment record not found.");
}

$date = date("M d, Y h:i A", strtotime($payment['payment_date']));

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Payment Receipt</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        @media print {
            .no-print { display: none; }
        }
        .receipt {
            max-width: 600px;
            margin: auto;
            border: 1px solid #ccc;
            padding: 20px;
        }
    </style>
</head>
<body>
    <div class="receipt">
        <div class="text-center">
            <h4>Lifeway Diagnostic Connect</h4>
            <p><strong>Payment Receipt</strong></p>
            <hr>
        </div>

        <p><strong>Patient:</strong> <?= htmlspecialchars($invoice['first_name'] . ' ' . $invoice['last_name']) ?><br>
        <strong>Phone:</strong> <?= htmlspecialchars($invoice['phone']) ?><br>
        <strong>Barcode:</strong> <?= htmlspecialchars($invoice['barcode']) ?></p>

        <p><strong>Invoice Number:</strong> <?= htmlspecialchars($invoice['invoice_number']) ?><br>
        <strong>Payment Date:</strong> <?= $date ?><br>
        <strong>Payment Method:</strong> <?= ucfirst($payment['payment_method']) ?><br>
        <?php if ($payment['transaction_id']): ?>
            <strong>Transaction ID:</strong> <?= htmlspecialchars($payment['transaction_id']) ?><br>
        <?php endif; ?>
        <?php if ($payment['description']): ?>
            <strong>Description:</strong> <?= htmlspecialchars($payment['description']) ?><br>
        <?php endif; ?>
        </p>

        <table class="table table-bordered">
            <tr>
                <th>Amount Paid</th>
                <td>₦<?= number_format($payment['amount_paid'], 2) ?></td>
            </tr>
            <tr>
                <th>Remaining Balance</th>
                <td>₦<?= number_format($invoice['balance_remaining'], 2) ?></td>
            </tr>
        </table>

        <div class="text-center mt-4">
            <button class="btn btn-primary no-print" onclick="window.print()">Print Receipt</button>
            <a href="../invoices/view_invoice.php?id=<?= $invoice_id ?>" class="btn btn-secondary no-print">Back to Invoice</a>
        </div>
    </div>
</body>
</html>
