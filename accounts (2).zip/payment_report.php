<?php
// Get payment data
$stmt = $pdo->prepare("
    SELECT p.*, i.invoice_number, pt.first_name, pt.last_name
    FROM payments p
    LEFT JOIN invoices i ON p.invoice_id = i.id
    LEFT JOIN patients pt ON p.patient_id = pt.id
    WHERE p.payment_date BETWEEN ? AND ?
    ORDER BY p.payment_date DESC
");
$stmt->execute([$start_date . ' 00:00:00', $end_date . ' 23:59:59']);
$payments = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate totals
$total_payments = array_sum(array_column($payments, 'amount_paid'));
?>

<div class="card">
    <div class="card-header">
        <h5>Payment Summary (<?= date('M j, Y', strtotime($start_date)) ?> to <?= date('M j, Y', strtotime($end_date)) ?>)</h5>
    </div>
    <div class="card-body">
        <div class="alert alert-info">
            <strong>Total Payments:</strong> <?= number_format($total_payments, 2) ?>
        </div>
        
        <div class="table-responsive">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Patient</th>
                        <th>Invoice #</th>
                        <th class="text-end">Amount</th>
                        <th>Method</th>
                        <th>Status</th>
                        <th>Transaction ID</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($payments as $payment): ?>
                    <tr>
                        <td><?= date('M j, Y', strtotime($payment['payment_date'])) ?></td>
                        <td><?= htmlspecialchars($payment['first_name'] . ' ' . $payment['last_name']) ?></td>
                        <td><?= $payment['invoice_id'] ? '#' . $payment['invoice_id'] : 'N/A' ?></td>
                        <td class="text-end"><?= number_format($payment['amount_paid'], 2) ?></td>
                        <td><?= ucfirst($payment['payment_method']) ?></td>
                        <td><?= ucfirst(str_replace('_', ' ', $payment['status'])) ?></td>
                        <td><?= $payment['transaction_id'] ?: 'N/A' ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($payments)): ?>
                    <tr>
                        <td colspan="7" class="text-center">No payments found for selected period</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>