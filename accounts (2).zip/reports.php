<?php

// Show errors temporarily
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check if user is logged in and has accountant role
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirect if not logged in or not an accountant
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'accountant') {
    header("Location: ../unauthorized.php");
    exit();
}

// Database connection
$host = "localhost";
$dbname = "u740329344_rlis";
$username = "u740329344_rlis";
$password = "Rlis@7030";

// MySQLi for basic connection
$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("MySQLi Connection failed: " . $conn->connect_error);
}

// PDO for queries
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);
} catch (PDOException $e) {
    die("PDO Connection failed: " . $e->getMessage());
}



// Verify user has accounting access
if ($_SESSION['user_role'] != 'accountant' && $_SESSION['user_role'] != 'admin') {
    header("Location: unauthorized.php");
    exit();
}

$page_title = "Accounting Reports";
include 'header.php';

// Date range handling
$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-01');
$end_date = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-d');
?>

<div class="container-fluid">
    <div class="row">
     

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Accounting Reports</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <div class="btn-group me-2">
                        <button type="button" class="btn btn-sm btn-outline-secondary" onclick="window.print()">
                            <i class="fas fa-print"></i> Print Report
                        </button>
                        <button type="button" class="btn btn-sm btn-outline-secondary" onclick="exportToExcel()">
                            <i class="fas fa-file-excel"></i> Export to Excel
                        </button>
                    </div>
                </div>
            </div>

            <!-- Date Range Filter -->
            <div class="card mb-4">
                <div class="card-body">
                    <form method="get" action="reports.php">
                        <div class="row">
                            <div class="col-md-3">
                                <label for="start_date" class="form-label">From Date</label>
                                <input type="date" class="form-control" id="start_date" name="start_date" 
                                       value="<?= htmlspecialchars($start_date) ?>">
                            </div>
                            <div class="col-md-3">
                                <label for="end_date" class="form-label">To Date</label>
                                <input type="date" class="form-control" id="end_date" name="end_date" 
                                       value="<?= htmlspecialchars($end_date) ?>">
                            </div>
                            <div class="col-md-3">
                                <label for="report_type" class="form-label">Report Type</label>
                                <select class="form-select" id="report_type" name="report_type">
                                    <option value="daily_summary">Daily Summary</option>
                                    <option value="invoice_list">Invoice List</option>
                                    <option value="payment_summary">Payment Summary</option>
                                    <option value="test_volume">Test Volume</option>
                                    <option value="outstanding_balances">Outstanding Balances</option>
                                </select>
                            </div>
                            <div class="col-md-3 d-flex align-items-end">
                                <button type="submit" class="btn btn-primary">Generate Report</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <?php
            // Determine which report to show
            $report_type = $_GET['report_type'] ?? 'daily_summary';
            
            // Get report data based on type
            switch ($report_type) {
                case 'invoice_list':
                    include 'invoice_report.php';
                    break;
                    
                case 'payment_summary':
                    include 'payment_report.php';
                    break;
                    
                case 'test_volume':
                    include 'test_volume_report.php';
                    break;
                    
                case 'outstanding_balances':
                    include 'outstanding_report.php';
                    break;
                    
                default:
                    include 'daily_summary.php';
            }
            ?>

        </main>
    </div>
</div>

<script>
function exportToExcel() {
    // Get current URL with parameters
    let url = new URL(window.location.href);
    url.searchParams.set('export', 'excel');
    
    // Open in new tab to trigger download
    window.open(url.toString(), '_blank');
}
</script>
