<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Start session
// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Database connection
$host = "localhost";
$dbname = "u740329344_rlis";
$username = "u740329344_rlis";
$password = "Rlis@7030";

// MySQLi for basic connection
$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("MySQLi Connection failed: " . $conn->connect_error);
}

// PDO for queries
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);
} catch (PDOException $e) {
    die("PDO Connection failed: " . $e->getMessage());
}


$page_title = "Discount Approvals";
include 'header.php';

$requests = $pdo->query("SELECT dr.*, i.id as invoice_id, i.total_amount, i.final_amount, 
                         p.first_name, p.last_name, p.barcode,
                         u.name as requested_by
                         FROM discount_requests dr
                         JOIN invoices i ON dr.invoice_id = i.id
                         JOIN patients p ON i.patient_id = p.id
                         JOIN users u ON dr.requested_by = u.id
                         WHERE dr.status = 'pending'
                         ORDER BY dr.request_date DESC")->fetchAll();

?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Pending Discount Requests</h3>
                </div>
                <div class="card-body">
                    <?php if (empty($requests)): ?>
                        <div class="alert alert-info">No pending discount requests</div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>Request #</th>
                                        <th>Invoice</th>
                                        <th>Patient</th>
                                        <th>Current Amount</th>
                                        <th>Requested Discount</th>
                                        <th>Requested By</th>
                                        <th>Reason</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($requests as $request): ?>
                                        <tr>
                                            <td>DR-<?= $request['id'] ?></td>
                                            <td><td>INV-<?= $request['invoice_id'] ?></td>
</td>
                                            <td>
                                                <?= htmlspecialchars($request['first_name'] . ' ' . $request['last_name']) ?><br>
                                                <small><?= htmlspecialchars($request['barcode']) ?></small>
                                            </td>
                                            <td>₦<?= number_format($request['total_amount'], 2) ?></td>
                                            <td><?= $request['discount_amount'] ?>%</td>
                                            <td><?= htmlspecialchars($request['requested_by']) ?></td>
                                            <td><?= htmlspecialchars($request['reason']) ?></td>
                                            <td>
                                                <div class="btn-group">
                                                    <button class="btn btn-sm btn-success approve-btn" 
                                                            data-id="<?= $request['id'] ?>" 
                                                            data-invoice="<?= $request['invoice_id'] ?>"
                                                            data-discount="<?= $request['discount_amount'] ?>"
                                                            data-original="<?= $request['total_amount'] ?>">
                                                        <i class="fas fa-check"></i> Approve
                                                    </button>
                                                    <button class="btn btn-sm btn-danger reject-btn" 
                                                            data-id="<?= $request['id'] ?>">
                                                        <i class="fas fa-times"></i> Reject
                                                    </button>
                                                    <a href="view_invoice.php?id=<?= $request['invoice_id'] ?>" 
                                                       class="btn btn-sm btn-info">
                                                        <i class="fas fa-eye"></i> View
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Approval Modal -->
<div class="modal fade" id="approvalModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Confirm Discount Approval</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="approvalForm" method="post" action="process_discount.php">
                <div class="modal-body">
                    <p>You are about to approve a <span id="discountPercent"></span>% discount.</p>
                    <p>Original Amount: ₦<span id="originalAmount"></span></p>
                    <p>New Amount: ₦<span id="newAmount"></span></p>

                    <div class="form-group">
                        <label for="approvalNotes">Approval Notes</label>
                        <textarea class="form-control" id="approvalNotes" name="approval_notes" rows="3"></textarea>
                    </div>

                    <input type="hidden" name="action" value="approve">
                    <input type="hidden" name="request_id" id="requestId">
                    <input type="hidden" name="invoice_id" id="invoiceId">
                    <input type="hidden" name="discount_amount" id="discountAmount">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-success">Confirm Approval</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Rejection Modal -->
<div class="modal fade" id="rejectionModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Confirm Discount Rejection</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="rejectionForm" method="post" action="process_discount.php">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="rejectionReason">Rejection Reason</label>
                        <textarea class="form-control" id="rejectionReason" name="rejection_reason" rows="3" required></textarea>
                    </div>

                    <input type="hidden" name="action" value="reject">
                    <input type="hidden" name="request_id" id="rejectRequestId">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-danger">Confirm Rejection</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Approval button click
    $('.approve-btn').click(function() {
        const requestId = $(this).data('id');
        const invoiceId = $(this).data('invoice');
        const discount = $(this).data('discount');
        const original = $(this).data('original');
        const newAmount = original * (1 - (discount / 100));

        $('#requestId').val(requestId);
        $('#invoiceId').val(invoiceId);
        $('#discountAmount').val(discount);
        $('#discountPercent').text(discount);
        $('#originalAmount').text(original.toFixed(2));
        $('#newAmount').text(newAmount.toFixed(2));

        $('#approvalModal').modal('show');
    });

    // Rejection button click
    $('.reject-btn').click(function() {
        $('#rejectRequestId').val($(this).data('id'));
        $('#rejectionModal').modal('show');
    });
});
</script>


