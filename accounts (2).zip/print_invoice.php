<?php
// Show errors temporarily
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirect if not logged in or not an accountant
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'accountant') {
    header("Location: ../unauthorized.php");
    exit();
}

// Database connection
$host = "localhost";
$dbname = "u740329344_rlis";
$username = "u740329344_rlis";
$password = "Rlis@7030";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);
} catch (PDOException $e) {
    die("PDO Connection failed: " . $e->getMessage());
}

if (!isset($_GET['id']) || !filter_var($_GET['id'], FILTER_VALIDATE_INT)) {
    die("Invoice ID missing or invalid.");
}

$invoice_id = (int)$_GET['id'];

$stmt = $pdo->prepare("SELECT i.*, p.first_name, p.last_name, p.barcode, p.phone, p.email, p.referral_doctor, p.referral_organisation, i.created_at
                       FROM invoices i
                       JOIN patients p ON i.patient_id = p.id
                       WHERE i.id = ?");
$stmt->execute([$invoice_id]);
$invoice = $stmt->fetch();

if (!$invoice) {
    die("Invoice not found.");
}

$items = $pdo->prepare("SELECT * FROM invoice_items WHERE invoice_id = ?");
$items->execute([$invoice_id]);
$invoice_items = $items->fetchAll();

$total_paid_stmt = $pdo->prepare("SELECT IFNULL(SUM(amount_paid), 0) AS total_paid FROM payments WHERE invoice_id = ? AND status = 'completed'");
$total_paid_stmt->execute([$invoice_id]);
$total_paid = $total_paid_stmt->fetchColumn();
$balance = $invoice['final_amount'] - $total_paid;

// QR code generation
$qrCodePath = '../qr/invoice_' . $invoice['id'] . '.png';
if (!file_exists($qrCodePath)) {
    if (!file_exists('../qr')) {
        mkdir('../qr', 0755, true);
    }
    $qrContent = 'https://lifewaydiagnosticconnect.com/invoice?id=' . $invoice['id'];
    file_put_contents($qrCodePath, file_get_contents('https://api.qrserver.com/v1/create-qr-code/?size=100x100&data=' . urlencode($qrContent)));
}

$invoiceNumber = $invoice['invoice_number'] ?? 'INV-' . $invoice['id'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice #<?= $invoiceNumber ?></title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        .header, .footer { text-align: center; }
        .header img { width: 100px; }
        .invoice-box { max-width: 850px; margin: auto; padding: 20px; border: 1px solid #eee; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ccc; padding: 10px; text-align: left; }
        th { background-color: #f5f5f5; }
        .summary td { font-weight: bold; }
        .qr { float: right; }

        .print-button {
            text-align: center;
            margin-bottom: 20px;
        }

        @media print {
            .print-button { display: none; }
            .qr { float: none; text-align: center; margin-top: 20px; }
            body { margin: 0; font-size: 13px; }
        }
    </style>
</head>
<body>

    <!-- Print Button -->
    <div class="print-button">
        <button onclick="window.print()" style="padding: 10px 20px; font-size: 16px;">🖨️ Print Invoice</button>
    </div>

    <div class="invoice-box">
        <div class="header">
            <img src="../assets/images/logo.png" alt="Logo">
            <h2>LIFEWAY DIAGNOSTIC CENTER</h2>
            <p>123 Health St, City, Nigeria<br>+234 000 0000 000 | info@lifewaydiagnosticconnect.com</p>
        </div>

        <hr>

        <div class="qr">
            <img src="<?= $qrCodePath ?>" alt="QR Code">
        </div>

        <h3>Invoice #: <?= $invoiceNumber ?></h3>
        <p><strong>Patient:</strong> <?= htmlspecialchars($invoice['first_name'] . ' ' . $invoice['last_name']) ?><br>
           <strong>Phone:</strong> <?= htmlspecialchars($invoice['phone']) ?><br>
           <strong>Email:</strong> <?= htmlspecialchars($invoice['email']) ?><br>
           <strong>Barcode:</strong> <?= htmlspecialchars($invoice['barcode']) ?><br>
           <strong>Date:</strong> <?= date('M d, Y', strtotime($invoice['created_at'])) ?><br>
           <?php if (!empty($invoice['referral_doctor']) || !empty($invoice['referral_organisation'])): ?>
               <strong>Referred By:</strong>
               <?= htmlspecialchars($invoice['referral_doctor']) ?>
               <?= !empty($invoice['referral_organisation']) ? ' (' . htmlspecialchars($invoice['referral_organisation']) . ')' : '' ?><br>
           <?php endif; ?>
        </p>

        <table>
            <thead>
                <tr>
                    <th>Test/Service</th>
                    <th>Quantity</th>
                    <th>Unit Price</th>
                    <th>Subtotal</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($invoice_items as $item): ?>
                <tr>
                    <td><?= htmlspecialchars($item['test_name']) ?></td>
                    <td><?= $item['quantity'] ?></td>
                    <td>₦<?= number_format($item['price'], 2) ?></td>
                    <td>₦<?= number_format($item['price'] * $item['quantity'], 2) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
            <tfoot>
                <tr class="summary">
                    <td colspan="3">Total Amount</td>
                    <td>₦<?= number_format($invoice['total_amount'], 2) ?></td>
                </tr>
                <tr class="summary">
                    <td colspan="3">Discount</td>
                    <td><?= $invoice['discount'] ?>%</td>
                </tr>
                <tr class="summary">
                    <td colspan="3">Final Amount</td>
                    <td>₦<?= number_format($invoice['final_amount'], 2) ?></td>
                </tr>
                <tr class="summary">
                    <td colspan="3">Amount Paid</td>
                    <td>₦<?= number_format($total_paid, 2) ?></td>
                </tr>
                <tr class="summary">
                    <td colspan="3">Balance</td>
                    <td>₦<?= number_format($balance, 2) ?></td>
                </tr>
            </tfoot>
        </table>

        <div class="footer">
            <p>Thank you for choosing Lifeway Diagnostic Center.</p>
            <p><small>Printed on <?= date('M d, Y h:i A') ?></small></p>
        </div>
    </div>

</body>
</html>
