<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirect if not logged in or not an accountant
$allowed_roles = ['lab_technician', 'lab_manager', 'admin'];
if (!in_array($_SESSION['user_role'], $allowed_roles)) {
    header("Location: unauthorized.php");
    exit();
}
// Database connection
$host = "localhost";
$dbname = "u740329344_rlis";
$username = "u740329344_rlis";
$password = "Rlis@7030";

// MySQLi for basic connection
$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("MySQLi Connection failed: " . $conn->connect_error);
}

// PDO for queries
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);
} catch (PDOException $e) {
    die("PDO Connection failed: " . $e->getMessage());
}



// Get user data
$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

// Determine active module for sidebar highlighting
$current_module = basename(dirname($_SERVER['PHP_SELF']));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RLIS - <?= isset($pageTitle) ? $pageTitle : 'Dashboard' ?></title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- DataTables -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css">

    <style>
        /* Internal CSS for Laboratory Module */
        :root {
            --lab-primary: #2c3e50;
            --lab-secondary: #3498db;
            --lab-light: #ecf0f1;
            --lab-dark: #2c3e50;
            --lab-success: #27ae60;
            --lab-danger: #e74c3c;
            --lab-warning: #f39c12;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
        }
        
        .navbar-lab {
            background-color: var(--lab-primary) !important;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .sidebar {
            background-color: white;
            border-right: 1px solid #dee2e6;
            height: calc(100vh - 56px);
            position: sticky;
            top: 56px;
            overflow-y: auto;
        }
        
        .sidebar-sticky {
            padding-top: 1rem;
        }
        
        .sidebar .nav-link {
            color: #495057;
            border-radius: 0.25rem;
            margin-bottom: 0.25rem;
        }
        
        .sidebar .nav-link:hover, 
        .sidebar .nav-link.active {
            background-color: var(--lab-secondary);
            color: white;
        }
        
        .sidebar .nav-link i {
            margin-right: 8px;
            width: 20px;
            text-align: center;
        }
        
        .main-content {
            padding-top: 1.5rem;
            padding-bottom: 2rem;
        }
        
        .module-card {
            transition: transform 0.2s;
            border: none;
            border-radius: 0.5rem;
            box-shadow: 0 0.125rem 0.25rem rgba(0,0,0,0.075);
        }
        
        .module-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 0.5rem 1rem rgba(0,0,0,0.1);
        }
        
        .card-icon {
            font-size: 2rem;
            margin-bottom: 1rem;
        }
        
        .lab-badge {
            font-size: 0.7rem;
            vertical-align: top;
        }
        
        .breadcrumb {
            background-color: transparent;
            padding: 0.5rem 0;
        }
        
        .table-responsive {
            background-color: white;
            border-radius: 0.5rem;
            box-shadow: 0 0.125rem 0.25rem rgba(0,0,0,0.075);
        }
        
        .status-badge {
            padding: 0.35em 0.65em;
            font-size: 0.75em;
            font-weight: 700;
            border-radius: 0.25rem;
        }
        
        .badge-pending {
            background-color: #f39c12;
            color: white;
        }
        
        .badge-completed {
            background-color: #27ae60;
            color: white;
        }
        
        .badge-cancelled {
            background-color: #e74c3c;
            color: white;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                height: auto;
                position: relative;
                top: 0;
            }
            
            .main-content {
                padding-top: 1rem;
            }
        }
    </style>
</head>
<body>
    <!-- Top Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-dark navbar-lab">
        <div class="container-fluid">
            <a class="navbar-brand" href="dashboard/">
                <i class="fas fa-flask me-2"></i>
                RLIS Laboratory
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link <?= ($current_module == 'dashboard') ? 'active' : '' ?>" href="dashboard/">
                            <i class="fas fa-tachometer-alt"></i> Dashboard
                        </a>
                    </li>
                </ul>
                
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user-circle me-1"></i> 
                            <?= htmlspecialchars($user['name']) ?>
                            <span class="badge bg-light text-dark lab-badge ms-1">
                                <?= ucfirst($user['role']) ?>
                            </span>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="../profile.php"><i class="fas fa-user me-2"></i> Profile</a></li>
                            <li><a class="dropdown-item" href="../settings.php"><i class="fas fa-cog me-2"></i> Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i> Logout</a></li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#" data-bs-toggle="modal" data-bs-target="#notificationsModal">
                            <i class="fas fa-bell"></i>
                            <span class="badge bg-danger lab-badge" id="notificationBadge">0</span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Container with Sidebar and Content -->
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar - Integrated into header.php -->
            <div class="col-md-3 col-lg-2 d-md-block sidebar">
                <div class="sidebar-sticky pt-3">
                    <ul class="nav flex-column">
                        <!-- Laboratory Module Links -->
                        <li class="nav-item">
                            <a class="nav-link <?= ($current_module == 'patients') ? 'active' : '' ?>" href="../patients/">
                                <i class="fas fa-user-injured"></i> Patient Registration
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?= ($current_module == 'tests') ? 'active' : '' ?>" href="../tests/">
                                <i class="fas fa-flask"></i> Test Management
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?= ($current_module == 'billing') ? 'active' : '' ?>" href="../billing/">
                                <i class="fas fa-file-invoice-dollar"></i> Billing
                            </a>
                        </li>
                        
                        <!-- Accounts Management Link -->
                        <?php if ($user['role'] == 'admin' || $user['role'] == 'accountant'): ?>
                        <li class="nav-item">
                            <a class="nav-link <?= ($current_module == 'accounts') ? 'active' : '' ?>" href="../accounts/">
                                <i class="fas fa-calculator"></i> Accounts
                            </a>
                        </li>
                        <?php endif; ?>
                        
                        <!-- Front Desk Link -->
                        <li class="nav-item">
                            <a class="nav-link <?= ($current_module == 'frontdesk') ? 'active' : '' ?>" href="../frontdesk/">
                                <i class="fas fa-desktop"></i> Front Desk
                            </a>
                        </li>
                        
                        <!-- Reports -->
                        <li class="nav-item">
                            <a class="nav-link <?= ($current_module == 'reports') ? 'active' : '' ?>" href="../reports/">
                                <i class="fas fa-chart-bar"></i> Reports
                            </a>
                        </li>
                        
                        <!-- Admin Only Sections -->
                        <?php if ($user['role'] == 'admin' || $user['role'] == 'lab_manager'): ?>
                        <li class="nav-item mt-3">
                            <h6 class="sidebar-heading px-3 mb-1 text-muted">Administration</h6>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?= ($current_module == 'inventory') ? 'active' : '' ?>" href="../inventory/">
                                <i class="fas fa-boxes"></i> Inventory
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?= ($current_module == 'users') ? 'active' : '' ?>" href="../users/">
                                <i class="fas fa-users-cog"></i> User Management
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?= ($current_module == 'settings') ? 'active' : '' ?>" href="../settings/">
                                <i class="fas fa-sliders-h"></i> System Settings
                            </a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>

            <!-- Main Content Area -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 main-content">
                <!-- Page Header -->
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2"><?= isset($pageTitle) ? $pageTitle : 'Dashboard' ?></h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <div class="btn-group me-2">
                            <?php if (isset($actionButtons)): ?>
                                <?php foreach ($actionButtons as $button): ?>
                                    <a href="<?= $button['link'] ?>" class="btn btn-sm btn-<?= $button['type'] ?>">
                                        <i class="fas fa-<?= $button['icon'] ?> me-1"></i> <?= $button['text'] ?>
                                    </a>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <!-- Breadcrumb -->
                <nav aria-label="breadcrumb" class="mb-4">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="dashboard/"><i class="fas fa-home"></i></a></li>
                        <?php if (isset($breadcrumbs)): ?>
                            <?php foreach ($breadcrumbs as $crumb): ?>
                                <li class="breadcrumb-item <?= $crumb['active'] ? 'active' : '' ?>">
                                    <?php if (!$crumb['active']): ?>
                                        <a href="<?= $crumb['link'] ?>"><?= $crumb['text'] ?></a>
                                    <?php else: ?>
                                        <?= $crumb['text'] ?>
                                    <?php endif; ?>
                                </li>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </ol>
                </nav>
                
                <!-- Alerts Section -->
                <div id="alertsContainer">
                    <?php if (isset($_SESSION['success'])): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <i class="fas fa-check-circle me-2"></i>
                            <?= $_SESSION['success'] ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                        <?php unset($_SESSION['success']); ?>
                    <?php endif; ?>
                    
                    <?php if (isset($_SESSION['error'])): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <i class="fas fa-exclamation-circle me-2"></i>
                            <?= $_SESSION['error'] ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                        <?php unset($_SESSION['error']); ?>
                    <?php endif; ?>
                    
                    <?php if (isset($_SESSION['warning'])): ?>
                        <div class="alert alert-warning alert-dismissible fade show" role="alert">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            <?= $_SESSION['warning'] ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                        <?php unset($_SESSION['warning']); ?>
                    <?php endif; ?>
                </div>