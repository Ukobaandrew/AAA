<?php
require_once '../models/ChatModel.php';

class ChatController {
    private $chatModel;

    public function __construct() {
        $this->chatModel = new ChatModel();
    }

    // Send a new message
    public function sendMessage($senderId, $receiverId, $message, $departmentId = null, $file = null) {
        return $this->chatModel->sendMessage($senderId, $receiverId, $message, $departmentId, $file);
    }

    // Get messages between two users
    public function getMessages($user1Id, $user2Id) {
        return $this->chatModel->getMessages($user1Id, $user2Id);
    }

    // Get messages for a department (Group Chat)
    public function getDepartmentMessages($departmentId) {
        return $this->chatModel->getDepartmentMessages($departmentId);
    }

    // Delete a message (only sender or admin can delete)
    public function deleteMessage($messageId, $userId) {
        return $this->chatModel->deleteMessage($messageId, $userId);
    }
}

// Example usage
$chatController = new ChatController();
// $chatController->sendMessage(1, 2, "Hello, how are you?", null, "attachment.pdf");
?>
