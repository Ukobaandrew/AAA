<?php

class MachineController {
    private $conn;

    public function __construct($db) {
        $this->conn = $db;
    }

    // Get all machines
    public function getMachines() {
        $query = "SELECT * FROM machine_integrations";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Get machine by ID
    public function getMachineById($id) {
        $query = "SELECT * FROM machine_integrations WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Add a new machine
    public function addMachine($machine_name, $ip_address, $port, $status = 'disconnected') {
        $query = "INSERT INTO machine_integrations (machine_name, ip_address, port, status) VALUES (?, ?, ?, ?)";
        $stmt = $this->conn->prepare($query);
        return $stmt->execute([$machine_name, $ip_address, $port, $status]);
    }

    // Update machine details
    public function updateMachine($id, $machine_name, $ip_address, $port, $status) {
        $query = "UPDATE machine_integrations SET machine_name = ?, ip_address = ?, port = ?, status = ? WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        return $stmt->execute([$machine_name, $ip_address, $port, $status, $id]);
    }

    // Delete machine
    public function deleteMachine($id) {
        $query = "DELETE FROM machine_integrations WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        return $stmt->execute([$id]);
    }

    // Update machine connection status
    public function updateMachineStatus($id, $status) {
        $query = "UPDATE machine_integrations SET status = ? WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        return $stmt->execute([$status, $id]);
    }
}