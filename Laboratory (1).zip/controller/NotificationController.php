<?php

class NotificationController {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    // Send a notification
    public function sendNotification($user_id, $message) {
        $stmt = $this->db->prepare("INSERT INTO notifications (user_id, message, status) VALUES (?, ?, 'unread')");
        return $stmt->execute([$user_id, $message]);
    }

    // Retrieve all notifications for a user
    public function getNotifications($user_id) {
        $stmt = $this->db->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC");
        $stmt->execute([$user_id]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Mark notification as read
    public function markAsRead($notification_id) {
        $stmt = $this->db->prepare("UPDATE notifications SET status = 'read' WHERE id = ?");
        return $stmt->execute([$notification_id]);
    }

    // Delete a notification
    public function deleteNotification($notification_id) {
        $stmt = $this->db->prepare("DELETE FROM notifications WHERE id = ?");
        return $stmt->execute([$notification_id]);
    }
}
