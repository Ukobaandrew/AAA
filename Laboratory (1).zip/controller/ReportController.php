<?php
require_once '../models/ReportModel.php';

class ReportController {
    private $reportModel;

    public function __construct() {
        $this->reportModel = new ReportModel();
    }

    // Upload a new lab report
    public function uploadReport($patientId, $testId, $resultData, $technicianId) {
        if (empty($patientId) || empty($testId) || empty($resultData) || empty($technicianId)) {
            return ["status" => "error", "message" => "All fields are required."];
        }
        return $this->reportModel->uploadReport($patientId, $testId, $resultData, $technicianId);
    }

    // Verify a result before final approval
    public function verifyResult($resultId, $status, $comments = null) {
        if (!in_array($status, ['verified', 'rejected'])) {
            return ["status" => "error", "message" => "Invalid status value."];
        }
        return $this->reportModel->updateResultStatus($resultId, $status, $comments);
    }

    // Approve a test result (Doctor's Approval)
    public function approveResult($resultId, $doctorId, $signature) {
        if (empty($resultId) || empty($doctorId) || empty($signature)) {
            return ["status" => "error", "message" => "All fields are required for approval."];
        }
        return $this->reportModel->approveResult($resultId, $doctorId, $signature);
    }

    // Get all reports
    public function getAllReports() {
        return $this->reportModel->getAllReports();
    }

    // Get reports for a specific patient
    public function getReportsByPatient($patientId) {
        if (empty($patientId)) {
            return ["status" => "error", "message" => "Patient ID is required."];
        }
        return $this->reportModel->getReportsByPatient($patientId);
    }

    // Get reports by status
    public function getReportsByStatus($status) {
        if (!in_array($status, ['pending', 'verified', 'approved', 'rejected'])) {
            return ["status" => "error", "message" => "Invalid status filter."];
        }
        return $this->reportModel->getReportsByStatus($status);
    }

    // Delete a lab report
    public function deleteReport($reportId) {
        if (empty($reportId)) {
            return ["status" => "error", "message" => "Report ID is required."];
        }
        return $this->reportModel->deleteReport($reportId);
    }
}

// Example usage
$reportController = new ReportController();
// $reportController->uploadReport(1, 5, "Hemoglobin: 13.5 g/dL", 3);
?>