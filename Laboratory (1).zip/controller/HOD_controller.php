<?php
require_once '../models/HODModel.php';
require_once '../models/TechnicianModel.php';
require_once '../models/MachineModel.php';
require_once '../models/ReportModel.php';

class HODController {
    private $hodModel;
    private $techModel;
    private $machineModel;
    private $reportModel;

    public function __construct() {
        $this->hodModel = new HODModel();
        $this->techModel = new TechnicianModel();
        $this->machineModel = new MachineModel();
        $this->reportModel = new ReportModel();
    }

    // Create Lab Domain
    public function createDomain($labName, $description) {
        return $this->hodModel->createLabDomain($labName, $description);
    }

    // Connect a machine to the lab
    public function connectMachine($machineName, $ipAddress, $port) {
        return $this->machineModel->addMachine($machineName, $ipAddress, $port);
    }

    // Assign a technician to the lab
    public function assignTechnician($name, $email, $role) {
        return $this->techModel->addTechnician($name, $email, $role);
    }

    // Manage rotation schedules
    public function setRotationSchedule($techId, $shiftTime) {
        return $this->techModel->setRotation($techId, $shiftTime);
    }

    // Verify lab results
    public function verifyResult($resultId, $status, $comments) {
        return $this->reportModel->updateResultStatus($resultId, $status, $comments);
    }

    // Upload lab test templates
    public function uploadTemplate($templateName, $filePath) {
        return $this->hodModel->saveTemplate($templateName, $filePath);
    }
}

// Example usage
$hod = new HODController();
// $hod->createDomain("Hematology", "Handles blood-related tests.");
?>
