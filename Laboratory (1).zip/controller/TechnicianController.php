<?php

class TechnicianController {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    // Fetch all test results assigned to the logged-in technician
    public function getAssignedTests($technician_id) {
        $query = "SELECT tr.id, p.first_name, p.last_name, t.name AS test_name, tr.result, tr.status, tr.sample_status, tr.hod_verified 
                  FROM test_results tr 
                  JOIN patients p ON tr.patient_id = p.id 
                  JOIN tests t ON tr.test_id = t.id 
                  WHERE tr.technician_id = ? ";
        $stmt = $this->db->prepare($query);
        $stmt->execute([$technician_id]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Update test result by technician
    public function updateTestResult($test_result_id, $result, $status, $technician_id) {
        $query = "UPDATE test_results SET result = ?, status = ?, assigned_to = ? WHERE id = ?";
        $stmt = $this->db->prepare($query);
        return $stmt->execute([$result, $status, $technician_id, $test_result_id]);
    }

    // Mark sample status
    public function updateSampleStatus($test_result_id, $sample_status) {
        $query = "UPDATE test_results SET sample_status = ? WHERE id = ?";
        $stmt = $this->db->prepare($query);
        return $stmt->execute([$sample_status, $test_result_id]);
    }

    // Fetch technician performance report
    public function getPerformanceReport($technician_id) {
        $query = "SELECT COUNT(*) AS total_tests, 
                         SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) AS approved_tests, 
                         SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) AS pending_tests
                  FROM test_results 
                  WHERE technician_id = ?";
        $stmt = $this->db->prepare($query);
        $stmt->execute([$technician_id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Fetch all pending tests for verification by HOD
    public function getPendingVerification() {
        $query = "SELECT tr.id, p.first_name, p.last_name, t.name AS test_name, tr.result, tr.status, tr.hod_verified 
                  FROM test_results tr 
                  JOIN patients p ON tr.patient_id = p.id 
                  JOIN tests t ON tr.test_id = t.id 
                  WHERE tr.hod_verified = 'pending'";
        $stmt = $this->db->query($query);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
