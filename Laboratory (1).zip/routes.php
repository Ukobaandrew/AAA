<?php
// routes.php - Define URL routes for the lab system

$routes = [
    'dashboard' => 'views/dashboard.php',
    'departments' => 'views/departments.php',
    'users' => 'views/users.php',
    'patients' => 'views/patients.php',
    'tests' => 'views/tests.php',
    'test_results' => 'views/test_results.php',
    'invoices' => 'views/invoices.php',
    'payments' => 'views/payments.php',
    'notifications' => 'views/notifications.php',
    'audit_logs' => 'views/audit_logs.php',
    'inventory' => 'views/inventory.php',
    'machine_integrations' => 'views/machine_integrations.php',
    'appointments' => 'views/appointments.php',
    'purchase_orders' => 'views/purchase_orders.php',
    'settings' => 'views/settings.php',
];

function route($page)
{
    global $routes;
    if (array_key_exists($page, $routes)) {
        require $routes[$page];
    } else {
        require 'views/404.php'; // Load a 404 page if the route is not found
    }
}

// Example Usage
if (isset($_GET['page'])) {
    route($_GET['page']);
} else {
    route('dashboard'); // Default route
}
?>
