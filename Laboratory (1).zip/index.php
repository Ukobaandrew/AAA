<?php
require 'config.php'; // Database connection

// Fetch Departments
$departments = $conn->query("SELECT * FROM departments");

// Fetch Lab Technicians & HODs
$lab_staff = $conn->query("SELECT users.id, users.name, users.role, departments.name AS department FROM users 
                           LEFT JOIN departments ON users.department_id = departments.id
                           WHERE users.role IN ('lab_technician', 'admin')");

// Fetch Tests
$tests = $conn->query("SELECT tests.id, tests.name, tests.price, departments.name AS department FROM tests 
                      LEFT JOIN departments ON tests.department_id = departments.id");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Lab Module - Main Entry</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h2>Lab Module Dashboard</h2>
    
    <section>
        <h3>Departments</h3>
        <ul>
            <?php while ($dept = $departments->fetch_assoc()) { ?>
                <li><?php echo htmlspecialchars($dept['name']); ?></li>
            <?php } ?>
        </ul>
    </section>
    
    <section>
        <h3>Lab Staff (Technicians & HODs)</h3>
        <ul>
            <?php while ($staff = $lab_staff->fetch_assoc()) { ?>
                <li><?php echo htmlspecialchars($staff['name']) . " - " . htmlspecialchars($staff['role']) . " (" . htmlspecialchars($staff['department']) . ")"; ?></li>
            <?php } ?>
        </ul>
    </section>
    
    <section>
        <h3>Available Tests</h3>
        <table border="1">
            <tr>
                <th>Test Name</th>
                <th>Department</th>
                <th>Price</th>
            </tr>
            <?php while ($test = $tests->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo htmlspecialchars($test['name']); ?></td>
                    <td><?php echo htmlspecialchars($test['department']); ?></td>
                    <td><?php echo htmlspecialchars($test['price']); ?></td>
                </tr>
            <?php } ?>
        </table>
    </section>
    
    <footer>
        <a href="add_test.php">Add New Test</a> | 
        <a href="manage_departments.php">Manage Departments</a> | 
        <a href="view_results.php">View Test Results</a>
    </footer>
</body>
</html>