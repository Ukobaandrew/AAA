<?php
// Lab HOD Dashboard
session_start();
require_once '../config.php';
require_once '../helpers/functions.php';

// Fetch lab statistics
$total_tests = getTotalTests($conn);
$pending_tests = getPendingTests($conn);
$completed_tests = getCompletedTests($conn);
$daily_test_stats = getDailyTestStats($conn);
$audit_logs = getAuditLogs($conn);

function getTotalTests($conn) {
    $query = "SELECT COUNT(*) AS total FROM lab_tests";
    return mysqli_fetch_assoc(mysqli_query($conn, $query))['total'];
}

function getPendingTests($conn) {
    $query = "SELECT COUNT(*) AS pending FROM lab_tests WHERE status = 'pending'";
    return mysqli_fetch_assoc(mysqli_query($conn, $query))['pending'];
}

function getCompletedTests($conn) {
    $query = "SELECT COUNT(*) AS completed FROM lab_tests WHERE status = 'completed'";
    return mysqli_fetch_assoc(mysqli_query($conn, $query))['completed'];
}

function getDailyTestStats($conn) {
    $query = "SELECT DATE(test_date) AS date, COUNT(*) AS count FROM lab_tests GROUP BY DATE(test_date) ORDER BY date DESC LIMIT 7";
    return mysqli_query($conn, $query);
}

function getAuditLogs($conn) {
    $query = "SELECT user, action, timestamp FROM audit_logs ORDER BY timestamp DESC LIMIT 10";
    return mysqli_query($conn, $query);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lab HOD Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        .wrapper {
            display: flex;
            flex: 1;
        }
        .sidebar {
            width: 250px;
            background: #343a40;
            color: white;
            padding: 20px;
        }
        .content {
            flex: 1;
            padding: 20px;
        }
        .footer {
            text-align: center;
            padding: 10px;
            background: #343a40;
            color: white;
        }
        @media (max-width: 760px) {
            .sidebar { width: 100px; }
        }
        @media (max-width: 550px) {
            .sidebar { display: none; }
        }
        @media (max-width: 365px) {
            .content { padding: 10px; }
        }
    </style>
</head>
<body>
    <header class="bg-dark text-white text-center py-3">
        <h2>Lab HOD Dashboard</h2>
    </header>
    <div class="wrapper">
        <nav class="sidebar">
            <ul class="list-unstyled">
                <li><a href="#" class="text-white">Home</a></li>
                <li><a href="#" class="text-white">Reports</a></li>
                <li><a href="#" class="text-white">Settings</a></li>
            </ul>
        </nav>
        <main class="content">
            <h3>Dashboard Overview</h3>
            <div class="row">
                <div class="col-md-4">
                    <div class="card text-white bg-primary mb-3">
                        <div class="card-header">Total Tests</div>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo $total_tests; ?></h5>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card text-white bg-warning mb-3">
                        <div class="card-header">Pending Tests</div>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo $pending_tests; ?></h5>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card text-white bg-success mb-3">
                        <div class="card-header">Completed Tests</div>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo $completed_tests; ?></h5>
                        </div>
                    </div>
                </div>
            </div>
            <h3>Daily Test Statistics</h3>
            <canvas id="testChart"></canvas>
            <script>
                var ctx = document.getElementById('testChart').getContext('2d');
                var testChart = new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: [<?php while ($row = mysqli_fetch_assoc($daily_test_stats)) echo "'".$row['date']."',"; ?>],
                        datasets: [{
                            label: 'Tests Per Day',
                            data: [<?php mysqli_data_seek($daily_test_stats, 0); while ($row = mysqli_fetch_assoc($daily_test_stats)) echo $row['count'].","; ?>],
                            borderColor: 'blue',
                            fill: false
                        }]
                    },
                });
            </script>
            <h3>Recent Audit Logs</h3>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>User</th>
                        <th>Action</th>
                        <th>Timestamp</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($log = mysqli_fetch_assoc($audit_logs)) { ?>
                        <tr>
                            <td><?php echo $log['user']; ?></td>
                            <td><?php echo $log['action']; ?></td>
                            <td><?php echo $log['timestamp']; ?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </main>
    </div>
    <footer class="footer">&copy; 2025 Dashboard System</footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
