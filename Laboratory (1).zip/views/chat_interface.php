<?php
session_start();
require 'db_connect.php'; // Ensure this file connects to your database

// Fetch current user details
$user_id = $_SESSION['user_id'] ?? null;
$department_id = $_SESSION['department_id'] ?? null;
if (!$user_id || !$department_id) {
    die("Unauthorized access");
}

// Handle new messages
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['message'])) {
    $message = trim($_POST['message']);
    $receiver_department_id = $_POST['receiver_department_id'];

    if (!empty($message)) {
        $stmt = $conn->prepare("INSERT INTO chat_messages (sender_id, receiver_department_id, message) VALUES (?, ?, ?)");
        $stmt->bind_param("iis", $user_id, $receiver_department_id, $message);
        $stmt->execute();
    }
}

// Fetch chat messages
$messages = $conn->query("SELECT chat_messages.*, users.name AS sender_name FROM chat_messages JOIN users ON chat_messages.sender_id = users.id WHERE receiver_department_id = $department_id ORDER BY created_at DESC LIMIT 50")->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Unit Chat</title>
    <style>
        body { font-family: Arial, sans-serif; }
        .chat-box { width: 50%; margin: auto; border: 1px solid #ccc; padding: 10px; }
        .message { margin-bottom: 10px; padding: 5px; border-radius: 5px; }
        .sent { background: #dcf8c6; text-align: right; }
        .received { background: #f1f1f1; text-align: left; }
    </style>
</head>
<body>
    <div class="chat-box">
        <h3>Real-time Chat</h3>
        <div id="chat-messages">
            <?php foreach ($messages as $msg): ?>
                <div class="message <?= $msg['sender_id'] == $user_id ? 'sent' : 'received' ?>">
                    <strong><?= htmlspecialchars($msg['sender_name']) ?>:</strong> <?= htmlspecialchars($msg['message']) ?>
                    <small>(<?= $msg['created_at'] ?>)</small>
                </div>
            <?php endforeach; ?>
        </div>
        <form method="POST">
            <select name="receiver_department_id" required>
                <option value="">Select Department</option>
                <?php 
                $departments = $conn->query("SELECT * FROM departments");
                while ($dept = $departments->fetch_assoc()) {
                    echo "<option value='" . $dept['id'] . "'>" . $dept['name'] . "</option>";
                }
                ?>
            </select>
            <input type="text" name="message" placeholder="Type a message" required>
            <button type="submit">Send</button>
        </form>
    </div>
</body>
</html>
