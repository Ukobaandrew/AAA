<?php
require_once '../config/db.php'; // Ensure you have a database connection

// Fetch lab technicians
$labTechniciansQuery = "SELECT id, name FROM users WHERE role = 'lab_technician' AND status = 'active'";
$labTechnicians = $conn->query($labTechniciansQuery);

// Fetch existing shift rotations
$shiftQuery = "SELECT users.id AS user_id, users.name AS technician_name, shifts.shift_time 
               FROM users 
               LEFT JOIN shifts ON users.id = shifts.user_id 
               WHERE users.role = 'lab_technician'";
$shifts = $conn->query($shiftQuery);

// Handle shift assignment
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $technicianId = $_POST['technician_id'];
    $shiftTime = $_POST['shift_time'];
    
    // Check if technician already has a shift
    $checkShift = $conn->prepare("SELECT * FROM shifts WHERE user_id = ?");
    $checkShift->bind_param("i", $technicianId);
    $checkShift->execute();
    $result = $checkShift->get_result();
    
    if ($result->num_rows > 0) {
        // Update existing shift
        $updateShift = $conn->prepare("UPDATE shifts SET shift_time = ? WHERE user_id = ?");
        $updateShift->bind_param("si", $shiftTime, $technicianId);
        $updateShift->execute();
    } else {
        // Assign new shift
        $assignShift = $conn->prepare("INSERT INTO shifts (user_id, shift_time) VALUES (?, ?)");
        $assignShift->bind_param("is", $technicianId, $shiftTime);
        $assignShift->execute();
    }
    
    header("Location: set_rotation.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Set Lab Work Rotation</title>
</head>
<body>
    <h2>Lab Work Shift Rotation</h2>
    
    <form method="POST">
        <label for="technician">Select Technician:</label>
        <select name="technician_id" required>
            <?php while ($tech = $labTechnicians->fetch_assoc()): ?>
                <option value="<?= $tech['id'] ?>"> <?= $tech['name'] ?> </option>
            <?php endwhile; ?>
        </select>
        
        <label for="shift_time">Shift Time:</label>
        <select name="shift_time" required>
            <option value="Morning">Morning (8 AM - 2 PM)</option>
            <option value="Afternoon">Afternoon (2 PM - 8 PM)</option>
            <option value="Night">Night (8 PM - 8 AM)</option>
        </select>
        
        <button type="submit">Assign Shift</button>
    </form>
    
    <h3>Existing Rotations</h3>
    <table border="1">
        <tr>
            <th>Technician</th>
            <th>Shift Time</th>
        </tr>
        <?php while ($shift = $shifts->fetch_assoc()): ?>
            <tr>
                <td><?= $shift['technician_name'] ?></td>
                <td><?= $shift['shift_time'] ?></td>
            </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>
