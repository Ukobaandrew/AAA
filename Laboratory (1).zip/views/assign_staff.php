<?php
require 'config.php'; // Include database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT); // Secure password
    $department_id = $_POST['department_id'];
    $role = 'lab_technician'; // Default role for new staff

    // Check if email already exists
    $checkEmail = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $checkEmail->bind_param("s", $email);
    $checkEmail->execute();
    $checkEmail->store_result();
    
    if ($checkEmail->num_rows > 0) {
        echo "Error: Email already exists.";
        exit;
    }
    
    $checkEmail->close();

    // Insert the new technician
    $stmt = $conn->prepare("INSERT INTO users (name, email, password, role, department_id) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssi", $name, $email, $password, $role, $department_id);
    
    if ($stmt->execute()) {
        echo "New technician assigned successfully.";
    } else {
        echo "Error: " . $stmt->error;
    }
    
    $stmt->close();
}

// Fetch departments for dropdown
$departments = $conn->query("SELECT id, name FROM departments");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Assign New Technician</title>
</head>
<body>
    <h2>Assign New Technician</h2>
    <form method="POST" action="">
        <label>Name:</label>
        <input type="text" name="name" required><br>

        <label>Email:</label>
        <input type="email" name="email" required><br>

        <label>Password:</label>
        <input type="password" name="password" required><br>

        <label>Department:</label>
        <select name="department_id" required>
            <option value="">Select Department</option>
            <?php while ($row = $departments->fetch_assoc()) { ?>
                <option value="<?php echo $row['id']; ?>"><?php echo $row['name']; ?></option>
            <?php } ?>
        </select><br>

        <button type="submit">Assign Technician</button>
    </form>
</body>
</html>