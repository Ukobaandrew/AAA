<?php
require 'db_connection.php'; // Ensure this file connects to your database

function applyFormula($formula, $values) {
    extract($values); // Extract variable names dynamically
    try {
        eval('$result = ' . $formula . ';'); // Evaluates the formula
        return $result;
    } catch (Throwable $e) {
        return 'Error in calculation';
    }
}

$query = "SELECT tr.id, tr.test_id, tr.result, tf.formula FROM test_results tr
          JOIN test_formulas tf ON tr.test_id = tf.test_id
          WHERE tr.status = 'pending'";

$results = $conn->query($query);

if ($results->num_rows > 0) {
    while ($row = $results->fetch_assoc()) {
        $testResultId = $row['id'];
        $formula = $row['formula'];
        
        // Assuming results are stored as JSON key-value pairs
        $values = json_decode($row['result'], true);
        
        if ($values && is_array($values)) {
            $calculatedResult = applyFormula($formula, $values);
            
            // Update the test result
            $updateQuery = "UPDATE test_results SET result = ?, status = 'verified' WHERE id = ?";
            $stmt = $conn->prepare($updateQuery);
            $stmt->bind_param("si", $calculatedResult, $testResultId);
            $stmt->execute();
            $stmt->close();
        }
    }
    echo "Formulas applied successfully!";
} else {
    echo "No pending test results with formulas found.";
}

$conn->close();
?>
