<?php
session_start();
include '../config/db.php'; // Database connection

// Ensure user is logged in and is an HOD
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'hod') {
    header("Location: ../login.php");
    exit();
}

$hod_id = $_SESSION['user_id'];

// Fetch department details
$query = "SELECT * FROM departments WHERE hod_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $hod_id);
$stmt->execute();
$department = $stmt->get_result()->fetch_assoc();
$department_id = $department['id'];
$department_name = $department['name'];

// Fetch statistics
$total_tests = $conn->query("SELECT COUNT(*) as count FROM test_results WHERE department_id = $department_id")->fetch_assoc()['count'];
$pending_tests = $conn->query("SELECT COUNT(*) as count FROM test_results WHERE department_id = $department_id AND status = 'pending'")->fetch_assoc()['count'];
$approved_tests = $conn->query("SELECT COUNT(*) as count FROM test_results WHERE department_id = $department_id AND status = 'approved'")->fetch_assoc()['count'];
$rejected_tests = $conn->query("SELECT COUNT(*) as count FROM test_results WHERE department_id = $department_id AND status = 'rejected'")->fetch_assoc()['count'];

// Fetch test names and counts for chart
$test_data = $conn->query("SELECT name, COUNT(*) as count FROM tests WHERE department_id = $department_id GROUP BY name");
$test_labels = [];
$test_counts = [];
while ($row = $test_data->fetch_assoc()) {
    $test_labels[] = $row['name'];
    $test_counts[] = $row['count'];
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HOD Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav class="col-md-3 col-lg-2 d-md-block bg-dark sidebar text-white p-3">
                <h4><?php echo $department_name; ?> Dashboard</h4>
                <ul class="nav flex-column">
                    <li class="nav-item"><a href="#" class="nav-link text-white">Overview</a></li>
                    <li class="nav-item"><a href="#" class="nav-link text-white">Manage Tests</a></li>
                    <li class="nav-item"><a href="#" class="nav-link text-white">Reports</a></li>
                    <li class="nav-item"><a href="logout.php" class="nav-link text-danger">Logout</a></li>
                </ul>
            </nav>
            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h2>Overview</h2>
                </div>
                <div class="row">
                    <div class="col-md-3">
                        <div class="card bg-info text-white p-3">
                            <h5>Total Tests</h5>
                            <h3><?php echo $total_tests; ?></h3>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card bg-warning text-white p-3">
                            <h5>Pending</h5>
                            <h3><?php echo $pending_tests; ?></h3>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card bg-success text-white p-3">
                            <h5>Approved</h5>
                            <h3><?php echo $approved_tests; ?></h3>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card bg-danger text-white p-3">
                            <h5>Rejected</h5>
                            <h3><?php echo $rejected_tests; ?></h3>
                        </div>
                    </div>
                </div>
                <div class="row mt-4">
                    <div class="col-md-6">
                        <canvas id="barChart"></canvas>
                    </div>
                    <div class="col-md-6">
                        <canvas id="pieChart"></canvas>
                    </div>
                </div>
            </main>
        </div>
    </div>
    <script>
        var ctxBar = document.getElementById('barChart').getContext('2d');
        new Chart(ctxBar, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($test_labels); ?>,
                datasets: [{
                    label: 'Tests Conducted',
                    data: <?php echo json_encode($test_counts); ?>,
                    backgroundColor: 'rgba(54, 162, 235, 0.5)'
                }]
            }
        });

        var ctxPie = document.getElementById('pieChart').getContext('2d');
        new Chart(ctxPie, {
            type: 'pie',
            data: {
                labels: ['Pending', 'Approved', 'Rejected'],
                datasets: [{
                    data: [<?php echo $pending_tests; ?>, <?php echo $approved_tests; ?>, <?php echo $rejected_tests; ?>],
                    backgroundColor: ['#ffc107', '#28a745', '#dc3545']
                }]
            }
        });
    </script>
</body>
</html>