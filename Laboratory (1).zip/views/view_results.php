<?php
include '../config/db.php'; // Database connection

// Fetch patient test results
$query = "
    SELECT 
        tr.id, 
        p.first_name, p.last_name, p.barcode,
        t.name AS test_name, 
        tr.result, tr.status, tr.sample_status, 
        u.name AS technician, d.name AS doctor 
    FROM test_results tr
    JOIN patients p ON tr.patient_id = p.id
    JOIN tests t ON tr.test_id = t.id
    LEFT JOIN users u ON tr.technician_id = u.id
    LEFT JOIN users d ON tr.doctor_id = d.id
    ORDER BY tr.created_at DESC
";
$result = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Test Results</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-4">
    <h2 class="text-center">Patient Lab Test Results</h2>
    <table class="table table-bordered table-striped">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Patient</th>
                <th>Barcode</th>
                <th>Test</th>
                <th>Result</th>
                <th>Status</th>
                <th>Sample Status</th>
                <th>Technician</th>
                <th>Doctor</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= $row['id'] ?></td>
                    <td><?= $row['first_name'] . ' ' . $row['last_name'] ?></td>
                    <td><?= $row['barcode'] ?></td>
                    <td><?= $row['test_name'] ?></td>
                    <td><?= $row['result'] ?: 'Pending' ?></td>
                    <td>
                        <span class="badge bg-<?php 
                            echo ($row['status'] == 'approved') ? 'success' : 
                                 ($row['status'] == 'verified' ? 'warning' : 'danger');
                        ?>">
                            <?= ucfirst($row['status']) ?>
                        </span>
                    </td>
                    <td><?= ucfirst($row['sample_status']) ?></td>
                    <td><?= $row['technician'] ?: 'N/A' ?></td>
                    <td><?= $row['doctor'] ?: 'N/A' ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>
</body>
</html>
