<?php
session_start();
include '../config/db.php'; // Include your database connection

// Handle file upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['template'])) {
    $file = $_FILES['template'];
    $allowedExtensions = ['pdf', 'doc', 'docx', 'xlsx'];
    $uploadDir = 'uploads/templates/';

    // Ensure the upload directory exists
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }

    $fileExt = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($fileExt, $allowedExtensions)) {
        $_SESSION['error'] = 'Invalid file format. Only PDF, DOC, DOCX, and XLSX allowed.';
    } elseif ($file['size'] > 5 * 1024 * 1024) { // 5MB max
        $_SESSION['error'] = 'File size exceeds 5MB.';
    } else {
        $fileName = uniqid() . '.' . $fileExt;
        $filePath = $uploadDir . $fileName;
        if (move_uploaded_file($file['tmp_name'], $filePath)) {
            $stmt = $conn->prepare("INSERT INTO lab_templates (file_name, file_path, uploaded_by) VALUES (?, ?, ?)");
            $stmt->bind_param("ssi", $file['name'], $filePath, $_SESSION['user_id']);
            $stmt->execute();
            $stmt->close();
            $_SESSION['success'] = 'Template uploaded successfully.';
        } else {
            $_SESSION['error'] = 'Failed to upload file.';
        }
    }
    header("Location: upload_template.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Lab Report Templates</title>
    <link rel="stylesheet" href="../assets/styles.css">
</head>
<body>
    <h2>Upload Predefined Lab Report Templates</h2>
    <?php if (isset($_SESSION['error'])): ?>
        <p style="color: red;"> <?= $_SESSION['error']; unset($_SESSION['error']); ?> </p>
    <?php endif; ?>
    <?php if (isset($_SESSION['success'])): ?>
        <p style="color: green;"> <?= $_SESSION['success']; unset($_SESSION['success']); ?> </p>
    <?php endif; ?>

    <form action="" method="POST" enctype="multipart/form-data">
        <input type="file" name="template" required>
        <button type="submit">Upload Template</button>
    </form>
</body>
</html>