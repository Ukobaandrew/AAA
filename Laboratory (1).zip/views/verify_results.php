<?php
session_start();

// Database configuration
$host = "localhost";
$dbname = "u876286375_Ris_Lis";
$username = "u876286375_Ris_Lis";
$password = "Rlis@7030";

// Create connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$conn->set_charset("utf8");

// Check if user is logged in and is HOD
// if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'doctor') {
//     header('Location: login.php');
//     exit();
// }

// $hod_id = $_SESSION['user_id'];

// Fetch test results that need HOD verification
$query = "SELECT tr.id, p.first_name, p.last_name, t.name AS test_name, tr.result, tr.status, tr.hod_verified, tr.rejection_reason 
          FROM test_results tr
          JOIN patients p ON tr.patient_id = p.id
          JOIN tests t ON tr.test_id = t.id
          JOIN users u ON u.id = tr.technician_id
          WHERE u.department_id = (SELECT department_id FROM users WHERE id = ?) 
          AND tr.hod_verified = 'pending'";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $hod_id);
$stmt->execute();
$results = $stmt->get_result();

// Handle Approve or Reject Action
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $result_id = $_POST['result_id'];
    $action = $_POST['action'];
    $rejection_reason = isset($_POST['rejection_reason']) ? $_POST['rejection_reason'] : null;

    if ($action === 'approve') {
        $update_query = "UPDATE test_results SET hod_verified = 'verified' WHERE id = ?";
    } elseif ($action === 'reject' && !empty($rejection_reason)) {
        $update_query = "UPDATE test_results SET hod_verified = 'rejected', rejection_reason = ? WHERE id = ?";
    }

    $stmt = $conn->prepare($update_query);
    if ($action === 'reject') {
        $stmt->bind_param("si", $rejection_reason, $result_id);
    } else {
        $stmt->bind_param("i", $result_id);
    }
    $stmt->execute();
    header("Location: verify_results.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify Test Results</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .sidebar {
            position: fixed;
            left: -250px;
            top: 0;
            width: 250px;
            height: 100%;
            background: #cccc;
            transition: left 0.3s ease;
            padding-top: 60px;
        }
        .sidebar.open {
            left: 0;
        }
        .sidebar ul {
            list-style: none;
            padding: 0;
        }
        .sidebar ul li {
            padding: 10px;
        }
        .sidebar ul li a {
            color: white;
            text-decoration: none;
            display: block;
        }
        .close-toggle{
             position: absolute;
            top: 15px;
            left: 220px;
            font-size: 24px;
            cursor: pointer;
            color: #343a40;
        }
        .menu-toggle {
            position: absolute;
            top: 15px;
            left: 15px;
            font-size: 24px;
            cursor: pointer;
            color: #343a40;
        }
        .header {
            background: #007bff;
            color: white;
            padding: 15px;
            text-align: center;
            font-size: 1.5em;
        }
        @media (max-width: 760px) {
            .header {
                font-size: 1.2em;
            }
            .container{
               font-size: 1em; 
            }
            h2{
                font-size: 0.99em;
                text-align: center;
            }
        }
        @media (max-width: 550px) {
            .header {
                font-size: 1em;
            }
        }
        @media (max-width: 350px) {
            .header {
                font-size: 0.9em;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <i class="fas fa-bars menu-toggle" onclick="toggleSidebar()"></i>
        Verify Test Results
        <!--   <ul>-->
        <!--    <li><a href="#">Home</a></li>-->
        <!--    <li><a href="#">Verify Results</a></li>-->
        <!--    <li><a href="logout.php">Logout</a></li>-->
        <!--</ul>-->
    </div>
    <nav class="sidebar" id="sidebar">
        <i class="fas fa-close close-toggle" onclick="toggleSidebar()"></i>
        <ul>
            
            <li><a href="#">Home</a></li>
            <li><a href="#">Verify Results</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav>
    <main class="container mt-4">
        <h2>HOD Panel - Verify Test Results</h2>
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead class="table-dark">
                    <tr>
                                <th>Patient</th>
                                <th>Test</th>
                                <th>Result</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = $results->fetch_assoc()) { ?>
                                <tr>
                                    <td><?= htmlspecialchars($row['first_name'] . ' ' . $row['last_name']); ?></td>
                                    <td><?= htmlspecialchars($row['test_name']); ?></td>
                                    <td><?= htmlspecialchars($row['result']); ?></td>
                                    <td><?= htmlspecialchars($row['hod_verified']); ?></td>
                                    <td>
                                        <form method="post" class="d-inline-block">
                                            <input type="hidden" name="result_id" value="<?= $row['id']; ?>">
                                            <button type="submit" name="action" value="approve" class="btn btn-success btn-sm">Approve</button>
                                        </form>
                                        <button class="btn btn-danger btn-sm" onclick="showRejectForm(<?= $row['id']; ?>)">Reject</button>
                                        <div id="reject-form-<?= $row['id']; ?>" style="display:none; margin-top:10px;">
                                            <form method="post">
                                                <input type="hidden" name="result_id" value="<?= $row['id']; ?>">
                                                <textarea class="form-control my-2" name="rejection_reason" placeholder="Enter reason"></textarea>
                                                <button type="submit" name="action" value="reject" class="btn btn-warning btn-sm">Confirm Rejection</button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
                <footer class="text-center py-3 mt-4 border-top">
                    <p>&copy; <?= date('Y'); ?> RIS-LIS System. All rights reserved.</p>
                </footer>
            </main>
        </div>
    </div>
 <script>
        function toggleSidebar() {
            document.getElementById('sidebar').classList.toggle('open');
        }
    </script>
    
    <script>
        function showRejectForm(id) {
            document.getElementById('reject-form-' + id).style.display = 'block';
        }
    </script>
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
