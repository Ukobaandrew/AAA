<?php
require_once '../config/database.php'; // Adjust path as needed


// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $test_id = $_POST['test_id'];
    $formula = $_POST['formula'];
    $created_by = 1; // Change to actual logged-in user ID

    $stmt = $pdo->prepare("INSERT INTO test_formulas (test_id, formula, created_by) VALUES (?, ?, ?)");
    $stmt->execute([$test_id, $formula, $created_by]);
    echo "Formula saved successfully.";
}

// Fetch tests and formulas
$tests = $pdo->query("SELECT * FROM tests")->fetchAll(PDO::FETCH_ASSOC);
$formulas = $pdo->query("SELECT tf.id, t.name AS test_name, tf.formula, u.name AS created_by, tf.created_at 
                          FROM test_formulas tf 
                          JOIN tests t ON tf.test_id = t.id 
                          JOIN users u ON tf.created_by = u.id")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Manage Formulas</title>
</head>
<body>
    <h2>Define Test Calculations</h2>
    <form method="POST">
        <label for="test_id">Select Test:</label>
        <select name="test_id" required>
            <?php foreach ($tests as $test) { ?>
                <option value="<?= $test['id'] ?>"><?= $test['name'] ?></option>
            <?php } ?>
        </select>
        <br>
        <label for="formula">Formula:</label>
        <textarea name="formula" required></textarea>
        <br>
        <button type="submit">Save Formula</button>
    </form>

    <h2>Existing Formulas</h2>
    <table border="1">
        <tr>
            <th>Test Name</th>
            <th>Formula</th>
            <th>Created By</th>
            <th>Created At</th>
        </tr>
        <?php foreach ($formulas as $formula) { ?>
            <tr>
                <td><?= $formula['test_name'] ?></td>
                <td><?= $formula['formula'] ?></td>
                <td><?= $formula['created_by'] ?></td>
                <td><?= $formula['created_at'] ?></td>
            </tr>
        <?php } ?>
    </table>

    <!-- Button to Apply Formulas -->
    <br>
    <form action="apply_formula.php" method="POST">
        <button type="submit">Apply Formulas</button>
    </form>

</body>
</html>
