<?php
require_once 'db_connect.php'; // Ensure this file contains your database connection logic

// Fetch machine statuses
$query = "SELECT * FROM machine_integrations ORDER BY created_at DESC";
$result = $conn->query($query);
$machines = $result->fetch_all(MYSQLI_ASSOC);

// Fetch lab performance reports
$query = "SELECT d.name AS department_name, lpr.* FROM lab_performance_reports lpr
          JOIN departments d ON lpr.department_id = d.id ORDER BY lpr.created_at DESC";
$result = $conn->query($query);
$lab_reports = $result->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Monitor Machine Status</title>
    <link rel="stylesheet" href="styles.css"> <!-- Include your CSS file -->
    <style>
        body { font-family: Arial, sans-serif; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f4f4f4; }
    </style>
</head>
<body>
    <h2>Machine Performance Monitor</h2>

    <h3>Machine Status</h3>
    <table>
        <tr>
            <th>Machine Name</th>
            <th>IP Address</th>
            <th>Port</th>
            <th>Status</th>
            <th>Last Updated</th>
        </tr>
        <?php foreach ($machines as $machine): ?>
        <tr>
            <td><?php echo htmlspecialchars($machine['machine_name']); ?></td>
            <td><?php echo htmlspecialchars($machine['ip_address']); ?></td>
            <td><?php echo htmlspecialchars($machine['port']); ?></td>
            <td><?php echo htmlspecialchars($machine['status']); ?></td>
            <td><?php echo htmlspecialchars($machine['created_at']); ?></td>
        </tr>
        <?php endforeach; ?>
    </table>

    <h3>Lab Performance Reports</h3>
    <table>
        <tr>
            <th>Department</th>
            <th>Total Tests</th>
            <th>Urgent Tests</th>
            <th>Rejected Results</th>
            <th>Machine Downtime (min)</th>
            <th>Last Updated</th>
        </tr>
        <?php foreach ($lab_reports as $report): ?>
        <tr>
            <td><?php echo htmlspecialchars($report['department_name']); ?></td>
            <td><?php echo htmlspecialchars($report['total_tests']); ?></td>
            <td><?php echo htmlspecialchars($report['urgent_tests']); ?></td>
            <td><?php echo htmlspecialchars($report['rejected_results']); ?></td>
            <td><?php echo htmlspecialchars($report['machine_downtime']); ?></td>
            <td><?php echo htmlspecialchars($report['created_at']); ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
