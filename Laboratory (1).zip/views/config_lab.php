<?php
include('../config.php'); // Include database connection

// Handle form submission for lab configuration
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_department'])) {
        $dept_name = $_POST['department_name'];
        $hod_id = $_POST['hod_id'] ?? NULL;
        
        $stmt = $conn->prepare("INSERT INTO departments (name, hod_id) VALUES (?, ?)");
        $stmt->bind_param("si", $dept_name, $hod_id);
        $stmt->execute();
    }
    
    if (isset($_POST['update_test'])) {
        $test_id = $_POST['test_id'];
        $price = $_POST['price'];
        $priority = $_POST['priority'];
        
        $stmt = $conn->prepare("UPDATE tests SET price = ?, priority = ? WHERE id = ?");
        $stmt->bind_param("dsi", $price, $priority, $test_id);
        $stmt->execute();
    }
}

// Fetch existing departments
$departments = $conn->query("SELECT * FROM departments");
// Fetch users (HOD candidates)
$users = $conn->query("SELECT id, name FROM users WHERE role IN ('lab_technician', 'doctor')");
// Fetch tests
$tests = $conn->query("SELECT tests.*, departments.name AS dept_name FROM tests LEFT JOIN departments ON tests.department_id = departments.id");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Lab Configuration</title>
</head>
<body>
    <h2>Lab Settings & Configuration</h2>
    
    <h3>Add New Department</h3>
    <form method="POST">
        <input type="text" name="department_name" placeholder="Department Name" required>
        <select name="hod_id">
            <option value="">Select HOD (Optional)</option>
            <?php while ($user = $users->fetch_assoc()) { ?>
                <option value="<?php echo $user['id']; ?>"> <?php echo $user['name']; ?> </option>
            <?php } ?>
        </select>
        <button type="submit" name="add_department">Add Department</button>
    </form>
    
    <h3>Manage Tests</h3>
    <table border="1">
        <tr>
            <th>Test Name</th>
            <th>Department</th>
            <th>Price</th>
            <th>Priority</th>
            <th>Action</th>
        </tr>
        <?php while ($test = $tests->fetch_assoc()) { ?>
            <tr>
                <form method="POST">
                    <input type="hidden" name="test_id" value="<?php echo $test['id']; ?>">
                    <td><?php echo $test['name']; ?></td>
                    <td><?php echo $test['dept_name']; ?></td>
                    <td><input type="text" name="price" value="<?php echo $test['price']; ?>" required></td>
                    <td>
                        <select name="priority">
                            <option value="normal" <?php echo ($test['priority'] == 'normal') ? 'selected' : ''; ?>>Normal</option>
                            <option value="urgent" <?php echo ($test['priority'] == 'urgent') ? 'selected' : ''; ?>>Urgent</option>
                            <option value="critical" <?php echo ($test['priority'] == 'critical') ? 'selected' : ''; ?>>Critical</option>
                        </select>
                    </td>
                    <td><button type="submit" name="update_test">Update</button></td>
                </form>
            </tr>
        <?php } ?>
    </table>
</body>
</html>