<?php
require '../config/db.php'; // Database connection

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $machine_name = $_POST['machine_name'] ?? '';
    $ip_address = $_POST['ip_address'] ?? '';
    $port = $_POST['port'] ?? '';
    $status = 'disconnected';

    if (!empty($machine_name) && !empty($ip_address) && !empty($port)) {
        $stmt = $conn->prepare("INSERT INTO machine_integrations (machine_name, ip_address, port, status) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssis", $machine_name, $ip_address, $port, $status);
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Machine added successfully.']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to add machine.']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'All fields are required.']);
    }
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $result = $conn->query("SELECT * FROM machine_integrations");
    $machines = [];
    while ($row = $result->fetch_assoc()) {
        $machines[] = $row;
    }
    echo json_encode($machines);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
    parse_str(file_get_contents("php://input"), $put_vars);
    $machine_id = $put_vars['id'] ?? '';
    $status = $put_vars['status'] ?? '';

    if (!empty($machine_id) && !empty($status)) {
        $stmt = $conn->prepare("UPDATE machine_integrations SET status = ? WHERE id = ?");
        $stmt->bind_param("si", $status, $machine_id);
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Machine status updated.']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to update status.']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid input.']);
    }
    exit;
}
?>
