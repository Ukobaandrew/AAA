<?php
session_start();
require '../config/db.php'; // Include DB connection

// Check if technician is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'lab_technician') {
    header("Location: ../login.php");
    exit();
}

$technician_id = $_SESSION['user_id'];

// Fetch pending tests assigned to technician
$query = "SELECT tr.id, p.first_name, p.last_name, t.name AS test_name, tr.result, tr.status, tr.sample_status
          FROM test_results tr
          JOIN patients p ON tr.patient_id = p.id
          JOIN tests t ON tr.test_id = t.id
          WHERE tr.technician_id = ? AND tr.status = 'pending'";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $technician_id);
$stmt->execute();
$result = $stmt->get_result();
$pending_tests = $result->fetch_all(MYSQLI_ASSOC);

// Fetch test statistics
$stats_query = "SELECT status, COUNT(*) as count FROM test_results WHERE technician_id = ? GROUP BY status";
$stmt = $conn->prepare($stats_query);
$stmt->bind_param("i", $technician_id);
$stmt->execute();
$stats_result = $stmt->get_result();
$test_stats = [];
while ($row = $stats_result->fetch_assoc()) {
    $test_stats[$row['status']] = $row['count'];
}
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Technician Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav class="col-md-2 d-none d-md-block bg-light sidebar">
                <div class="position-sticky">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active" href="#">Dashboard</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php">Logout</a>
                        </li>
                    </ul>
                </div>
            </nav>

            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <h2 class="mt-4">Technician Workspace</h2>
                <div class="row">
                    <div class="col-md-6">
                        <canvas id="barChart"></canvas>
                    </div>
                    <div class="col-md-6">
                        <canvas id="pieChart"></canvas>
                    </div>
                </div>

                <h3 class="mt-4">Pending Tests</h3>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Patient</th>
                            <th>Test Name</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($pending_tests as $test): ?>
                            <tr>
                                <td><?= htmlspecialchars($test['first_name'] . ' ' . $test['last_name']); ?></td>
                                <td><?= htmlspecialchars($test['test_name']); ?></td>
                                <td><?= htmlspecialchars($test['status']); ?></td>
                                <td>
                                    <a href="process_test.php?id=<?= $test['id']; ?>" class="btn btn-primary btn-sm">Process</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </main>
        </div>
    </div>

    <script>
        // Test Statistics Data
        const testStats = {
            pending: <?= $test_stats['pending'] ?? 0; ?>,
            verified: <?= $test_stats['verified'] ?? 0; ?>,
            approved: <?= $test_stats['approved'] ?? 0; ?>
        };

        // Bar Chart
        new Chart(document.getElementById('barChart'), {
            type: 'bar',
            data: {
                labels: ['Pending', 'Verified', 'Approved'],
                datasets: [{
                    label: 'Test Status',
                    data: [testStats.pending, testStats.verified, testStats.approved],
                    backgroundColor: ['red', 'yellow', 'green']
                }]
            }
        });

        // Pie Chart
        new Chart(document.getElementById('pieChart'), {
            type: 'pie',
            data: {
                labels: ['Pending', 'Verified', 'Approved'],
                datasets: [{
                    data: [testStats.pending, testStats.verified, testStats.approved],
                    backgroundColor: ['red', 'yellow', 'green']
                }]
            }
        });
    </script>
</body>
</html>
