<?php
class SignatureModel {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    // Store digital signature
    public function saveSignature($user_id, $signature) {
        $query = "INSERT INTO signatures (user_id, signature) VALUES (?, ?) 
                  ON DUPLICATE KEY UPDATE signature = VALUES(signature)";
        $stmt = $this->db->prepare($query);
        return $stmt->execute([$user_id, $signature]);
    }

    // Retrieve user's signature
    public function getSignature($user_id) {
        $query = "SELECT signature FROM signatures WHERE user_id = ?";
        $stmt = $this->db->prepare($query);
        $stmt->execute([$user_id]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result ? $result['signature'] : null;
    }

    // Attach signature to test result
    public function attachSignatureToResult($test_result_id, $user_id) {
        $signature = $this->getSignature($user_id);
        if (!$signature) {
            return false; // No signature found
        }
        $query = "UPDATE test_results SET signature = ? WHERE id = ?";
        $stmt = $this->db->prepare($query);
        return $stmt->execute([$signature, $test_result_id]);
    }
}