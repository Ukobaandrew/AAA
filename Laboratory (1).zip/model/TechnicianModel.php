<?php

class TechnicianModel {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    // Fetch technician details by ID
    public function getTechnicianById($technician_id) {
        $query = "SELECT id, name, email, department_id, status FROM users WHERE id = ? AND role = 'lab_technician'";
        $stmt = $this->db->prepare($query);
        $stmt->execute([$technician_id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Fetch all technicians
    public function getAllTechnicians() {
        $query = "SELECT id, name, email, department_id, status FROM users WHERE role = 'lab_technician'";
        $stmt = $this->db->query($query);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Assign a test to a technician
    public function assignTestToTechnician($test_result_id, $technician_id) {
        $query = "UPDATE test_results SET technician_id = ? WHERE id = ?";
        $stmt = $this->db->prepare($query);
        return $stmt->execute([$technician_id, $test_result_id]);
    }

    // Update technician work schedule
    public function updateWorkSchedule($technician_id, $schedule) {
        $query = "UPDATE users SET schedule = ? WHERE id = ?";
        $stmt = $this->db->prepare($query);
        return $stmt->execute([$schedule, $technician_id]);
    }

    // Fetch work schedule of a technician
    public function getWorkSchedule($technician_id) {
        $query = "SELECT schedule FROM users WHERE id = ?";
        $stmt = $this->db->prepare($query);
        $stmt->execute([$technician_id]);
        return $stmt->fetchColumn();
    }

    // Get technician performance data
    public function getTechnicianPerformance($technician_id) {
        $query = "SELECT COUNT(*) AS total_tests,
                         SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) AS approved_tests,
                         SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) AS pending_tests
                  FROM test_results
                  WHERE technician_id = ?";
        $stmt = $this->db->prepare($query);
        $stmt->execute([$technician_id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}
