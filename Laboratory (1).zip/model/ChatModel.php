<?php

class ChatModel {
    private $db;

    public function __construct($database) {
        $this->db = $database;
    }

    public function sendMessage($sender_id, $receiver_id, $message, $file = null, $group_id = null) {
        $query = "INSERT INTO chat_messages (sender_id, receiver_id, message, file_path, group_id) VALUES (?, ?, ?, ?, ?)";
        $stmt = $this->db->prepare($query);
        return $stmt->execute([$sender_id, $receiver_id, $message, $file, $group_id]);
    }

    public function getMessages($user_id, $other_id) {
        $query = "SELECT * FROM chat_messages WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?) ORDER BY created_at ASC";
        $stmt = $this->db->prepare($query);
        $stmt->execute([$user_id, $other_id, $other_id, $user_id]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getDepartmentMessages($department_id) {
        $query = "SELECT cm.* FROM chat_messages cm INNER JOIN users u ON cm.sender_id = u.id WHERE u.department_id = ? ORDER BY cm.created_at ASC";
        $stmt = $this->db->prepare($query);
        $stmt->execute([$department_id]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function deleteMessage($message_id) {
        $query = "DELETE FROM chat_messages WHERE id = ?";
        $stmt = $this->db->prepare($query);
        return $stmt->execute([$message_id]);
    }

    public function getUserList($department_id = null) {
        if ($department_id) {
            $query = "SELECT id, name FROM users WHERE department_id = ?";
            $stmt = $this->db->prepare($query);
            $stmt->execute([$department_id]);
        } else {
            $query = "SELECT id, name FROM users";
            $stmt = $this->db->query($query);
        }
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
