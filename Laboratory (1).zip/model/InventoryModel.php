<?php
class InventoryModel {
    private $conn;

    public function __construct($db) {
        $this->conn = $db;
    }

    // Add a new inventory item
    public function addItem($name, $description, $quantity, $unit, $reorder_level, $auto_reorder) {
        $sql = "INSERT INTO inventory_items (name, description, quantity, unit, reorder_level, auto_reorder) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $this->conn->prepare($sql);
        return $stmt->execute([$name, $description, $quantity, $unit, $reorder_level, $auto_reorder]);
    }

    // Update an inventory item
    public function updateItem($id, $quantity, $reorder_level, $auto_reorder) {
        $sql = "UPDATE inventory_items SET quantity = ?, reorder_level = ?, auto_reorder = ? WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        return $stmt->execute([$quantity, $reorder_level, $auto_reorder, $id]);
    }

    // Get all inventory items
    public function getItems() {
        $sql = "SELECT * FROM inventory_items";
        $stmt = $this->conn->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Get a specific inventory item by ID
    public function getItemById($id) {
        $sql = "SELECT * FROM inventory_items WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Create a new purchase order
    public function createPurchaseOrder($item_id, $item_name, $quantity, $created_by) {
        $sql = "INSERT INTO purchase_orders (item_id, item_name, quantity, created_by) VALUES (?, ?, ?, ?)";
        $stmt = $this->conn->prepare($sql);
        return $stmt->execute([$item_id, $item_name, $quantity, $created_by]);
    }

    // Get all purchase orders
    public function getPurchaseOrders() {
        $sql = "SELECT * FROM purchase_orders";
        $stmt = $this->conn->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Approve or reject a purchase order
    public function updatePurchaseOrderStatus($id, $status) {
        $sql = "UPDATE purchase_orders SET status = ? WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        return $stmt->execute([$status, $id]);
    }
}