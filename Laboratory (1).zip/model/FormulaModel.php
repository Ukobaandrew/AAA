<?php
class FormulaModel {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    // Add a new formula
    public function addFormula($test_id, $formula, $variables) {
        $query = "INSERT INTO formulas (test_id, formula, variables) VALUES (?, ?, ?)";
        $stmt = $this->db->prepare($query);
        return $stmt->execute([$test_id, $formula, json_encode($variables)]);
    }

    // Get formula by test ID
    public function getFormulaByTest($test_id) {
        $query = "SELECT * FROM formulas WHERE test_id = ?";
        $stmt = $this->db->prepare($query);
        $stmt->execute([$test_id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Apply formula to calculate test result
    public function applyFormula($test_id, $input_values) {
        $formulaData = $this->getFormulaByTest($test_id);
        if (!$formulaData) {
            return null; // No formula found
        }
        
        $formula = $formulaData['formula'];
        $variables = json_decode($formulaData['variables'], true);
        
        foreach ($variables as $var) {
            if (!isset($input_values[$var])) {
                return "Missing value for variable: $var";
            }
            $formula = str_replace("{{$var}}", $input_values[$var], $formula);
        }
        
        try {
            return eval("return $formula;");
        } catch (Exception $e) {
            return "Error in formula calculation: " . $e->getMessage();
        }
    }
}
