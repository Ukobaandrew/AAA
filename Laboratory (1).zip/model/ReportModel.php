<?php
require_once '../config/Database.php';

class ReportModel {
    private $conn;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    // Upload a new lab report
    public function uploadReport($patientId, $testId, $resultData, $technicianId) {
        $query = "INSERT INTO test_results (patient_id, test_id, result, status, technician_id, created_at) VALUES (?, ?, ?, 'pending', ?, NOW())";
        $stmt = $this->conn->prepare($query);
        if ($stmt->execute([$patientId, $testId, $resultData, $technicianId])) {
            return ["status" => "success", "message" => "Report uploaded successfully."];
        }
        return ["status" => "error", "message" => "Failed to upload report."];
    }

    // Update test result status (verification or rejection)
    public function updateResultStatus($resultId, $status, $comments = null) {
        $query = "UPDATE test_results SET status = ?, comments = ? WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        if ($stmt->execute([$status, $comments, $resultId])) {
            return ["status" => "success", "message" => "Result status updated successfully."];
        }
        return ["status" => "error", "message" => "Failed to update result status."];
    }

    // Approve test result with doctor's signature
    public function approveResult($resultId, $doctorId, $signature) {
        $query = "UPDATE test_results SET status = 'approved', doctor_id = ?, signature = ? WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        if ($stmt->execute([$doctorId, $signature, $resultId])) {
            return ["status" => "success", "message" => "Result approved successfully."];
        }
        return ["status" => "error", "message" => "Failed to approve result."];
    }

    // Get all lab reports
    public function getAllReports() {
        $query = "SELECT * FROM test_results";
        $stmt = $this->conn->query($query);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Get reports by patient ID
    public function getReportsByPatient($patientId) {
        $query = "SELECT * FROM test_results WHERE patient_id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$patientId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Get reports by status
    public function getReportsByStatus($status) {
        $query = "SELECT * FROM test_results WHERE status = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$status]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Delete a lab report
    public function deleteReport($reportId) {
        $query = "DELETE FROM test_results WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        if ($stmt->execute([$reportId])) {
            return ["status" => "success", "message" => "Report deleted successfully."];
        }
        return ["status" => "error", "message" => "Failed to delete report."];
    }
}
?>
