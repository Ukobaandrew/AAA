<?php

class HODModel {
    private $db;
    
    public function __construct($database) {
        $this->db = $database;
    }

    // Get all HODs
    public function getAllHODs() {
        $query = "SELECT users.id, users.name, users.email, departments.name AS department 
                  FROM users 
                  JOIN departments ON users.id = departments.hod_id 
                  WHERE users.role = 'admin'";
        return $this->db->query($query)->fetchAll(PDO::FETCH_ASSOC);
    }

    // Get HOD by ID
    public function getHODById($id) {
        $query = "SELECT users.id, users.name, users.email, departments.name AS department 
                  FROM users 
                  JOIN departments ON users.id = departments.hod_id 
                  WHERE users.id = ? AND users.role = 'admin'";
        $stmt = $this->db->prepare($query);
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Assign a user as HOD to a department
    public function assignHOD($userId, $departmentId) {
        $query = "UPDATE departments SET hod_id = ? WHERE id = ?";
        $stmt = $this->db->prepare($query);
        return $stmt->execute([$userId, $departmentId]);
    }

    // Remove a HOD from a department
    public function removeHOD($departmentId) {
        $query = "UPDATE departments SET hod_id = NULL WHERE id = ?";
        $stmt = $this->db->prepare($query);
        return $stmt->execute([$departmentId]);
    }

    // Get HOD permissions
    public function getHODPermissions($hodId) {
        $query = "SELECT * FROM permissions WHERE user_id = ?";
        $stmt = $this->db->prepare($query);
        $stmt->execute([$hodId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Set HOD permissions
    public function setHODPermissions($hodId, $permissions) {
        $this->db->beginTransaction();
        try {
            $query = "DELETE FROM permissions WHERE user_id = ?";
            $stmt = $this->db->prepare($query);
            $stmt->execute([$hodId]);
            
            $query = "INSERT INTO permissions (user_id, permission) VALUES (?, ?)";
            $stmt = $this->db->prepare($query);
            foreach ($permissions as $permission) {
                $stmt->execute([$hodId, $permission]);
            }
            
            $this->db->commit();
            return true;
        } catch (Exception $e) {
            $this->db->rollBack();
            return false;
        }
    }
}
