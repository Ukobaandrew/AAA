<?php

// Database connection
function dbConnect() {
    $host = "localhost";
    $dbname = "lab_system";
    $username = "root";
    $password = "";
    
    try {
        $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $pdo;
    } catch (PDOException $e) {
        die("Database connection failed: " . $e->getMessage());
    }
}

// Fetch all departments
function getDepartments() {
    $pdo = dbConnect();
    $stmt = $pdo->prepare("SELECT * FROM departments");
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Fetch users by role
function getUsersByRole($role) {
    $pdo = dbConnect();
    $stmt = $pdo->prepare("SELECT * FROM users WHERE role = ?");
    $stmt->execute([$role]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Fetch patient details by barcode
function getPatientByBarcode($barcode) {
    $pdo = dbConnect();
    $stmt = $pdo->prepare("SELECT * FROM patients WHERE barcode = ?");
    $stmt->execute([$barcode]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

// Fetch test results by patient ID
function getTestResultsByPatient($patient_id) {
    $pdo = dbConnect();
    $stmt = $pdo->prepare("SELECT * FROM test_results WHERE patient_id = ?");
    $stmt->execute([$patient_id]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Add notification
function addNotification($user_id, $message) {
    $pdo = dbConnect();
    $stmt = $pdo->prepare("INSERT INTO notifications (user_id, message) VALUES (?, ?)");
    return $stmt->execute([$user_id, $message]);
}

// Fetch unread notifications
function getUnreadNotifications($user_id) {
    $pdo = dbConnect();
    $stmt = $pdo->prepare("SELECT * FROM notifications WHERE user_id = ? AND status = 'unread'");
    $stmt->execute([$user_id]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Mark notifications as read
function markNotificationsAsRead($user_id) {
    $pdo = dbConnect();
    $stmt = $pdo->prepare("UPDATE notifications SET status = 'read' WHERE user_id = ?");
    return $stmt->execute([$user_id]);
}

// Fetch system setting by key
function getSystemSetting($key) {
    $pdo = dbConnect();
    $stmt = $pdo->prepare("SELECT setting_value FROM system_settings WHERE setting_key = ?");
    $stmt->execute([$key]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result ? $result['setting_value'] : null;
}

// Update system setting
function updateSystemSetting($key, $value) {
    $pdo = dbConnect();
    $stmt = $pdo->prepare("UPDATE system_settings SET setting_value = ? WHERE setting_key = ?");
    return $stmt->execute([$value, $key]);
}

?>