<?php
return [
    'host' => 'localhost', // Change if hosted elsewhere
    'dbname' => 'ris_lis', // Replace with your actual database name
    'username' => 'root', // Replace with your database username
    'password' => '', // Replace with your database password
];
