<?php
require_once 'config.php'; // Database connection

class InventoryConfig {
    private $conn;

    public function __construct($db) {
        $this->conn = $db;
    }

    // Get all inventory categories
    public function getCategories() {
        $query = "SELECT DISTINCT category FROM inventory_items ORDER BY category";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Get low-stock threshold settings
    public function getLowStockThreshold() {
        $query = "SELECT setting_value FROM system_settings WHERE setting_key = 'low_stock_threshold'";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC)['setting_value'] ?? 5; // Default threshold
    }

    // Get safety stock settings
    public function getSafetyStock() {
        $query = "SELECT setting_value FROM system_settings WHERE setting_key = 'safety_stock'";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC)['setting_value'] ?? 10; // Default safety stock
    }

    // Get lead time for reordering
    public function getLeadTime() {
        $query = "SELECT setting_value FROM system_settings WHERE setting_key = 'lead_time'";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC)['setting_value'] ?? 7; // Default lead time (days)
    }

    // Update inventory settings
    public function updateSetting($key, $value) {
        $query = "INSERT INTO system_settings (setting_key, setting_value) VALUES (:key, :value)
                  ON DUPLICATE KEY UPDATE setting_value = :value";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':key', $key);
        $stmt->bindParam(':value', $value);
        return $stmt->execute();
    }
}

// Initialize database connection
$database = new Database();
$db = $database->getConnection();
$inventoryConfig = new InventoryConfig($db);

// Example Usage
$categories = $inventoryConfig->getCategories();
$lowStockThreshold = $inventoryConfig->getLowStockThreshold();
$safetyStock = $inventoryConfig->getSafetyStock();
$leadTime = $inventoryConfig->getLeadTime();

// Handle settings update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $key = $_POST['key'];
    $value = $_POST['value'];
    $inventoryConfig->updateSetting($key, $value);
    echo "Setting updated successfully";
}
?>
