<?php
// Database Configuration
$host = 'localhost';
$dbname = 'u876286375_Ris_Lis';
$username = 'u876286375_Ris_Lis';
$password = 'Rlis@7030';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Define Base URL
define('BASE_URL', 'https://humanracediagnostic.com/AAA/');

// Start session
session_start();

// Fetch inventory items summary
$query = "SELECT * FROM inventory_items ORDER BY name";
$result = $pdo->query($query);
$inventory_items = $result->fetchAll(PDO::FETCH_ASSOC);

// Fetch low stock items
$low_stock_query = "SELECT * FROM inventory_items WHERE quantity <= reorder_level ORDER BY quantity ASC";
$low_stock_result = $pdo->query($low_stock_query);
$low_stock_items = $low_stock_result->fetchAll(PDO::FETCH_ASSOC);

// Fetch pending purchase orders
$pending_orders_query = "SELECT * FROM purchase_orders WHERE status='pending' ORDER BY created_at DESC";
$pending_orders_result = $pdo->query($pending_orders_query);
$pending_orders = $pending_orders_result->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory Report</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body {
            display: flex;
        }
        .sidebar {
            width: 250px;
            height: 100vh;
            background: #343a40;
            padding: 20px;
            color: white;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
            display: block;
            padding: 10px;
            margin: 5px 0;
        }
        .sidebar a:hover {
            background: #495057;
        }
        .content {
            flex-grow: 1;
            padding: 20px;
        }
    </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <h3>Inventory System</h3>
    <a href="dashboard.php">Dashboard</a>
    <a href="add_item.php">Inventory</a>
    <a href="purchase_order_list.php">Orders</a>
    <a href="report.php">Reports</a>
    <a href="export_excel.php" class="btn btn-warning text-white mt-3">Download Excel</a>
</div>

<!-- Main Content -->
<div class="content">
    <div class="container">
        <h1 class="mb-4">Inventory Report</h1>

        <!-- Total Inventory -->
        <h2 class="mt-4">Total Inventory</h2>
        <table class="table table-striped">
            <thead class="table-dark">
                <tr>
                    <th>Item Name</th>
                    <th>Description</th>
                    <th>Quantity</th>
                    <th>Unit</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($inventory_items as $item): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($item['name']); ?></td>
                        <td><?php echo htmlspecialchars($item['description']); ?></td>
                        <td><?php echo htmlspecialchars($item['quantity']); ?></td>
                        <td><?php echo htmlspecialchars($item['unit']); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <!-- Low Stock Items -->
        <h2 class="mt-4">Low Stock Items</h2>
        <table class="table table-bordered">
            <thead class="table-danger">
                <tr>
                    <th>Item Name</th>
                    <th>Quantity</th>
                    <th>Reorder Level</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($low_stock_items as $item): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($item['name']); ?></td>
                        <td><?php echo htmlspecialchars($item['quantity']); ?></td>
                        <td><?php echo htmlspecialchars($item['reorder_level']); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <!-- Pending Purchase Orders -->
        <h2 class="mt-4">Pending Purchase Orders</h2>
        <table class="table table-hover">
            <thead class="table-info">
                <tr>
                    <th>Item Name</th>
                    <th>Quantity</th>
                    <th>Status</th>
                    <th>Created At</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pending_orders as $order): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($order['item_name']); ?></td>
                        <td><?php echo htmlspecialchars($order['quantity']); ?></td>
                        <td><?php echo htmlspecialchars($order['status']); ?></td>
                        <td><?php echo htmlspecialchars($order['created_at']); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
