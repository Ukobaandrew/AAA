<?php
require 'vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

// Database Connection
$host = 'localhost';
$dbname = 'u876286375_Ris_Lis';
$username = 'u876286375_Ris_Lis';
$password = 'Rlis@7030';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Fetch Inventory Data
$query = "SELECT * FROM inventory_items ORDER BY name";
$result = $pdo->query($query);
$inventory_items = $result->fetchAll(PDO::FETCH_ASSOC);

// Create Spreadsheet
$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();
$sheet->setTitle('Inventory Report');

// Set Column Headers
$sheet->setCellValue('A1', 'Item Name');
$sheet->setCellValue('B1', 'Description');
$sheet->setCellValue('C1', 'Quantity');
$sheet->setCellValue('D1', 'Unit');

// Populate Data
$row = 2;
foreach ($inventory_items as $item) {
    $sheet->setCellValue('A' . $row, $item['name']);
    $sheet->setCellValue('B' . $row, $item['description']);
    $sheet->setCellValue('C' . $row, $item['quantity']);
    $sheet->setCellValue('D' . $row, $item['unit']);
    $row++;
}

// Output Excel File
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="Inventory_Report.xlsx"');
header('Cache-Control: max-age=0');

$writer = new Xlsx($spreadsheet);
$writer->save('php://output');
exit;
