<?php
require 'config.php'; // Include database connection file

// Check if item ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("Invalid request.");
}

$item_id = intval($_GET['id']);

// Fetch existing item details
$query = "SELECT * FROM inventory_items WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $item_id);
$stmt->execute();
$result = $stmt->get_result();
$item = $result->fetch_assoc();

if (!$item) {
    die("Item not found.");
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $quantity = intval($_POST['quantity']);
    $unit = $_POST['unit'];
    $reorder_level = intval($_POST['reorder_level']);

    // Update item in database
    $update_query = "UPDATE inventory_items SET name = ?, description = ?, quantity = ?, unit = ?, reorder_level = ? WHERE id = ?";
    $update_stmt = $conn->prepare($update_query);
    $update_stmt->bind_param("ssissi", $name, $description, $quantity, $unit, $reorder_level, $item_id);
    
    if ($update_stmt->execute()) {
        echo "<p>Item updated successfully.</p>";
    } else {
        echo "<p>Error updating item.</p>";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Inventory Item</title>
</head>
<body>
    <h2>Edit Inventory Item</h2>
    <form method="POST">
        <label>Name:</label>
        <input type="text" name="name" value="<?php echo htmlspecialchars($item['name']); ?>" required><br>
        
        <label>Description:</label>
        <textarea name="description"><?php echo htmlspecialchars($item['description']); ?></textarea><br>
        
        <label>Quantity:</label>
        <input type="number" name="quantity" value="<?php echo $item['quantity']; ?>" required><br>
        
        <label>Unit:</label>
        <input type="text" name="unit" value="<?php echo htmlspecialchars($item['unit']); ?>"><br>
        
        <label>Reorder Level:</label>
        <input type="number" name="reorder_level" value="<?php echo $item['reorder_level']; ?>"><br>
        
        <button type="submit">Update Item</button>
    </form>
</body>
</html>
