<?php
// Database Configuration
$host = 'localhost';
$dbname = 'u876286375_Ris_Lis';
$username = 'u876286375_Ris_Lis';
$password = 'Rlis@7030';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Define Base URL
define('BASE_URL', 'https://humanracediagnostic.com/AAA/');

// Start session
session_start();

// Validate and fetch order data
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("Invalid Request");
}

$id = (int)$_GET['id'];

// Fetch purchase order
$query = "SELECT po.*, ii.name AS item_name 
          FROM purchase_orders po 
          JOIN inventory_items ii ON po.item_id = ii.id 
          WHERE po.id = :id";

$stmt = $pdo->prepare($query);
$stmt->bindParam(':id', $id, PDO::PARAM_INT);
$stmt->execute();
$order = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$order) {
    die("Order not found.");
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $status = $_POST['status'] ?? '';

    if (!in_array($status, ['pending', 'approved', 'rejected'])) {
        die("Invalid status value.");
    }

    $updateQuery = "UPDATE purchase_orders SET status = :status WHERE id = :id";
    $stmt = $pdo->prepare($updateQuery);
    $stmt->bindParam(':status', $status, PDO::PARAM_STR);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);

    if ($stmt->execute()) {
        echo "Order updated successfully!";
    } else {
        echo "Error updating order.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Purchase Order</title>
</head>
<body>
    <h2>Edit Purchase Order</h2>
    <form method="post">
        <p>Item: <?= htmlspecialchars($order['item_name']); ?></p>
        <p>Quantity: <?= htmlspecialchars($order['quantity']); ?></p>
        <label for="status">Update Status:</label>
        <select name="status">
            <option value="pending" <?= $order['status'] === 'pending' ? 'selected' : ''; ?>>Pending</option>
            <option value="approved" <?= $order['status'] === 'approved' ? 'selected' : ''; ?>>Approved</option>
            <option value="rejected" <?= $order['status'] === 'rejected' ? 'selected' : ''; ?>>Rejected</option>
        </select>
        <button type="submit">Update</button>
    </form>
</body>
</html>
