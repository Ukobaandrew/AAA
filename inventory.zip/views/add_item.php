<?php
// Database Configuration
$host = 'localhost';
$dbname = 'u876286375_Ris_Lis';
$username = 'u876286375_Ris_Lis';
$password = 'Rlis@7030';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Define Base URL (Update this based on your project structure)
define('BASE_URL', 'https://humanracediagnostic.com/AAA/');

// Start session
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);
    $description = trim($_POST['description']);
    $quantity = filter_var($_POST['quantity'], FILTER_VALIDATE_INT);
    $unit = trim($_POST['unit']);
    $reorder_level = filter_var($_POST['reorder_level'], FILTER_VALIDATE_INT);

    // Validate required fields
    if (empty($name) || $quantity === false || empty($unit)) {
        $error = "Please fill in all required fields correctly.";
    } else {
        $stmt = $pdo->prepare("INSERT INTO inventory_items (name, description, quantity, unit, reorder_level) VALUES (?, ?, ?, ?, ?)");
        if ($stmt->execute([$name, $description, $quantity, $unit, $reorder_level])) {
            $success = "Item added successfully!";
        } else {
            $error = "Failed to add item. Please try again.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Inventory Item</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="card shadow p-4">
            <h2 class="text-center">Add New Inventory Item</h2>
            <?php if (isset($success)) echo "<div class='alert alert-success'>$success</div>"; ?>
            <?php if (isset($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>
            <form action="" method="POST">
                <div class="mb-3">
                    <label for="name" class="form-label">Item Name:</label>
                    <input type="text" name="name" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label for="description" class="form-label">Description:</label>
                    <textarea name="description" class="form-control"></textarea>
                </div>
                <div class="mb-3">
                    <label for="quantity" class="form-label">Quantity:</label>
                    <input type="number" name="quantity" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label for="unit" class="form-label">Unit:</label>
                    <input type="text" name="unit" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label for="reorder_level" class="form-label">Reorder Level:</label>
                    <input type="number" name="reorder_level" class="form-control">
                </div>
                <button type="submit" class="btn btn-primary w-100">Add Item</button>
            </form>
        </div>
    </div>
</body>
</html>
