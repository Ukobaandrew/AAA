<?php
// Database Configuration
$host = 'localhost';
$dbname = 'u876286375_Ris_Lis';
$username = 'u876286375_Ris_Lis';
$password = 'Rlis@7030';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Define Base URL (Update this based on your project structure)
define('BASE_URL', 'https://humanracediagnostic.com/AAA/');

// Start session
session_start();

// Handle add, edit, delete actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        $name = trim($_POST['name'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $quantity = filter_var($_POST['quantity'] ?? 0, FILTER_VALIDATE_INT);
        $unit = trim($_POST['unit'] ?? '');
        $reorder_level = filter_var($_POST['reorder_level'] ?? 0, FILTER_VALIDATE_INT);
        
        if ($_POST['action'] === 'add') {
            $stmt = $pdo->prepare("INSERT INTO inventory_items (name, description, quantity, unit, reorder_level) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$name, $description, $quantity, $unit, $reorder_level]);
        } elseif ($_POST['action'] === 'edit' && isset($_POST['id'])) {
            $id = filter_var($_POST['id'], FILTER_VALIDATE_INT);
            $stmt = $pdo->prepare("UPDATE inventory_items SET name=?, description=?, quantity=?, unit=?, reorder_level=? WHERE id=?");
            $stmt->execute([$name, $description, $quantity, $unit, $reorder_level, $id]);
        } elseif ($_POST['action'] === 'delete' && isset($_POST['id'])) {
            $id = filter_var($_POST['id'], FILTER_VALIDATE_INT);
            $stmt = $pdo->prepare("DELETE FROM inventory_items WHERE id=?");
            $stmt->execute([$id]);
        }
    }
    header("Location: List_Items.php");
    exit();
}

// Fetch inventory items
$stmt = $pdo->query("SELECT * FROM inventory_items");
$items = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory Items</title>
    <link rel="stylesheet" href="../assets/styles.css"> <!-- Add your CSS file -->
</head>
<body>
    <h2>Inventory Items</h2>
    <form method="POST">
        <input type="hidden" name="action" value="add">
        <input type="text" name="name" placeholder="Item Name" required>
        <input type="text" name="description" placeholder="Description">
        <input type="number" name="quantity" placeholder="Quantity" required>
        <input type="text" name="unit" placeholder="Unit">
        <input type="number" name="reorder_level" placeholder="Reorder Level">
        <button type="submit">Add Item</button>
    </form>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Description</th>
            <th>Quantity</th>
            <th>Unit</th>
            <th>Reorder Level</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($items as $item): ?>
            <tr>
                <td><?= htmlspecialchars($item['id']) ?></td>
                <td><?= htmlspecialchars($item['name']) ?></td>
                <td><?= htmlspecialchars($item['description']) ?></td>
                <td><?= htmlspecialchars($item['quantity']) ?></td>
                <td><?= htmlspecialchars($item['unit']) ?></td>
                <td><?= htmlspecialchars($item['reorder_level']) ?></td>
                <td>
                    <form method="POST" style="display:inline;">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="id" value="<?= htmlspecialchars($item['id']) ?>">
                        <button type="submit">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
