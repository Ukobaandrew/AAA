<?php
// Database Configuration
$host = 'localhost';
$dbname = 'u876286375_Ris_Lis';
$username = 'u876286375_Ris_Lis';
$password = 'Rlis@7030';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Define Base URL
define('BASE_URL', 'https://humanracediagnostic.com/AAA/');

// Start session
session_start();

// Fetch pending purchase orders
$query = "SELECT po.*, ii.name AS item_name 
          FROM purchase_orders po 
          JOIN inventory_items ii ON po.item_id = ii.id 
          WHERE po.status = 'pending'";

$stmt = $pdo->prepare($query);
$stmt->execute();
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Purchase Order List</title>
</head>
<body>
    <h2>Pending Purchase Orders</h2>
    <table border="1">
        <tr>
            <th>Item Name</th>
            <th>Quantity</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($orders as $order) { ?>
            <tr>
                <td><?= htmlspecialchars($order['item_name']); ?></td>
                <td><?= htmlspecialchars($order['quantity']); ?></td>
                <td><?= htmlspecialchars($order['status']); ?></td>
                <td>
                    <a href="purchase_order_edit.php?id=<?= $order['id']; ?>">Edit</a>
                </td>
            </tr>
        <?php } ?>
    </table>
</body>
</html>
