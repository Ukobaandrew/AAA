<?php
session_start();

// Database configuration
$host = "localhost"; // Change if your database is hosted elsewhere
$dbname = "u876286375_Ris_Lis"; // Replace with your actual database name
$username = "u876286375_Ris_Lis"; // Replace with your database username
$password = "Rlis@7030"; // Replace with your database password

try {
    // Create a new PDO connection
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Uncomment this if you want to enable login protection
// if (!isset($_SESSION['user_id'])) {
//     header("Location: login.php");
//     exit();
// }

// Fetch inventory levels
$inventoryQuery = "SELECT name, quantity, reorder_level FROM inventory_items ORDER BY quantity ASC";
$inventoryResult = $pdo->query($inventoryQuery);

// Fetch low-stock alerts
$lowStockQuery = "SELECT name, quantity FROM inventory_items WHERE quantity <= reorder_level";
$lowStockResult = $pdo->query($lowStockQuery);

// Fetch procurement notifications
$procurementQuery = "SELECT item_name, quantity, status FROM purchase_orders WHERE status='pending'";
$procurementResult = $pdo->query($procurementQuery);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .card {
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        .table thead {
            background-color: #343a40;
            color: #fff;
        }
    </style>
</head>
<body>
    <div class="container mt-4">
        <h1 class="text-center mb-4">Dashboard Overview</h1>
        
        <div class="row">
            <div class="col-md-6">
                <div class="card p-3">
                    <h4><i class="fas fa-boxes"></i> Inventory Levels</h4>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Item Name</th>
                                <th>Quantity</th>
                                <th>Reorder Level</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = $inventoryResult->fetch(PDO::FETCH_ASSOC)) { ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($row['name']); ?></td>
                                    <td><?php echo htmlspecialchars($row['quantity']); ?></td>
                                    <td><?php echo htmlspecialchars($row['reorder_level']); ?></td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card p-3">
                    <h4 class="text-danger"><i class="fas fa-exclamation-triangle"></i> Low Stock Alerts</h4>
                    <ul class="list-group">
                        <?php while ($row = $lowStockResult->fetch(PDO::FETCH_ASSOC)) { ?>
                            <li class="list-group-item list-group-item-danger">
                                <?php echo htmlspecialchars($row['name']); ?> - Only <strong><?php echo htmlspecialchars($row['quantity']); ?></strong> left!
                            </li>
                        <?php } ?>
                    </ul>
                </div>
            </div>
        </div>
        
        <div class="row mt-4">
            <div class="col-md-12">
                <div class="card p-3">
                    <h4><i class="fas fa-truck-loading"></i> Procurement Notifications</h4>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Item Name</th>
                                <th>Quantity Ordered</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = $procurementResult->fetch(PDO::FETCH_ASSOC)) { ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($row['item_name']); ?></td>
                                    <td><?php echo htmlspecialchars($row['quantity']); ?></td>
                                    <td>
                                        <span class="badge bg-warning text-dark"><?php echo htmlspecialchars($row['status']); ?></span>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
