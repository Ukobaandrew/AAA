<?php
class ProcurementController {
    private $db;

    public function __construct() {
        // Database connection parameters
        $host = 'localhost';
        $dbname = 'u876286375_Ris_Lis';
        $username = 'u876286375_Ris_Lis';
        $password = 'Rlis@7030'; // Update with your DB password

        try {
            $this->db = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
            $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch(PDOException $e) {
            die("Database connection failed: " . $e->getMessage());
        }
    }

    // List all purchase orders
    public function listPurchaseOrders() {
        $stmt = $this->db->prepare("SELECT * FROM purchase_orders ORDER BY created_at DESC");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Generate a new purchase order for a specific inventory item
    public function generatePurchaseOrder($item_id, $quantity) {
        // Retrieve item details from inventory_items table
        $stmt = $this->db->prepare("SELECT * FROM inventory_items WHERE id = :item_id");
        $stmt->bindParam(':item_id', $item_id, PDO::PARAM_INT);
        $stmt->execute();
        $item = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$item) {
            throw new Exception("Item not found");
        }

        // Insert new purchase order
        $stmt = $this->db->prepare("INSERT INTO purchase_orders (item_id, item_name, quantity, status) VALUES (:item_id, :item_name, :quantity, 'pending')");
        $stmt->bindParam(':item_id', $item_id, PDO::PARAM_INT);
        $stmt->bindParam(':item_name', $item['name']);
        $stmt->bindParam(':quantity', $quantity, PDO::PARAM_INT);

        if($stmt->execute()){
            // Log the action (using admin user ID 1 for demonstration)
            $this->logAudit(1, 'Generated Purchase Order', 'Generated PO for item: ' . $item['name'] . ' with quantity: ' . $quantity);
            return $this->db->lastInsertId();
        }
        return false;
    }

    // Approve a purchase order
    public function approvePurchaseOrder($orderId, $approvedBy) {
        // Update the purchase order's status to 'approved'
        $stmt = $this->db->prepare("UPDATE purchase_orders SET status = 'approved' WHERE id = :orderId");
        $stmt->bindParam(':orderId', $orderId, PDO::PARAM_INT);
        if($stmt->execute()){
            $this->logAudit($approvedBy, 'Approved Purchase Order', 'Approved PO ID: ' . $orderId);
            return true;
        }
        return false;
    }

    // Update purchase order details (e.g., adjust order quantity)
    public function updatePurchaseOrder($orderId, $quantity) {
        $stmt = $this->db->prepare("UPDATE purchase_orders SET quantity = :quantity WHERE id = :orderId");
        $stmt->bindParam(':quantity', $quantity, PDO::PARAM_INT);
        $stmt->bindParam(':orderId', $orderId, PDO::PARAM_INT);
        if($stmt->execute()){
            $this->logAudit(1, 'Updated Purchase Order', 'Updated PO ID: ' . $orderId . ' to quantity: ' . $quantity);
            return true;
        }
        return false;
    }

    // Automated procurement: Check inventory and generate orders for items at or below reorder level
    public function automatedProcurement() {
        $stmt = $this->db->prepare("SELECT * FROM inventory_items WHERE quantity <= reorder_level");
        $stmt->execute();
        $lowStockItems = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($lowStockItems as $item) {
            // Calculate required order quantity based on maximum stock level (example: 100)
            $maxStock = 100;
            $orderQuantity = $maxStock - $item['quantity'];
            if($orderQuantity > 0){
                // Ensure no pending order exists for this item
                $stmt2 = $this->db->prepare("SELECT COUNT(*) FROM purchase_orders WHERE item_id = :item_id AND status = 'pending'");
                $stmt2->bindParam(':item_id', $item['id'], PDO::PARAM_INT);
                $stmt2->execute();
                $count = $stmt2->fetchColumn();
                if($count == 0){
                    $this->generatePurchaseOrder($item['id'], $orderQuantity);
                }
            }
        }
    }

    // Log audit actions for accountability
    public function logAudit($userId, $action, $details) {
        $stmt = $this->db->prepare("INSERT INTO audit_logs (user_id, action, details) VALUES (:user_id, :action, :details)");
        $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
        $stmt->bindParam(':action', $action);
        $stmt->bindParam(':details', $details);
        return $stmt->execute();
    }
}

// Example usage:
//
// $procurement = new ProcurementController();
//
// // List all purchase orders
// $orders = $procurement->listPurchaseOrders();
// print_r($orders);
//
// // Generate a new purchase order for inventory item with ID 1 and quantity 50
// $newPOId = $procurement->generatePurchaseOrder(1, 50);
//
// // Approve a purchase order (order ID 2) by admin (user ID 1)
// $procurement->approvePurchaseOrder(2, 1);
//
// // Run the automated procurement process
// $procurement->automatedProcurement();
?>
