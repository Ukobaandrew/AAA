<?php
class InventoryController {
    private $db;

    public function __construct() {
        // Set your database connection parameters
        $host = 'localhost';
        $dbname = 'u876286375_Ris_Lis';
        $username = 'u876286375_Ris_Lis';
        $password = 'Rlis@7030'; // update with your DB password

        try {
            $this->db = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
            $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch(PDOException $e) {
            die("Database connection failed: " . $e->getMessage());
        }
    }

    // List all inventory items
    public function listItems() {
        $stmt = $this->db->prepare("SELECT * FROM inventory_items");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Add a new inventory item
    public function addItem($data) {
        $stmt = $this->db->prepare("INSERT INTO inventory_items (name, description, quantity, unit, reorder_level) VALUES (:name, :description, :quantity, :unit, :reorder_level)");
        $stmt->bindParam(':name', $data['name']);
        $stmt->bindParam(':description', $data['description']);
        $stmt->bindParam(':quantity', $data['quantity'], PDO::PARAM_INT);
        $stmt->bindParam(':unit', $data['unit']);
        $stmt->bindParam(':reorder_level', $data['reorder_level'], PDO::PARAM_INT);
        return $stmt->execute();
    }

    // Update an existing inventory item
    public function updateItem($id, $data) {
        $stmt = $this->db->prepare("UPDATE inventory_items SET name = :name, description = :description, quantity = :quantity, unit = :unit, reorder_level = :reorder_level WHERE id = :id");
        $stmt->bindParam(':name', $data['name']);
        $stmt->bindParam(':description', $data['description']);
        $stmt->bindParam(':quantity', $data['quantity'], PDO::PARAM_INT);
        $stmt->bindParam(':unit', $data['unit']);
        $stmt->bindParam(':reorder_level', $data['reorder_level'], PDO::PARAM_INT);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        return $stmt->execute();
    }

    // Delete an inventory item
    public function deleteItem($id) {
        $stmt = $this->db->prepare("DELETE FROM inventory_items WHERE id = :id");
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        return $stmt->execute();
    }

    // Check inventory items and generate purchase orders if below reorder level
    public function checkStockLevels() {
        $stmt = $this->db->prepare("SELECT * FROM inventory_items WHERE quantity <= reorder_level");
        $stmt->execute();
        $lowStockItems = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if (count($lowStockItems) > 0) {
            foreach ($lowStockItems as $item) {
                // Determine max stock level (this could be based on more complex logic or system settings)
                $maxStock = $this->getMaxStockForItem($item['id']);
                $orderQuantity = $maxStock - $item['quantity'];

                if ($orderQuantity > 0) {
                    // Generate purchase order for low stock item
                    $this->generatePurchaseOrder($item, $orderQuantity);
                }
            }
        }
        return $lowStockItems;
    }

    // Dummy function: Get maximum stock level for an item.
    // In a real system, this might be calculated from historical data or defined per item.
    private function getMaxStockForItem($itemId) {
        // For demonstration, assume max stock is 100 for all items.
        return 100;
    }

    // Dummy function: Generate a purchase order for an item
    // In a real system, you might insert into a purchase_orders table and notify procurement staff.
    private function generatePurchaseOrder($item, $quantity) {
        $message = "Generated Purchase Order for Item: {$item['name']}, Order Quantity: {$quantity}";
        // Log this action into the audit_logs table (using a system/admin user ID, here assumed as 1)
        $this->logAudit(1, 'Auto Purchase Order', $message);

        // Optionally, trigger notifications or additional workflows here.
    }

    // Log audit actions for accountability
    public function logAudit($userId, $action, $details) {
        $stmt = $this->db->prepare("INSERT INTO audit_logs (user_id, action, details) VALUES (:user_id, :action, :details)");
        $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
        $stmt->bindParam(':action', $action);
        $stmt->bindParam(':details', $details);
        return $stmt->execute();
    }
}

// Example usage:
// $inventory = new InventoryController();
// List all items:
// $items = $inventory->listItems();
// print_r($items);

// To add an item:
// $data = [\n    'name' => 'Reagent A',\n    'description' => 'Test reagent for analysis',\n    'quantity' => 50,\n    'unit' => 'bottles',\n    'reorder_level' => 20\n];
// $inventory->addItem($data);

// To check stock levels and auto-generate purchase orders if needed:
// $inventory->checkStockLevels();
?>
