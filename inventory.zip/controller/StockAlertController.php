<?php
class StockAlertController {
    private $db;

    public function __construct() {
        // Database connection parameters
         $host = 'localhost';
        $dbname = 'u876286375_Ris_Lis';
        $username = 'u876286375_Ris_Lis';
        $password = 'Rlis@7030'; // update with your DB password


        try {
            $this->db = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
            $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch(PDOException $e) {
            die("Database connection failed: " . $e->getMessage());
        }
    }

    /**
     * Check inventory items for low stock and generate notifications for active inventory users.
     *
     * @return string Message indicating the process result.
     */
    public function checkLowStockAlerts() {
        // Fetch items with quantity less than or equal to reorder level
        $stmt = $this->db->prepare("SELECT * FROM inventory_items WHERE quantity <= reorder_level");
        $stmt->execute();
        $lowStockItems = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if(empty($lowStockItems)) {
            return "No low stock alerts.";
        }

        // Get active users with the 'inventory' role
        $stmtUsers = $this->db->prepare("SELECT id FROM users WHERE role = 'inventory' AND status = 'active'");
        $stmtUsers->execute();
        $inventoryUsers = $stmtUsers->fetchAll(PDO::FETCH_ASSOC);

        // For each low stock item, create a notification for each inventory user
        foreach($lowStockItems as $item) {
            $message = "Stock Alert: The item '{$item['name']}' is low. Current quantity: {$item['quantity']}, Reorder Level: {$item['reorder_level']}.";
            foreach($inventoryUsers as $user) {
                // Avoid duplicate alerts by checking if an unread notification with the same message already exists
                $stmtCheck = $this->db->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = :user_id AND message = :message AND status = 'unread'");
                $stmtCheck->execute([
                    ':user_id' => $user['id'],
                    ':message' => $message
                ]);
                $exists = $stmtCheck->fetchColumn();
                if($exists == 0) {
                    $this->createNotification($user['id'], $message);
                }
            }
        }

        return "Low stock alerts processed.";
    }

    /**
     * Create a notification for a specified user.
     *
     * @param int    $userId  The ID of the user.
     * @param string $message The notification message.
     * @return bool           True on success, false otherwise.
     */
    private function createNotification($userId, $message) {
        $stmt = $this->db->prepare("INSERT INTO notifications (user_id, message, status) VALUES (:user_id, :message, 'unread')");
        $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
        $stmt->bindParam(':message', $message);
        return $stmt->execute();
    }

    /**
     * List notifications for a given user.
     *
     * @param int $userId The ID of the user.
     * @return array      List of notifications.
     */
    public function listAlerts($userId) {
        $stmt = $this->db->prepare("SELECT * FROM notifications WHERE user_id = :user_id ORDER BY created_at DESC");
        $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Mark a specific notification as read.
     *
     * @param int $notificationId The notification ID.
     * @return bool               True on success, false otherwise.
     */
    public function markAlertAsRead($notificationId) {
        $stmt = $this->db->prepare("UPDATE notifications SET status = 'read' WHERE id = :id");
        $stmt->bindParam(':id', $notificationId, PDO::PARAM_INT);
        return $stmt->execute();
    }
}

// Example usage:
//
// $stockAlert = new StockAlertController();
//
// // Process low stock alerts and generate notifications
// echo $stockAlert->checkLowStockAlerts();
//
// // To list alerts for an inventory user with ID 5:
// $alerts = $stockAlert->listAlerts(5);
// print_r($alerts);
//
// // To mark an alert as read (e.g., notification ID 10):
// $stockAlert->markAlertAsRead(10);
?>
