<?php
session_start();
session_regenerate_id(true);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_secure', 1);

// Load database config
$config = require 'config/config.php';

try {
    $pdo = new PDO(
        "mysql:host={$config['host']};dbname={$config['dbname']};charset=utf8",
        $config['username'],
        $config['password']
    );
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    error_log("DB Connection Error: " . $e->getMessage(), 3, 'errors.log');
    die("⚠️ Database connection error. Please contact the administrator.");
}

// Require the controller
require_once 'controller/InventoryController.php';

// Check if user is logged in
// Uncomment and modify this if authentication is needed
// if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'inventory') {
//     header('Location: ../login.php');
//     exit();
// }

// Get page parameter
$page = $_GET['page'] ?? 'dashboard';
$controller = new InventoryController();

// Check if method exists in the controller before calling it
if (method_exists($controller, $page)) {
    $controller->$page();
} else {
    http_response_code(404);
    echo "<h1>404 - Page Not Found</h1>";
}
?>
