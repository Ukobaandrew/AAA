<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Load PHPMailer
require 'vendor/autoload.php';

$mail = new PHPMailer(true);

try {
    // SMTP Settings
    $mail->isSMTP();
    $mail->Host       = 'smtp.hostinger.com'; // Hostinger SMTP server
    $mail->SMTPAuth   = true;
    $mail->Username   = 'info@fibyfashiontech.com'; // Your Hostinger email
    $mail->Password   = 'Fiby@2024'; // Use actual password or App Password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS; // Use SSL if port 465
    $mail->Port       = 465; // 465 for SSL, 587 for TLS

    // Sender & Recipient
    $mail->setFrom('info@fibyfashiontech.com', 'Fiby at FashionTech');
    $mail->addAddress('johnmaryking661@gmail.com', 'Zeal');

    // Email Content
    $mail->isHTML(true);
    $mail->Subject = 'Test Email from Inventory';
    $mail->Body    = '<h3>This is a test email sent from Inventory , i need like 10m.</h3>';

    // Send Email
    $mail->send();
    echo '✅ Email sent successfully!';
} catch (Exception $e) {
    echo "❌ Email sending failed. Error: {$mail->ErrorInfo}";
}
?>
