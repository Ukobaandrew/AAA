<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'vendor/autoload.php';

// Twilio Configuration
require 'vendor/autoload.php';
use Twilio\Rest\Client;

define('TWILIO_SID', 'your_twilio_sid');
define('TWILIO_AUTH_TOKEN', 'your_twilio_auth_token');
define('TWILIO_PHONE_NUMBER', 'your_twilio_phone');

define('SMTP_HOST', 'smtp.example.com');
define('SMTP_USER', 'your_email@example.com');
define('SMTP_PASS', 'your_email_password');

define('BASE_URL', 'https://humanracediagnostic.com/AAA/');

$pdo = new PDO("mysql:host=localhost;dbname=u876286375_Ris_Lis;charset=utf8", 'u876286375_Ris_Lis', 'Rlis@7030');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Fetch low stock items
$query = "SELECT * FROM inventory_items WHERE quantity <= reorder_level ORDER BY quantity ASC";
$stmt = $pdo->query($query);
$low_stock_items = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($low_stock_items as $item) {
    $po_number = 'PO-' . time();
    $stmt = $pdo->prepare("INSERT INTO purchase_orders (item_name, quantity, status, created_at, po_number) VALUES (?, ?, 'pending', NOW(), ?)");
    $stmt->execute([$item['name'], $item['reorder_level'], $po_number]);

    $supplier_email = 'supplier@example.com';
    $supplier_phone = '+1234567890';
    $order_link = BASE_URL . 'confirm_order.php?po=' . $po_number;

    // Send Email
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = SMTP_HOST;
        $mail->SMTPAuth = true;
        $mail->Username = SMTP_USER;
        $mail->Password = SMTP_PASS;
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        $mail->setFrom(SMTP_USER, 'Inventory System');
        $mail->addAddress($supplier_email);
        $mail->Subject = 'Purchase Order: ' . $po_number;
        $mail->Body = "Dear Supplier,\n\nA new purchase order ($po_number) has been generated.\nClick here to confirm: $order_link";
        $mail->send();
    } catch (Exception $e) {
        error_log("Mail error: " . $mail->ErrorInfo);
    }

    // Send SMS
    $client = new Client(TWILIO_SID, TWILIO_AUTH_TOKEN);
    $client->messages->create(
        $supplier_phone,
        [
            'from' => TWILIO_PHONE_NUMBER,
            'body' => "New Purchase Order ($po_number) generated. Confirm: $order_link"
        ]
    );
}

echo "Purchase orders generated and notifications sent.";
