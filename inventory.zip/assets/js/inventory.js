// inventory.js

document.addEventListener("DOMContentLoaded", function () {
    loadInventory();
    
    document.getElementById("add-item-form").addEventListener("submit", function (e) {
        e.preventDefault();
        addInventoryItem();
    });
});

function loadInventory() {
    fetch("load_inventory.php")
        .then(response => response.json())
        .then(data => {
            let inventoryTable = document.getElementById("inventory-table-body");
            inventoryTable.innerHTML = "";
            data.forEach(item => {
                inventoryTable.innerHTML += `
                    <tr>
                        <td>${item.id}</td>
                        <td>${item.name}</td>
                        <td>${item.description}</td>
                        <td>${item.quantity}</td>
                        <td>${item.unit}</td>
                        <td>${item.reorder_level}</td>
                        <td>
                            <button onclick="editItem(${item.id})">Edit</button>
                            <button onclick="deleteItem(${item.id})">Delete</button>
                        </td>
                    </tr>
                `;
            });
        })
        .catch(error => console.error("Error loading inventory:", error));
}

function addInventoryItem() {
    let formData = new FormData(document.getElementById("add-item-form"));
    fetch("add_inventory.php", {
        method: "POST",
        body: formData
    })
    .then(response => response.json())
    .then(result => {
        alert(result.message);
        loadInventory();
    })
    .catch(error => console.error("Error adding item:", error));
}

function editItem(id) {
    let newName = prompt("Enter new name:");
    if (!newName) return;
    
    fetch("edit_inventory.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, name: newName })
    })
    .then(response => response.json())
    .then(result => {
        alert(result.message);
        loadInventory();
    })
    .catch(error => console.error("Error editing item:", error));
}

function deleteItem(id) {
    if (!confirm("Are you sure you want to delete this item?")) return;
    
    fetch("delete_inventory.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id })
    })
    .then(response => response.json())
    .then(result => {
        alert(result.message);
        loadInventory();
    })
    .catch(error => console.error("Error deleting item:", error));
}
