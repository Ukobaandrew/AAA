<?php
class InventoryModel {
    private $db;

    public function __construct() {
        // Database connection parameters
        $host = 'localhost';
        $dbname = 'u876286375_Ris_Lis';
        $username = 'u876286375_Ris_Lis';
        $password = 'Rlis@7030'; // Update with your actual DB password

        try {
            $this->db = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
            $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            die("Database connection failed: " . $e->getMessage());
        }
    }

    // Retrieve all inventory items
    public function getAllItems() {
        $stmt = $this->db->prepare("SELECT * FROM inventory_items ORDER BY created_at DESC");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Retrieve a single inventory item by ID
    public function getItemById($id) {
        $stmt = $this->db->prepare("SELECT * FROM inventory_items WHERE id = :id");
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Add a new inventory item
    public function addItem($data) {
        $stmt = $this->db->prepare("INSERT INTO inventory_items (name, description, quantity, unit, reorder_level) VALUES (:name, :description, :quantity, :unit, :reorder_level)");
        $stmt->bindParam(':name', $data['name']);
        $stmt->bindParam(':description', $data['description']);
        $stmt->bindParam(':quantity', $data['quantity'], PDO::PARAM_INT);
        $stmt->bindParam(':unit', $data['unit']);
        $stmt->bindParam(':reorder_level', $data['reorder_level'], PDO::PARAM_INT);
        return $stmt->execute();
    }

    // Update an existing inventory item
    public function updateItem($id, $data) {
        $stmt = $this->db->prepare("UPDATE inventory_items SET name = :name, description = :description, quantity = :quantity, unit = :unit, reorder_level = :reorder_level WHERE id = :id");
        $stmt->bindParam(':name', $data['name']);
        $stmt->bindParam(':description', $data['description']);
        $stmt->bindParam(':quantity', $data['quantity'], PDO::PARAM_INT);
        $stmt->bindParam(':unit', $data['unit']);
        $stmt->bindParam(':reorder_level', $data['reorder_level'], PDO::PARAM_INT);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        return $stmt->execute();
    }

    // Delete an inventory item
    public function deleteItem($id) {
        $stmt = $this->db->prepare("DELETE FROM inventory_items WHERE id = :id");
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        return $stmt->execute();
    }
}
?>
