<?php
class ProcurementModel {
    private $db;

    public function __construct() {
        // Database connection parameters
        $host = 'localhost';
        $dbname = 'u876286375_Ris_Lis';
        $username = 'u876286375_Ris_Lis';
        $password = 'Rlis@7030'; // update with your DB password


        try {
            $this->db = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
            $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            die("Database connection failed: " . $e->getMessage());
        }
    }

    /**
     * Retrieve all purchase orders.
     *
     * @return array List of purchase orders.
     */
    public function getAllPurchaseOrders() {
        $stmt = $this->db->prepare("SELECT * FROM purchase_orders ORDER BY created_at DESC");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Retrieve a single purchase order by ID.
     *
     * @param int $id Purchase order ID.
     * @return array|false The purchase order data or false if not found.
     */
    public function getPurchaseOrderById($id) {
        $stmt = $this->db->prepare("SELECT * FROM purchase_orders WHERE id = :id");
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /**
     * Create a new purchase order.
     *
     * @param array $data Purchase order data (expects keys: item_id, item_name, quantity, [status]).
     * @return mixed The last insert ID on success or false on failure.
     */
    public function createPurchaseOrder($data) {
        $stmt = $this->db->prepare("INSERT INTO purchase_orders (item_id, item_name, quantity, status) VALUES (:item_id, :item_name, :quantity, :status)");
        $stmt->bindParam(':item_id', $data['item_id'], PDO::PARAM_INT);
        $stmt->bindParam(':item_name', $data['item_name']);
        $stmt->bindParam(':quantity', $data['quantity'], PDO::PARAM_INT);
        // Use provided status or default to 'pending'
        $status = isset($data['status']) ? $data['status'] : 'pending';
        $stmt->bindParam(':status', $status);

        if ($stmt->execute()) {
            return $this->db->lastInsertId();
        }
        return false;
    }

    /**
     * Update an existing purchase order.
     *
     * @param int   $id   Purchase order ID.
     * @param array $data Purchase order data (expects keys: item_id, item_name, quantity, status).
     * @return bool True on success, false on failure.
     */
    public function updatePurchaseOrder($id, $data) {
        $stmt = $this->db->prepare("UPDATE purchase_orders SET item_id = :item_id, item_name = :item_name, quantity = :quantity, status = :status WHERE id = :id");
        $stmt->bindParam(':item_id', $data['item_id'], PDO::PARAM_INT);
        $stmt->bindParam(':item_name', $data['item_name']);
        $stmt->bindParam(':quantity', $data['quantity'], PDO::PARAM_INT);
        $stmt->bindParam(':status', $data['status']);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        return $stmt->execute();
    }

    /**
     * Delete a purchase order by ID.
     *
     * @param int $id Purchase order ID.
     * @return bool True on success, false on failure.
     */
    public function deletePurchaseOrder($id) {
        $stmt = $this->db->prepare("DELETE FROM purchase_orders WHERE id = :id");
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        return $stmt->execute();
    }

    /**
     * Retrieve all pending purchase orders.
     *
     * @return array List of pending purchase orders.
     */
    public function getPendingPurchaseOrders() {
        $stmt = $this->db->prepare("SELECT * FROM purchase_orders WHERE status = 'pending' ORDER BY created_at DESC");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}



class InventoryModel {
    private $db;

    public function __construct() {
        // Database connection
        $host = 'localhost';
        $dbname = 'u876286375_Ris_Lis';
        $username = 'u876286375_Ris_Lis';
        $password = 'Rlis@7030';

        try {
            $this->db = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
            $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            die("Database connection failed: " . $e->getMessage());
        }
    }

    // Retrieve all inventory items with stock levels
    public function getAllItems() {
        $stmt = $this->db->prepare("SELECT * FROM inventory_items ORDER BY created_at DESC");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Check if stock is below minimum level
    public function checkLowStockItems() {
        $stmt = $this->db->prepare("SELECT * FROM inventory_items WHERE stock_quantity <= min_stock_level");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

class ProcurementController {
    private $db;

    public function __construct() {
        // Database connection
        $host = 'localhost';
        $dbname = 'u876286375_Ris_Lis';
        $username = 'u876286375_Ris_Lis';
        $password = 'Rlis@7030';

        try {
            $this->db = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
            $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch(PDOException $e) {
            die("Database connection failed: " . $e->getMessage());
        }
    }

    // Generate automatic purchase order for low stock items
    public function autoGeneratePurchaseOrders() {
        $inventory = new InventoryModel();
        $lowStockItems = $inventory->checkLowStockItems();

        foreach ($lowStockItems as $item) {
            $stmt = $this->db->prepare("INSERT INTO purchase_orders (item_id, quantity, status) VALUES (?, ?, 'Pending')");
            $stmt->execute([$item['id'], $item['max_stock_level'] - $item['stock_quantity']]);
        }
    }
}
?>

?>
